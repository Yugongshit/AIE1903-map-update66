# Evidence and Evaluation

## Final evidence

Our final evidence will be an offline replay and controlled comparisons showing how perception, reliability assessment, planning, and shared-map maintenance work together to respond to road-map discrepancies.

The replay will align the reference map, observed lane markings, occupancy candidates, reliability decisions, and planning outputs in space and time. It will show why an event remains temporary, requires further review, or qualifies for a versioned base-map update. Decision histories and rollback records will make the process inspectable.

## Evaluation design

We will evaluate candidate assessment using precision, recall, and F1 on independently labelled cases. Planning will compare map-only, fixed-penalty, and reliability-aware policies under the same scenarios and feasibility checks. We will report feasible-route rate, route length, and failures; route-length comparisons will use cases in which both compared policies find a feasible route.

For map maintenance, we will report incorrect writes, false-update rate, geometry error against independent reference geometry, and update delay from the first qualifying observation. We will also report eligible-update coverage, including changes still awaiting an update. With no writes, false-update rate is undefined, not evidence of perfect accuracy. Version and rollback checks will assess traceability.

## Test conditions

Real observations and controlled simulations with known outcomes will be reported separately. Thresholds, temporal windows, and geometric matching criteria will be fixed before testing; variants of one scene will remain in the same data split. Unlabelled cases will not be treated as negatives. Persistent and temporary changes will be tested using independent revisits where available and clearly labelled temporal simulations; simulated persistence will not be claimed as a real-world observation.

## What the evidence will and will not demonstrate

The evidence will show whether the modules integrate coherently, how their decisions perform within the tested scenarios, and whether map actions can be traced to supporting observations. It can test whether reliability and persistence checks reduce incorrect updates or improve planning relative to the stated baselines; any improvement remains an empirical question.

It will not establish permanent change from repeated frames in a single pass, calibrate heuristic scores as probabilities, show that nearby vehicle behaviour is caused by a map discrepancy, or establish real-world closed-loop driving safety. The current scene contains 41 frames over approximately 20 seconds from one pass, so it supports an integration example rather than a claim of long-term change. Broader generalisation requires additional independently labelled scenes and revisits.