# Map Change Classification, Updating and Visualisation

## Objective

The core objective is to classify observed road changes as long-term, short-term or unresolved, then update and visualise the map. Verified long-term structural changes modify the base map; short-term obstacles or occupancy are recorded in a temporary event layer.

## Input

Inputs include the original map, change candidates with locations and geometry from perception, multi-frame verification results, observation times and visit records, and reliability decisions with observation-quality evidence. This module uses those upstream results for persistence assessment and map maintenance. Recorded sequences can supply time-ordered test inputs.

## Pipeline

First, associate candidates with map objects and check geometry, time and observation quality. Assess persistence using multi-frame and independent-visit evidence. Long-term structural changes update the base map only after reliability, object-matching and geometry checks, retaining before/after states, versions, evidence and rollback records.

Short-term changes enter a temporary event layer: annotations over the base map carrying location, affected area, observation time and validity, without rewriting road structure. New verification can update or clear an event; expiry or missing observations require review and do not establish clearance. Verified occupancy with unresolved persistence may also retain an event annotation while its classification remains unresolved. Insufficient evidence does not force a base-map update.

## Output

Our final evidence will be a demonstration and evaluation of map-change persistence assessment, layered updating and visualisation, showing how long-term changes update the base map, how short-term changes enter the temporary event layer, and how decisions and edits retain evidence, versions and rollback records.

Outputs include long-term, short-term and unresolved classifications, the updated base map, the temporary event layer, before/after visualisations and update logs. Evaluation will compare classifications with reference labels, reporting misclassifications, missed changes and the unresolved proportion. It will also measure false-update rate, eligible-update coverage, geometry error, update delay and rollback correctness, including eligible changes left unapplied.

## Conditions and Limitations

Long-term decisions require valid evidence over a sufficient time span. Consecutive frames from one short recording do not independently prove long-term change; persistent occupancy does not automatically establish structural change. Real and simulated evidence will be reported separately. Without reference labels, demonstrations establish workflow rather than classification accuracy. Evidence does not guarantee permanence or real-world driving safety.

Existing work includes map and observation intake, controlled updates and rollback. Actual reliability outputs, real revisit evidence and reference labels remain to be completed. Sharing updates with other vehicles for planning is a future extension, outside this module’s core deliverables and current evaluation requirements.