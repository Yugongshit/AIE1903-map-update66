# Shared-Map Updates and Reuse

## Input

Inputs comprise the existing map, vehicle observations, and the reliability, persistence and geometry evidence used in update decisions.

Recorded sequences provide time-ordered test inputs; the final outcome is the update–share–use chain.

## Method

The system will separate temporary events from persistent structural changes. Verified obstacles or temporary occupancy can be shared promptly in an event layer without waiting for long-term confirmation. Each event will carry its affected area, observation time, validity status and provenance. Structural changes will enter the base map only after reliability, independent-visit persistence, object-matching and geometry checks, with versions, before/after records and rollback history.

A publishing service will provide versioned map updates and events. A separate receiving client will retrieve and apply them through a common interface, checking object identity, version and freshness. Confirmed impassable areas should cause affected routes to be avoided or no feasible plan to be reported. Partial occupancy and uncertain candidates require local perception, coverage assessment and feasibility checks.

We will evaluate map maintenance using false-update rate, eligible-update coverage, geometry error and update delay. Sharing tests will measure version consistency and publication-to-application latency, and check stale updates, duplicates and rollback propagation. Planning will compare no shared updates, fixed penalties for shared candidates, and reliability-aware layered updates under identical local observations, start/goal settings and feasibility checks.

## Output

Our final evidence will be an end-to-end demonstration and controlled comparisons showing how a road change observed by one vehicle is assessed for reliability and persistence, added to the appropriate shared-map layer, published, and used by another vehicle for replanning.

The visualisation will show map differences, events, evidence, publication and receipt states, and the receiving planner’s response. The evidence will test whether road changes are maintained appropriately, transferred consistently and used by another vehicle’s planner.

We will report feasible-route rate, route length and failure reasons; length comparisons will use cases feasible for both compared policies.

## Assumption and Limitations

Expiry or missing observations will not establish clearance. Real observations and controlled simulations will be reported separately. Evidence will not guarantee permanence, interoperability with every production vehicle, or real-world driving safety.

Current work includes real-map and observation intake, plus controlled update and rollback prototypes. Actual reliability outputs, publishing and receiving clients, planner integration and real revisits remain to be completed. The final demonstration will distinguish implemented capabilities from planned validation and will not assume a performance improvement.