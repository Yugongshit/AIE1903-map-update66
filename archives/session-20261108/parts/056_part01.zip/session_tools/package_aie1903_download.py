from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import zipfile

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

SITE = Path('/tmp/aie1903-live-site')
SOURCE = Path('/tmp/aie1903-workbench-source')
RELEASE = Path('/workspace/AIE1903-map-update66/outputs/nuscenes/scene-0980/decision-release-v2-20261106')
OUT = Path('/workspace/AIE1903-map-update66/outputs/downloads-20261106')
ROOT = OUT / 'AIE1903_Evidence_Studio_20261106'
ROOT.mkdir(parents=True, exist_ok=False)
OUT.mkdir(parents=True, exist_ok=True)
site_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SITE, text=True).strip()
source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()

for name in ['en', 'zh', 'assets', 'review']:
    shutil.copytree(SITE / name, ROOT / 'website' / name)
for name in ['index.html', 'version.json', 'dataset_manifest.json', 'README.md', '.nojekyll']:
    shutil.copy2(SITE / name, ROOT / 'website' / name)

names = subprocess.check_output(
    ['git', 'ls-files', '-z', 'map_update', 'scripts', 'tests', 'docs', 'examples',
     'pyproject.toml', 'requirements-rerun.txt', 'README.md', '.gitignore'],
    cwd=SOURCE).decode().split('\0')
for name in filter(None, names):
    path = SOURCE / name
    if path.is_file():
        target = ROOT / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)

(ROOT / 'validation').mkdir()
for name in ['decision_checks.json', 'bilingual_checks.json', 'rerun_checks.json',
             'runtime_validation.json', 'deployment_check.json']:
    shutil.copy2(RELEASE / name, ROOT / 'validation' / name)

launcher = '''#!/usr/bin/env python3
"""Serve this packaged static demo on localhost using Python's standard library."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
import webbrowser

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--no-browser', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent / 'website'
if not (root / 'en/index.html').is_file():
    raise SystemExit('Please extract the entire ZIP before starting the demo.')
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
with ThreadingHTTPServer(('127.0.0.1', 0), handler) as server:
    url = 'http://127.0.0.1:%d/en/index.html#decisions' % server.server_port
    print('Demo: ' + url, flush=True)
    print('Keep this window open. Press Ctrl+C to stop. / 保持窗口打开，按 Ctrl+C 结束。', flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
'''
(ROOT / 'run_demo.py').write_text(launcher)
(ROOT / 'Start_Mac.command').write_text('''#!/bin/bash
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required for local viewing. Open START_HERE.html for the online links."
  read -r -p "Press Enter to close. "
  exit 1
fi
python3 run_demo.py
''')
(ROOT / 'Start_Mac.command').chmod(0o755)
(ROOT / 'Start_Windows.cmd').write_text('''@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python run_demo.py
) else (
  py -3 run_demo.py
)
pause
''')

english = 'https://yugongshit.github.io/AIE1903-map-update66/en/index.html?v=35aa3d4#decisions'
chinese = 'https://yugongshit.github.io/AIE1903-map-update66/zh/index.html?v=35aa3d4#decisions'
readme = f'''AIE1903 Evaluation & Evidence — 下载包使用说明
版本：2026-11-06

1. 最快查看：打开 START_HERE.html，点击英文版或中文版在线入口。
英文版：{english}
中文版：{chinese}

2. 本地运行：先完整解压 ZIP，不要只打开里面的单个文件。
本地运行需要已经安装 Python 3，不需要 pip 安装依赖。
Mac：双击 Start_Mac.command。若无法直接启动，在终端进入解压目录后运行 python3 run_demo.py。
Windows：双击 Start_Windows.cmd，或在解压目录执行 py -3 run_demo.py。
浏览器会打开本地网站；终端窗口保持打开。按 Ctrl+C 结束。
如果电脑没有 Python 3，直接使用在线链接即可。
Rerun 需要支持 WebGL 的浏览器；建议使用桌面版 Chrome 或 Edge。
不要只双击 website/en/index.html 来验证全部功能，Rerun 的模块与 WASM 需要 HTTP 服务。

3. 演示顺序：LD003 → 拖动地图分界线 → 展开可靠性和决策依据 → 受控写入实验 → 26 小时 → 回退 → 评估检查。

4. 内容：
website/：已经构建的英文和中文网站、原视频、RRD、官方 Rerun 查看器、案例 CSV、来源说明和报告。
source/：维护引擎、网站构建与检查代码、测试和文档；它不包含全部原始资料或模型权重。
validation/：这一版本的检查结果与 GitHub Pages 部署记录。
Quick_Start_CN.docx：可用 Word 打开的使用说明。
PACKAGE_MANIFEST.json：来源提交和各文件 SHA256。

5. 数据边界：真实场景仅 nuScenes scene-0980。真实基础地图写入为 0，真实准确率尚未知。
受控写图使用隔离副本及人为设定的偏移、复访和质量输入；不代表真实复访。
英文使用原类别标注，中文翻译显示名称。Argoverse、规划和跨车共享未接入。
已有原始演示视频；没有在下载包中补造 CAM_FRONT 实景照片。

6. source/ 用于查阅和继续开发。要从头重新运行完整数据处理/构建流程，仍需原仓库中对应成员的原始资料及依赖。
本地直接演示 website/ 不需要重新处理数据。

网站提交：{site_commit}
源码提交：{source_commit}
检查范围：99 项核心测试；56 项新工作台、40 项双语回归和35 项 Rerun 浏览器检查通过。
浏览器验证环境为云端 Chromium / SwiftShader，不代表已经在你的 Mac 或 Safari 上验证。
'''
(ROOT / 'README_先读我.txt').write_text(readme)
(ROOT / 'START_HERE.html').write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AIE1903 · 开始使用</title><style>body{{max-width:800px;margin:70px auto;padding:24px;background:#0b1420;color:#e6edf5;font:18px/1.8 system-ui}}a{{color:#93e1d1}}.button{{display:inline-block;background:#1c3d40;padding:12px 24px;border-radius:10px;text-decoration:none;margin:10px 16px 10px 0}}small{{color:#a7b8c7}}</style><h1>AIE1903 Evaluation &amp; Evidence</h1><p>2026-11-06 · 地图决策、证据追溯与评估工作台</p><a class="button" href="{english}">打开英文网站</a><a class="button" href="{chinese}">打开中文网站</a><h2>本地演示</h2><p>完整解压后，有 Python 3 的 Mac 可运行 <b>Start_Mac.command</b>，Windows 可运行 <b>Start_Windows.cmd</b>。浏览器自动打开后，请保持启动窗口打开。也可以在解压目录执行 <code>python3 run_demo.py</code>。</p><p>若没有 Python 3，请直接点击上方在线入口。详细步骤见 <a href="Quick_Start_CN.docx">Word 使用说明</a> 或 <a href="README_先读我.txt">文字说明</a>。</p><p><small>真实基础地图写入为 0；写入与回退展示使用受控副本。真实数据与受控实验在页面中分开显示。</small></p></html>''')

document = Document()
normal = document.styles['Normal']
normal.font.name = 'Calibri'
normal.font.size = Pt(11)
normal._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
document.add_heading('AIE1903 下载包使用说明', 0)
document.add_paragraph('地图决策 · 证据追溯 · 评估检查\n2026 年 11 月 6 日')
document.add_heading('先打开哪一个', 1)
document.add_paragraph('下载并完整解压 ZIP 后，先打开 START_HERE.html。里面有英文、中文在线入口；无需安装软件即可访问。')
def hyperlink(paragraph, text, url):
    relation = paragraph.part.relate_to(url, 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink', is_external=True)
    link = OxmlElement('w:hyperlink'); link.set(qn('r:id'), relation)
    run = OxmlElement('w:r'); props = OxmlElement('w:rPr')
    color = OxmlElement('w:color'); color.set(qn('w:val'), '087E8B'); props.append(color)
    run.append(props); label = OxmlElement('w:t'); label.text = text; run.append(label); link.append(run)
    paragraph._p.append(link)
hyperlink(document.add_paragraph(), '点击打开英文网站', english)
hyperlink(document.add_paragraph(), '点击打开中文网站', chinese)
document.add_heading('希望在本地运行', 1)
for text in [
    '完整解压 ZIP，保留文件夹内所有文件。',
    '本地运行需要 Python 3，启动器只使用标准库，不需要安装额外 Python 包。',
    'Mac：双击 Start_Mac.command。也可以在终端进入解压目录后执行 python3 run_demo.py。',
    'Windows：双击 Start_Windows.cmd，或在解压目录执行 py -3 run_demo.py。',
    '启动后浏览器自动打开；请保持终端窗口打开，按 Ctrl+C 结束。若没有 Python 3，使用在线入口即可。',
    'Rerun 需要 WebGL；建议使用桌面 Chrome 或 Edge。只双击 website 内的 HTML 文件不能验证 Rerun 的全部功能。',
]: document.add_paragraph(text, style='List Bullet')
document.add_heading('建议的演示路线', 1)
for text in [
    '选择默认 LD003，拖动地图中间分界线，比较参考地图、观测和处理结果。',
    '点击下方多帧验证、可靠性和地图决策，查看原始字段与来源；切换帧检查支持证据。',
    '打开受控写入实验，选择偏移，点击 26 小时观察副本写入，再点击回退检查恢复。',
    '进入评估检查，切换方法与条件，点击误报、漏报或证据不足查看具体案例。',
    '点击 Rerun 查看可操作的场景。英文保留原类别，中文翻译相同标注。',
]: document.add_paragraph(text, style='List Number')
document.add_heading('包中有哪些内容', 1)
table = document.add_table(rows=1, cols=2); table.style = 'Light Shading Accent 1'
table.rows[0].cells[0].text='文件或目录'; table.rows[0].cells[1].text='作用'
for a,b in [
 ('website/','中英文网站、原视频、RRD、官方 Rerun 查看器、案例表及报告。'),
 ('source/','维护引擎、网站代码、测试和实现文档；重建完整流程仍需原始资料和相应依赖。'),
 ('validation/','当前版本检查结果和部署记录。'),
 ('run_demo.py / Start_Mac.command / Start_Windows.cmd','通过本机 HTTP 服务打开已经构建的网站。'),
 ('PACKAGE_MANIFEST.json','源代码/网站提交与包内文件的 SHA256。'),
]:
    cells=table.add_row().cells; cells[0].text=a; cells[1].text=b
document.add_heading('解释结果时保留这些边界', 1)
document.add_paragraph('真实数据仅为 nuScenes scene-0980，真实基础地图写入保持 0，真实准确率尚未知。受控写图的偏移、复访和质量条件为人为输入，实际写入及回退发生在隔离地图副本上。Argoverse、规划与跨车共享未接入。原始演示视频已经包含；没有补造车前实景照片。')
document.add_paragraph('本次应用检查：99 项核心测试、56 项工作台检查、40 项双语检查、35 项 Rerun 检查通过。浏览器环境为云端 Chromium / SwiftShader，不能替代你的实际 Mac 或 Safari 验证。')
document.add_paragraph(f'网站提交：{site_commit}\n源码提交：{source_commit}')
for section in document.sections:
    section.top_margin=section.bottom_margin=Inches(0.75)
    section.left_margin=section.right_margin=Inches(0.8)
document.save(ROOT / 'Quick_Start_CN.docx')
shutil.copy2(ROOT / 'Quick_Start_CN.docx', OUT / 'AIE1903_Quick_Start_CN_20261106.docx')

manifest={
    'schema':'aie1903-download-package-1.0', 'release_date':'2026-11-06',
    'website_commit':site_commit, 'source_commit':source_commit,
    'dataset':'nuscenes/scene-0980','real_base_map_writes':0,
    'full_raw_dataset_included':False,
    'created_at_utc':datetime.now(timezone.utc).isoformat(),
    'files':[{ 'path':str(path.relative_to(ROOT)), 'bytes':path.stat().st_size,
              'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
             for path in sorted(ROOT.rglob('*')) if path.is_file()]
}
(ROOT / 'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
archive=OUT / (ROOT.name+'.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(ROOT.rglob('*')):
        if path.is_file():z.write(path,str(path.relative_to(OUT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(manifest['files'])+1
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'MiB':round(archive.stat().st_size/1048576,1),'files':len(manifest['files'])+1,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'word':str(OUT/'AIE1903_Quick_Start_CN_20261106.docx')},ensure_ascii=False))
