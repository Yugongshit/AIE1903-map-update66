"""Reorganise the six existing deliverables into the requested four sections."""
from pathlib import Path
import json
import re

from pptx.util import Inches
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from docx.shared import Pt
from docx.oxml.ns import qn

from build_shared_map_revision import Deck, NAVY, TEAL, MINT, INK, MUTED, PAPER, WHITE, BORDER, CORAL, GOLD, BLUE
from build_separate_evidence_versions import document_base
from shared_map_structured_content import HEADINGS, TITLES, PROPOSAL, SCRIPT, AUDIT

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/shared_map_structured'


class StructuredDeck(Deck):
    def heading(self, num, subtitle):
        s = self.p.slides.add_slide(self.p.slide_layouts[6])
        s.background.fill.solid(); s.background.fill.fore_color.rgb = RGBColor.from_string(PAPER)
        self.box(s, 0, 0, 16, .09, TEAL, kind=MSO_SHAPE.RECTANGLE)
        self.text(s, .55, .28, 6.7, .24, self.pick('共享地图更新与复用 · 证据与评估', 'SHARED-MAP UPDATES AND REUSE · EVIDENCE & EVALUATION'), 10.4, TEAL, True)
        nav = self.pick('输入  /  方法  /  输出  /  假设与局限', 'Input  /  Method  /  Output  /  Assumption and Limitations')
        self.text(s, 7.6, .28, 7.85, .24, nav, 10.2, MUTED, False, PP_ALIGN.RIGHT)
        self.text(s, .55, .75, 14.9, .66, TITLES[self.lang][num-1], 34, NAVY, True)
        self.text(s, .58, 1.46, 14.8, .31, subtitle, 14.1, MUTED)
        self.line(s, .55, 8.57, 15.45, 8.57, BORDER, .8)
        self.text(s, .55, 8.68, 13.9, .21, self.pick('项目计划书 · 真实数据与受控仿真分别报告；共享与规划效果仍待验证。', 'Research proposal · Real and simulated evidence reported separately; sharing and planning remain to be validated.'), 9.5, MUTED)
        self.text(s, 14.55, 8.66, .9, .25, f'{num:02d} / 03', 10.8, TEAL, True, PP_ALIGN.RIGHT)
        note = '\n\n'.join(h + '\n\n' + '\n\n'.join(ps) for h, ps in SCRIPT[self.lang][num-1])
        s.notes_slide.notes_text_frame.text = note
        return s

    def slide_one(self):
        s = self.heading(1, self.pick('从已有地图与车辆观测出发，判断变化、分层更新，再发布给其他车辆使用。', 'Use map and vehicle evidence to assess changes, update the appropriate layer, and share updates with another vehicle.'))
        self.box(s, .55, 1.99, 4.34, 5.22, NAVY)
        self.text(s, .82, 2.20, 3.8, .40, self.pick('输入', 'Input'), 23, WHITE, True)
        self.road(s, .88, 2.86, 3.66, 1.22)
        self.car(s, 1.15, 3.28, BLUE, .8)
        self.box(s, 3.60, 3.11, .18, .47, CORAL, kind=MSO_SHAPE.RECTANGLE)
        self.line(s, 2.18, 3.48, 3.37, 3.35, GOLD, 2)
        inputs = [
            self.pick('已有地图与车辆道路观测', 'Existing map and vehicle observations'),
            self.pick('可靠性、持续性与几何证据', 'Reliability, persistence and geometry evidence'),
            self.pick('已采集序列可按时间驱动测试', 'Recorded sequences can supply time-ordered test inputs'),
        ]
        for i, text in enumerate(inputs):
            self.box(s, .87, 4.46 + i*.75, .07, .30, ['78D9C3','9FC8EC','E1BD70'][i], kind=MSO_SHAPE.RECTANGLE)
            self.text(s, 1.12, 4.42+i*.75, 3.47, .57, text, 15.4, WHITE)
        self.text(s, 5.20, 2.10, 9.9, .42, self.pick('方法', 'Method'), 23, TEAL, True)
        rows = [
            (GOLD, self.pick('临时障碍：及时共享到事件层', 'Temporary events: verify and share promptly'), self.pick('经核验后记录影响区域、观测时间、有效状态与来源，不必等待长期性确认。', 'Record affected area, observation time, validity and provenance; do not wait for long-term confirmation.')),
            (TEAL, self.pick('结构变化：通过检查后更新基础地图', 'Structural changes: check, then update the base map'), self.pick('检查可靠性、跨访问持续性、对象与完整观测几何；保留版本、证据和回退。', 'Check reliability, independent visits, target and observed geometry; retain versions, evidence and rollback.')),
            (MUTED, self.pick('证据不足：保留待核实状态', 'Unresolved evidence: retain and collect more'), self.pick('继续收集证据，不据此改写基础地图几何。', 'Collect more evidence without rewriting base-map geometry on unresolved observations.')),
            (BLUE, self.pick('发布与使用：核对版本、时效，再规划', 'Publish and use: check version and freshness, then replan'), self.pick('发布对象、图层、时间与来源；核实不可通行时避开或报无解，部分占用结合本车感知处理。', 'Publish object, layer, time and source. Avoid confirmed impassability or report no plan; assess partial occupancy locally.')),
        ]
        for i, (color, title, body) in enumerate(rows):
            y = 2.66+i*1.13
            self.box(s, 5.18, y, 10.27, 1.02, WHITE, BORDER)
            self.box(s, 5.39, y+.19, .44, .44, color, kind=MSO_SHAPE.OVAL)
            self.text(s, 5.39, y+.255, .44, .28, str(i+1), 15.2, WHITE, True, PP_ALIGN.CENTER)
            self.text(s, 6.03, y+.12, 9.11, .30, title, 16.1, color, True)
            self.text(s, 6.03, y+.53, 9.10, .42, body, 12.9, INK)
        self.box(s, .55, 7.46, 14.90, .83, MINT)
        self.text(s, .80, 7.57, 14.4, .24, self.pick('方法中的对照实验：相同本车感知、起终点与可行性检查', 'Controlled comparisons: identical local observations, start/goal settings and feasibility checks'), 12.8, TEAL, True)
        self.text(s, .80, 7.95, 14.4, .24, self.pick('不使用共享更新   →   共享候选采用固定惩罚   →   使用可靠性与分层更新', 'No shared updates   →   Fixed penalties for shared candidates   →   Reliability-aware layered updates'), 13.8, INK)

    def slide_two(self):
        s = self.heading(2, self.pick('输出包括可视化、可追踪的共享记录、接收车辆的规划响应，以及配套评估结果。', 'Outputs include visualisations, traceable sharing records, the receiving planner’s response, and evaluation results.'))
        self.box(s, .55, 1.98, 14.90, 1.04, NAVY)
        self.text(s, .82, 2.12, 14.35, .80, self.pick(
            '我们的最终证据将是共享地图更新与复用的端到端演示及受控对照实验：\n一辆车发现的变化，经判断、分层更新与发布后，被另一辆车获取并用于重新规划。',
            'Our final evidence will be an end-to-end demonstration and controlled comparisons showing how a change\nobserved by one vehicle is assessed, added to a shared map, published, and used by another vehicle for replanning.'), 17.2, WHITE)
        titles = [self.pick('地图更新与可视化', 'Map updates and visualisation'), self.pick('共享与接收记录', 'Publication and receipt records'), self.pick('规划响应与评估结果', 'Planning response and evaluation')]
        bodies = [
            self.pick('展示地图前后差异、临时事件、支持证据、修改原因、版本与回退记录。', 'Show map differences, temporary events, supporting evidence, update reasons, versions and rollback history.'),
            self.pick('展示发布、接收与应用状态，核对接收端是否获得正确版本。', 'Show publication, receipt and application states; verify that the receiver applies the correct version.'),
            self.pick('展示另一车辆的路线响应；核实不可通行时避开受影响通路，或报告无可行方案。', 'Show another vehicle’s route response; avoid confirmed impassable routes or report no feasible plan.'),
        ]
        metrics = [
            self.pick('错误更新比例 · 更新覆盖率\n几何误差 · 更新延迟', 'False-update rate · Update coverage\nGeometry error · Update delay'),
            self.pick('发布→应用延迟 · 版本一致性\n重复 / 过期处理 · 回退传播', 'Publication-to-application latency\nVersions · Duplicates · Expiry · Rollback'),
            self.pick('可行路线比例 · 路线长度\n无可行方案与失败原因', 'Feasible-route rate · Route length\nNo-feasible-plan outcomes and reasons'),
        ]
        for i, color in enumerate([TEAL, BLUE, CORAL]):
            x = .55+i*5.07
            self.box(s, x, 3.24, 4.76, 4.12, WHITE, BORDER)
            self.text(s, x+.24, 3.43, 4.28, .35, titles[i], 17.0, color, True)
            if i == 0:
                for j, text in enumerate([self.pick('临时事件层','Temporary event layer'), self.pick('版本化基础地图','Versioned base map'), self.pick('证据与回退记录','Evidence and rollback history')]):
                    self.box(s, x+.45, 4.00+j*.34, 3.86, .28, [MINT,'E9F0F8','F0F3F7'][j])
                    self.text(s, x+.53, 4.025+j*.34, 3.70, .22, text, 10.9, color, True, PP_ALIGN.CENTER)
            elif i == 1:
                self.box(s, x+.35, 4.00, 4.06, .96, NAVY)
                self.text(s, x+.50, 4.21, 3.76, .30, self.pick('发布 → 接收 → 应用', 'Publish → Receive → Apply'), 15.8, WHITE, True, PP_ALIGN.CENTER)
                self.text(s, x+.50, 4.65, 3.76, .20, self.pick('对象 · 版本 · 时间 · 来源', 'Object · Version · Time · Source'), 10.3, 'BDEDDD', False, PP_ALIGN.CENTER)
            else:
                self.road(s, x+.40, 4.00, 3.96, .98)
                self.car(s, x+.62, 4.39, TEAL, .57)
                self.box(s, x+2.43, 4.49, .23, .24, CORAL, kind=MSO_SHAPE.RECTANGLE)
                points=[(x+1.36,4.63),(x+1.83,4.63),(x+2.08,4.27),(x+3.11,4.27),(x+3.58,4.63)]
                for a,b in zip(points,points[1:]):self.line(s,*a,*b,'76DFC3',2.5)
            self.text(s, x+.24, 5.24, 4.28, .91, bodies[i], 13.9, INK)
            self.line(s, x+.24, 6.27, x+4.52, 6.27, BORDER, .8)
            self.text(s, x+.24, 6.47, 4.28, .66, metrics[i], 14.0, color, True)
        self.box(s, .55, 7.58, 14.90, .68, MINT)
        self.text(s, .80, 7.70, 14.40, .45, self.pick('同时统计应更新却未更新的变化；检查真实发布、接收、应用记录。零写入或上传图标不足以证明成功。', 'Count eligible changes left unapplied and inspect actual publication, receipt and application logs. Zero writes or an upload icon do not establish success.'), 13.2, TEAL, True)
        self.text(s, .59, 8.33, 14.80, .19, self.pick('图中共享与路线为计划示意，尚不是实测规划结果。', 'Sharing and route graphics illustrate the planned demonstration, not measured planner outputs.'), 9.7, MUTED)

    def slide_three(self):
        s = self.heading(3, self.pick('明确演示成立的条件、已有与待完成内容，以及证据能够支持的结论范围。', 'State the conditions for the demonstration, existing and unfinished work, and the limits of the evidence.'))
        self.text(s, .58, 2.00, 7.22, .40, self.pick('假设与验证条件', 'Assumption and validation conditions'), 21.0, TEAL, True)
        rows=[
            (self.pick('共享必须实际发生', 'Sharing must actually occur'), self.pick('可用两个独立客户端代表车辆，但必须实际发布、接收、应用更新，并核对接口、版本与时效。', 'Two independent clients may represent vehicles, but updates must actually be published, received and applied, with interface, version and freshness checks.')),
            (self.pick('对照条件保持一致', 'Comparisons use matching conditions'), self.pick('相同本车感知、起终点与可行性检查；路线长度只在双方均可行的样本上比较。', 'Use identical local observations, start/goal and feasibility checks. Compare route lengths only where both policies are feasible.')),
            (self.pick('证据解释有边界', 'Evidence has interpretation limits'), self.pick('过期或缺测不代表道路恢复；持续占用不自动等于结构变化；候选不直接等于整条道路封闭。', 'Expiry or missing data do not prove clearance. Persistent occupancy is not automatically structural change; a candidate does not automatically close a road.')),
        ]
        for i,(title,body) in enumerate(rows):
            y=2.59+i*1.45
            self.box(s,.55,y,7.31,1.30,WHITE,BORDER)
            self.text(s,.81,y+.15,6.79,.32,title,17.0,TEAL,True)
            self.text(s,.81,y+.60,6.79,.62,body,13.5,INK)
        self.text(s,8.18,2.00,7.22,.40,self.pick('实施状态与局限','Implementation status and limitations'),21.0,NAVY,True)
        panels=[
            (2.59,1.30,TEAL,self.pick('已有原型','Current prototype'),self.pick('真实地图与观测接入；受控更新、版本管理与回退。','Real-map and observation intake; controlled updates, version management and rollback.')),
            (4.04,1.30,GOLD,self.pick('仍待完成与联调','Still to build and integrate'),self.pick('真实可靠性结果、发布与接收端、规划对照与真实复访。','Actual reliability outputs, publishing and receiving clients, planning comparisons and real revisits.')),
            (5.49,1.30,BLUE,self.pick('报告与展示方式','Reporting and presentation'),self.pick('真实数据与仿真分别报告；录制序列只是测试输入。图示为计划内容，是否改善由实验回答。','Report real and simulated evidence separately. Recorded sequences are test inputs; diagrams are planned outputs. Any improvement must be measured.')),
        ]
        for y,h,c,title,body in panels:
            self.box(s,8.14,y,7.31,h,WHITE,BORDER)
            self.text(s,8.40,y+.15,6.79,.32,title,17.0,c,True)
            self.text(s,8.40,y+.60,6.79,.62,body,13.5,INK)
        self.box(s,.55,7.26,14.90,1.00,NAVY)
        self.text(s,.82,7.42,14.35,.32,self.pick('这些证据支持测试条件下的地图维护、共享与复用结论。','The evidence supports conclusions about map maintenance, sharing and reuse under the tested conditions.'),16.8,WHITE,True)
        self.text(s,.82,7.92,14.35,.28,self.pick('不保证变化永久存在、兼容所有实车系统，或证明真实驾驶安全。','It does not guarantee permanence, compatibility with every production vehicle, or real-world driving safety.'),14.0,'DCEBF3')

    def save(self, folder):
        self.slide_one(); self.slide_two(); self.slide_three()
        for slide in self.p.slides:
            text='\n'.join(s.text for s in slide.shapes if s.has_text_frame)+'\n'+slide.notes_slide.notes_text_frame.text
            assert not re.search('[A-Za-z]' if self.cn else '[\u4e00-\u9fff]',text)
        name='共享地图_四部分结构_中文版.pptx' if self.cn else 'Shared_Map_Four_Sections_EN.pptx'
        self.p.save(folder/name)


def save_word(doc, path, lang):
    font='Noto Sans CJK SC' if lang=='zh' else 'Arial'
    for style in doc.styles:
        if not hasattr(style,'font'):continue
        fonts=style.element.get_or_add_rPr().get_or_add_rFonts()
        for key in list(fonts.attrib):
            if 'theme' in key.lower():del fonts.attrib[key]
        for slot in ('ascii','hAnsi','eastAsia','cs'):fonts.set(qn('w:'+slot),font)
    doc.save(path)


def documents(lang, folder):
    cn=lang=='zh'
    title='共享地图更新与复用：证据与评估' if cn else 'Shared-Map Updates and Reuse'
    subtitle='项目计划书｜输入、方法、输出、假设与局限' if cn else 'Proposal | Input, Method, Output, Assumption and Limitations'
    doc=document_base(lang,title,subtitle)
    normal=doc.styles['Normal'];normal.font.size=Pt(10.5)
    normal.paragraph_format.line_spacing=1.07
    normal.paragraph_format.space_after=Pt(4)
    doc.styles['Heading 1'].paragraph_format.space_before=Pt(7)
    for heading,paras in PROPOSAL[lang]:
        doc.add_heading(heading,1)
        for p in paras:doc.add_paragraph(p)
    name='共享地图_计划书_中文版' if cn else 'Shared_Map_Proposal_EN'
    save_word(doc,folder/(name+'.docx'),lang)
    md='# '+title+'\n\n'+'\n\n'.join('## '+h+'\n\n'+'\n\n'.join(ps) for h,ps in PROPOSAL[lang])
    (folder/(name+'.md')).write_text(md,encoding='utf-8')

    title='共享地图更新与复用：逐页讲稿' if cn else 'Shared-Map Updates and Reuse: Script'
    subtitle='对应三页演示｜约4至5分钟' if cn else 'Three corresponding slides | Approximately 4–5 minutes'
    doc=document_base(lang,title,subtitle)
    doc.styles['Normal'].font.size=Pt(11.5)
    doc.styles['Normal'].paragraph_format.line_spacing=1.10
    doc.styles['Normal'].paragraph_format.space_after=Pt(7)
    parts=[]
    for i,sections in enumerate(SCRIPT[lang]):
        if i:doc.add_page_break()
        page=(f'第{i+1}页｜' if cn else f'Slide {i+1} — ')+TITLES[lang][i]
        doc.add_heading(page,1)
        text=[page]
        for h,paras in sections:
            if i==0:doc.add_heading(h,2)
            text.append(h)
            for p in paras:doc.add_paragraph(p);text.append(p)
        parts.append('\n\n'.join(text))
    name='共享地图_讲稿_中文版' if cn else 'Shared_Map_Script_EN'
    save_word(doc,folder/(name+'.docx'),lang)
    plain='\n\n'.join(parts)
    (folder/(name+'.txt')).write_text(plain,encoding='utf-8')
    for text in (plain,md):assert not re.search('[A-Za-z]' if cn else '[\u4e00-\u9fff]',text)


if __name__=='__main__':
    for lang,sub in [('zh','中文'),('en','English')]:
        folder=OUT/sub;folder.mkdir(parents=True,exist_ok=True)
        StructuredDeck(lang).save(folder)
        documents(lang,folder)
        print('Generated:',sub,'3 slides, 4-section proposal, matching script')
    (OUT/'content_preservation.json').write_text(json.dumps(AUDIT,ensure_ascii=False,indent=2)+'\n')
