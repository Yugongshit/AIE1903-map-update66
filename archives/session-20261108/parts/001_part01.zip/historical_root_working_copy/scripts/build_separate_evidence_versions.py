"""Create separate English/Chinese decks, proposal sections, and speaking notes.

Uses the reviewed three-slide deck as a layout template. The original is retained.
Dependencies: python-pptx, python-docx, matplotlib. PDF export uses LibreOffice.
"""
from pathlib import Path
from copy import deepcopy
import json
import math
import re

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Polygon, FancyArrowPatch, FancyBboxPatch
from pptx import Presentation
from pptx.util import Pt
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.oxml.xmlchemy import OxmlElement as PptxElement
from docx import Document
from docx.shared import Inches, Pt as DocPt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'outputs/evidence_presentation'
OUT = BASE / 'separate_versions'
OUT.mkdir(parents=True, exist_ok=True)
TEMPLATE = BASE / 'AIE1903_Evidence_and_Evaluation.pptx'
FONT_CN = 'Noto Sans CJK SC'

CN = {
    'AIE1903  /  SHARED ROAD MAP MAINTENANCE': '课程项目  /  共享道路地图维护',
    'PLANNED EVIDENCE & EVALUATION': '证据展示与评估计划',
    'What Will We Show?': '我们的最终证据是什么？',
    'How Will We Evaluate It?': '我们将如何评估项目效果？',
    'What Can This Evidence Demonstrate?': '这些证据能够说明什么？',
    'Research proposal  •  Real-data and simulation evidence will be reported separately.': '项目计划书  ·  真实数据与仿真证据将分别报告。',
    'Our final evidence will be an offline replay and controlled comparisons showing how perception,\nreliability assessment, planning, and map maintenance work together.': '我们的最终证据将是一段离线回放，以及一组受控对照实验，\n展示感知、可靠性评估、路径规划与共享地图维护如何协同工作。',
    '01  Reference map': '01  参考道路地图',
    'Actual scene geometry': '来自真实场景的地图几何',
    'Keep source features and map IDs.': '保留原始地图要素及其编号，\n作为观测和决策的空间参照。',
    '02  Road observations': '02  道路观测证据',
    'Actual frame 0 evidence': '来自第零帧的实际观测',
    'Inspect lane curves and occupancy.': '叠加观测标线、占用轮廓\n及车辆位置，检查地图差异。',
    '03  Decision layers': '03  规划与地图决策',
    'Planned output concept': '计划中的输出形式示意',
    'Show routes, temporary events and\nevidence-gated map updates.': '展示路线、临时事件，\n以及通过证据检查的地图更新。',
    'Evidence the audience can inspect': '观众可以直接检查的证据',
    'SYNCHRONIZED REPLAY': '同步场景回放',
    'Compare the map, observations and decisions\nat the same scene time.': '在同一场景时间下，对比参考地图、\n道路观测和系统决策。',
    'TRACEABLE DECISIONS': '能够追溯的决策',
    'Show supporting evidence, uncertainty,\nand the reason for each action.': '展示支持证据、不确定性，\n以及每项决策的具体依据。',
    'VERSIONED MAP HISTORY': '保留版本的地图历史',
    'Separate temporary events from base-map\nchanges; record updates and rollback.': '区分临时事件与基础地图变化，\n记录更新内容和版本回退。',
    'ACTUAL FIGURES: nuScenes scene-0980. Dashed route in panel 03 is illustrative, not a tested planner output.': '实际配图：数据集第0980号场景。第三幅图的虚线路径仅为示意，尚不是经过测试的规划结果。',
    'Perception candidates': '感知变化候选',
    'Reliability assessment': '可靠性评估',
    'Planning  +  Shared-map maintenance': '路径规划  ＋  共享地图维护',
    'THREE QUESTIONS, WITH MEASURABLE EVIDENCE': '围绕三个问题，收集可衡量的评估证据',
    'Change assessment': '变化判断是否准确',
    'Are the candidates assessed correctly?': '系统能否正确判断候选变化及其可靠性？',
    'Precision / Recall / F1': '精确率 / 召回率 / 综合评分',
    'Planning': '规划决策是否有帮助',
    'Are routes feasible without needless detours?': '路线是否可行，同时避免不必要的绕行？',
    'Feasible route rate / Route length': '可行路线比例 / 路线长度',
    'Map maintenance': '地图是否被正确更新',
    'Do we avoid wrong updates and respond in time?': '能否减少错误写入，并及时处理已确认的变化？',
    'False-update rate / Geometry error / Update delay': '错误更新比例 / 几何误差 / 更新延迟',
    'Build a fair comparison': '采用公平的对照方法',
    'Use real observations and controlled\nchanges with known outcomes.': '结合真实场景观测，\n以及具有已知真值的受控变化。',
    'REAL SCENES': '真实场景',
    'Independent review where labels exist.': '对具有标注的样本开展独立核验。',
    'CONTROLLED SIMULATION': '受控仿真',
    'Known map changes and temporal patterns.': '设置已知地图变化和持续时间模式。',
    'Report these results separately.\nFix thresholds before testing; keep variants\nof the same scene in the same split.': '两类结果分别报告。\n测试前固定阈值，同一场景的变体\n应放在同一个数据划分中。',
    'PLANNING BASELINES  /  Same scenarios, same feasibility checks, different map-information policies': '三种规划对照  /  场景与可行性检查保持一致，仅改变地图变化信息的使用方式',
    'A': '一',
    'B': '二',
    'C': '三',
    'MAP ONLY': '仅使用参考地图',
    'Use the reference map\nwithout candidate penalties.': '以参考地图为依据，\n不加入变化候选惩罚。',
    'FIXED PENALTY': '采用固定惩罚',
    'Apply the same added cost\nto every change candidate.': '对每一个变化候选，\n施加相同的额外代价。',
    'RELIABILITY-AWARE': '依据可靠性调整',
    'Adapt planning decisions\nto the assessed evidence.': '根据可靠性评估结果，\n调整规划决策。',
    'WHAT IT CAN SUPPORT': '能够支持的结论',
    'WHAT REMAINS UNPROVEN': '尚不能证明的结论',
    'Integration': '模块能够协同运行',
    'Modules exchange consistent geometry,\ntimestamps and decisions.': '各模块能够交换一致的几何信息、\n时间戳与决策结果。',
    'Decision quality': '测试场景中的决策质量',
    'Compare feasible routes and incorrect\nmap updates within tested scenarios.': '比较测试场景中的路线可行性，\n以及错误地图更新的情况。',
    'Traceability': '决策过程能够解释',
    'Explain why evidence led to a temporary\nevent, further review or a map update.': '解释为什么保留为临时事件、\n继续核验，或允许更新基础地图。',
    'Permanence': '变化会永久存在',
    'Repeated observations do not guarantee\nthat a change will last forever.': '即使多次观察到同一变化，\n也不能保证它会永久存在。',
    'Probability or causation': '准确概率或因果关系',
    'A high score is not a calibrated probability;\nnearby behaviour is not a causal explanation.': '高分不等于校准后的真实概率；\n附近车辆行为也不能直接证明因果。',
    'Real-world driving safety': '真实自动驾驶安全',
    'Offline tests do not establish safety\nin closed-loop autonomous driving.': '离线测试尚不能验证真实驾驶中\n感知、决策与控制闭环的安全性。',
    'PERSISTENCE NEEDS EVIDENCE ACROSS TIME': '判断长期变化，需要跨时间的证据',
    'One observed pass': '现有资料：一次经过',
    'Current scene: 41 frames, about 20 s.\nSupports candidates, not permanence.': '当前场景共41帧，约20秒。\n可以支持变化候选，\n不足以证明长期变化。',
    'Independent revisits OR labelled temporal simulation': '独立重复访问，或明确标注的时序仿真',
    'Visit 1': '首次',
    'Later visit': '后续',
    'Illustrative timeline — not collected revisit results.': '时间线仅用于说明方法，并非已采集的复访结果。',
    'MAP-UPDATE GATE': '基础地图写入条件',
    'Reliability + persistence + geometry\nchecks must pass before writing.': '可靠性、持续性与几何检查\n全部通过后，才允许写入。',
}

EN = {
    '我们会展示什么？从道路观测，到可解释的规划与地图维护。': 'From road observations to explainable planning and map maintenance.',
    '我们怎么评估？判断是否准确，规划是否有帮助，地图是否被正确更新。': 'Assess correctness, planning usefulness, and map-update quality.',
    '这些证据能说明什么？验证测试场景中的表现，并清楚界定结论范围。': 'Evaluate performance in tested scenarios and define the limits of the claims.',
    '我们的目标：证明方法在已测试场景中是否有效，而不是证明变化永久存在或真实驾驶安全。': 'Our goal: assess effectiveness within tested scenarios, with conclusions limited to the available evidence.',
}

TITLES = {
    'en': ['What Will We Show?', 'How Will We Evaluate It?', 'What Can This Evidence Demonstrate?'],
    'zh': ['我们的最终证据是什么？', '我们将如何评估项目效果？', '这些证据能够说明什么？'],
}

NOTES = {
    'en': [
        [
            'Our final evidence will be an offline replay and controlled comparisons showing how perception, reliability assessment, planning, and map maintenance work together. The aim is to make the decision process visible, from a road observation to a planning response or a map decision.',
            'The first two images use our current scene data. The first shows the reference map; the second adds observed lane curves, occupancy outlines, and vehicle positions. The third image illustrates a planned output. Its dashed route is a concept, not an evaluated planning result.',
            'In the final demo, the audience should be able to follow the same event through time. We will show what evidence supports it, what remains uncertain, and why the system keeps it as a temporary event, requests further review, or allows a base-map update. Version records will show what changed and support rollback.',
            'We already have map geometry and frame-level replay material. The integrated reliability module, planning comparison, and persistence evaluation are planned work. The next slide explains how we will measure their performance.',
        ],
        [
            'Our evaluation asks three questions. First, are the change candidates assessed correctly? With independent reference labels, we will report precision, recall, and F1. A high rule-based score by itself is not a correct label.',
            'Second, does the information help planning? We will compare three versions: map only, a fixed penalty for every candidate, and a reliability-aware policy. Each version will use the same scenarios and feasibility checks. We will compare the proportion of feasible routes and their lengths, while reporting failed routes separately.',
            'Third, does map maintenance avoid incorrect writes and respond to confirmed changes? We will measure incorrect updates, geometric error, and update delay. We will also report how many eligible changes are actually updated, so doing nothing cannot appear successful simply because it produces no wrong writes.',
            'Real observations and controlled simulations will be reported separately. Thresholds will be chosen before testing, and variants of one scene will remain in the same split. Unlabelled examples will remain unlabelled. This is our evaluation plan; we are not presenting accuracy numbers that have already been measured.',
        ],
        [
            'The evidence can support three bounded conclusions: whether the modules integrate correctly, how the decisions perform in tested scenarios, and whether each decision can be traced back to its supporting evidence.',
            'The timeline explains the key issue in our map-update module. Our current scene contains 41 frames over about 20 seconds, all from one pass. Observing an object throughout that short sequence does not establish a long-term change. We need independent revisits, or explicitly labelled temporal simulations with known outcomes, to test persistence rules. The later visits drawn here are illustrations, not collected results.',
            'We will define persistence over an observation window and apply reliability, persistence, and geometry checks before allowing a base-map write. Unresolved events can remain in a temporary layer.',
            'The evidence will not prove that a change lasts forever, that a heuristic score is a calibrated probability, or that nearby vehicle behaviour was caused by the map discrepancy. Offline tests also cannot establish real-world driving safety. Our claim is limited to integration and measured performance under the stated test conditions.',
        ],
    ],
    'zh': [
        [
            '我们的最终证据将是一段离线回放，以及一组受控对照实验，展示感知、可靠性评估、路径规划和共享地图维护如何协同工作。我们希望让大家看清楚：一个道路观测，怎样一步步影响规划和地图决策。',
            '左边前两幅图来自目前已有的场景数据。第一幅是参考道路地图；第二幅叠加了观测标线、占用轮廓和车辆位置。第三幅是未来输出形式的示意图，其中的虚线路径尚不是经过评估的规划结果。',
            '在最终演示中，观众应该能够沿着时间线追踪同一个事件：有哪些证据支持它，哪些地方仍不确定，以及系统为什么把它保留为临时事件、要求继续核验，或者允许更新基础地图。地图版本记录还会展示修改内容，并支持回退。',
            '目前我们已经具备地图几何与逐帧回放资料。完整的可靠性模块接入、规划对照和持续性评估仍属于计划中的工作。下一页将说明，我们准备怎样衡量它们的效果。',
        ],
        [
            '我们的评估分成三个问题。第一，变化候选判断得准不准？对具有独立参考标注的样本，计算精确率、召回率，以及两者调和平均得到的综合评分。规则分数很高，并不代表判断一定正确。',
            '第二，这些信息是否有助于规划？我们比较三种方案：仅使用参考地图；对全部候选施加相同惩罚；根据可靠性结果调整决策。三组使用相同的场景与可行性检查，再比较可行路线比例和路线长度，失败的路线会单独报告。',
            '第三，地图能否减少错误写入，并及时处理已经确认的变化？我们统计错误更新、几何误差和更新延迟，还会报告符合条件的变化中有多少真正完成了更新。这样就不会出现“什么都不更新，所以看起来没有错误”的误导。',
            '真实观测与受控仿真分开报告，测试前固定阈值，同一个场景的不同变体留在同一数据划分中。没有独立标注的样本不会被自动当作负例。这一页介绍的是评估计划，尚没有填入已经测得的准确率或提升幅度。',
        ],
        [
            '这些证据能够支持三类有限而具体的结论：各模块能否正确协同；系统在测试场景中的决策表现如何；每项决策能否追溯到相应证据。',
            '下方时间线解释了地图更新模块最关键的问题。我们目前的场景只有一次经过，共41帧，约20秒。某个物体在这段短序列里一直出现，仍然不足以证明它属于长期变化。我们需要独立的重复访问，或者明确标注、具有已知结果的时序仿真，来检验持续性规则。图中的后续访问只是方法示意，并不是已经采集到的复访结果。',
            '我们会在预先设定的观察窗口内定义持续性。只有可靠性、持续性和几何检查都通过后，才允许修改基础地图；证据不足的事件可以继续留在临时图层。',
            '这些证据不能证明变化会永久存在，不能把规则分数解释为校准后的真实概率，也不能因为附近车辆出现某种行为，就认定它由地图差异导致。离线测试同样不能证明真实自动驾驶安全。我们最终的结论会限定在说明清楚的测试条件和实际获得的证据范围内。',
        ],
    ],
}

PROPOSAL = {
    'en': [
        ('Final evidence', [
            'Our final evidence will be an offline replay and controlled comparisons showing how perception, reliability assessment, planning, and shared-map maintenance work together to respond to road-map discrepancies.',
            'The replay will align the reference map, observed lane markings, occupancy candidates, reliability decisions, and planning outputs in space and time. It will show why an event remains temporary, requires further review, or qualifies for a versioned base-map update. Decision histories and rollback records will make the process inspectable.',
        ]),
        ('Evaluation design', [
            'We will evaluate candidate assessment using precision, recall, and F1 on independently labelled cases. Planning will compare map-only, fixed-penalty, and reliability-aware policies under the same scenarios and feasibility checks. We will report feasible-route rate, route length, and failures; route-length comparisons will use cases in which both compared policies find a feasible route.',
            'For map maintenance, we will report incorrect writes, false-update rate, geometry error against independent reference geometry, and update delay from the first qualifying observation. We will also report eligible-update coverage, including changes still awaiting an update. With no writes, false-update rate is undefined, not evidence of perfect accuracy. Version and rollback checks will assess traceability.',
        ]),
        ('Test conditions', [
            'Real observations and controlled simulations with known outcomes will be reported separately. Thresholds, temporal windows, and geometric matching criteria will be fixed before testing; variants of one scene will remain in the same data split. Unlabelled cases will not be treated as negatives. Persistent and temporary changes will be tested using independent revisits where available and clearly labelled temporal simulations; simulated persistence will not be claimed as a real-world observation.',
        ]),
        ('What the evidence will and will not demonstrate', [
            'The evidence will show whether the modules integrate coherently, how their decisions perform within the tested scenarios, and whether map actions can be traced to supporting observations. It can test whether reliability and persistence checks reduce incorrect updates or improve planning relative to the stated baselines; any improvement remains an empirical question.',
            'It will not establish permanent change from repeated frames in a single pass, calibrate heuristic scores as probabilities, show that nearby vehicle behaviour is caused by a map discrepancy, or establish real-world closed-loop driving safety. The current scene contains 41 frames over approximately 20 seconds from one pass, so it supports an integration example rather than a claim of long-term change. Broader generalisation requires additional independently labelled scenes and revisits.',
        ]),
    ],
    'zh': [
        ('最终证据', [
            '我们的最终证据将是一段离线回放，以及一组受控对照实验，展示感知、可靠性评估、路径规划与共享地图维护如何协同应对道路地图差异。',
            '回放将在统一的空间与时间基准下，展示参考地图、观测标线、占用候选、可靠性判定和规划输出，并解释为什么一个事件保留为临时事件、需要继续核验，或符合带版本记录的基础地图更新条件。决策历史和回退记录将使整个过程能够被检查与追溯。',
        ]),
        ('评估设计', [
            '变化判断将在具有独立标注的样本上，以精确率、召回率及两者调和平均得到的综合评分进行评估。规划部分将在相同场景与可行性检查条件下，比较仅使用参考地图、固定惩罚和依据可靠性调整三种方案，报告可行路线比例、路线长度与失败情况；路线长度比较只使用被比较的两种方案均获得可行路线的样本。',
            '地图维护将统计错误写入次数、错误更新比例、相对独立参考几何的误差，以及从首次符合条件的观测到更新的延迟。同时报告符合条件的变化中有多少完成了更新，并保留仍未更新的案例。没有发生写入时，错误更新比例不可计算，不能解释为准确率完美。版本与回退检查将用于验证可追溯性。',
        ]),
        ('测试条件', [
            '真实观测与具有已知结果的受控仿真将分别报告。阈值、时间窗口和几何匹配标准将在测试前固定，同一场景的不同变体保留在同一数据划分中；未标注案例不会被自动视为负例。长期与短期变化将通过可获得的独立重复访问，以及明确标注的时序仿真进行检验，仿真中的持续性不会被当作现实中的复访观测。',
        ]),
        ('证据能够与不能够支持的结论', [
            '这些证据将说明各模块能否一致地协同运行、系统在已测试场景中的决策表现，以及地图操作能否追溯至支持观测。通过与上述对照方案比较，可以检验可靠性和持续性检查是否减少错误更新或改善规划，但是否存在提升仍需由实验结果回答。',
            '这些证据不能仅凭一次经过中的连续帧证明变化永久存在，不能把规则分数视为校准后的概率，不能证明附近车辆行为由地图差异导致，也不能证明真实自动驾驶闭环安全。当前场景只有一次经过，共41帧、约20秒，适合作为模块集成案例，不足以支持长期变化结论。更广泛的推广仍需要更多独立标注场景和重复访问。',
        ]),
    ],
}


def chinese_figures():
    """Regenerate the source-data plots with Chinese-only annotations."""
    scene = json.loads((ROOT/'outputs/scene0980-map-replay/scene.json').read_text())
    # Matplotlib resolves the first face of a TTC collection, unlike fontconfig.
    # Register the installed CJK faces explicitly to avoid missing-glyph fallback.
    font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    font_manager.fontManager.addfont(font_path)
    font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc')
    plt.rcParams['font.family'] = font_manager.FontProperties(fname=font_path).get_name()
    paths = []
    for observed, name in [(False, '参考地图'), (True, '道路观测')]:
        fig, ax = plt.subplots(figsize=(4.2, 4.4), dpi=220)
        fig.patch.set_facecolor('#112C40'); ax.set_facecolor('#112C40')
        for e in scene['reference_map']['elements']:
            g, layer = e['geometry_city'], e['layer']
            if g['type'] == 'Polygon':
                fill = {'road_segment': '#193E50', 'lane': '#214E5B', 'lane_connector': '#1A4557', 'ped_crossing': '#58707A'}.get(layer, '#193E50')
                ax.add_patch(Polygon(g['coordinates'][0], facecolor=fill, edgecolor='#6392A0', linewidth=.65, alpha=.8, zorder=1))
            else:
                p = g['coordinates']
                ax.plot([x[0] for x in p], [x[1] for x in p], color='#8ADACB' if layer == 'lane_divider' else '#A8BBC2', lw=1.8, zorder=3)
        frame = scene['replay'][0]
        if observed:
            for item in frame['observed_lines']:
                p = item['geometry_city']['coordinates']
                ax.plot([x[0] for x in p], [x[1] for x in p], color='#FFD16F', lw=3.3, zorder=7)
            for item in frame['occupancy']:
                for obj in item['objects']:
                    ax.add_patch(Polygon(obj['geometry_city']['coordinates'][0], facecolor='#ED8D77', edgecolor='#FFCEBE', lw=.8, zorder=6))
            for v in frame['vehicles']:
                ax.scatter(*v['xy'], s=28, c='#A5C8FF', edgecolors='white', linewidth=.6, zorder=8)
            x, y = frame['ego']['xy']; a = math.radians(frame['ego']['yaw_deg'])
            ax.scatter(x, y, s=65, c='#70E8C7', edgecolors='white', zorder=10)
            ax.add_patch(FancyArrowPatch((x, y), (x+4*math.cos(a), y+4*math.sin(a)), arrowstyle='-|>', color='#70E8C7', mutation_scale=15, lw=2, zorder=10))
        ax.set_xlim(420, 457); ax.set_ylim(1228, 1280); ax.set_aspect('equal')
        ax.plot([423, 433], [1231, 1231], color='white', lw=1.5)
        ax.text(428, 1232, '10米', color='white', fontsize=8, ha='center')
        ax.annotate('北', xy=(453,1274), xytext=(453,1268), color='white', ha='center', fontsize=10, arrowprops={'arrowstyle':'->','color':'white'})
        ax.axis('off'); fig.subplots_adjust(0, 0, 1, 1)
        path = OUT/'中文'/f'{name}.png'; path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, facecolor=fig.get_facecolor(), dpi=220); plt.close(fig); paths.append(path)
    fig, ax = plt.subplots(figsize=(4.2,4.4), dpi=220)
    fig.patch.set_facecolor('#112C40'); ax.set_facecolor('#112C40')
    ax.add_patch(Polygon([[.5,0],[3.5,0],[3.5,6],[.5,6]],color='#27495A'))
    for x in [.5,3.5]: ax.plot([x,x],[0,6],color='#9CD3D1',lw=2)
    ax.plot([2,2],[0,6],color='#8AABB7',lw=1.3,ls=(0,(5,5)))
    for y in [2.65,3.05,3.45]:
        ax.add_patch(Polygon([[2.15,y],[3.05,y],[3.05,y+.16],[2.15,y+.16]],facecolor='#EB8B75',edgecolor='#FFD0C4',lw=.9))
    ax.plot([2.75,2.75,1.25,1.25,2.75,2.75],[.6,1.5,2.1,4.05,4.8,5.3],ls='--',lw=2.6,color='#8FDCCB')
    ax.annotate('',xy=(2.75,5.65),xytext=(2.75,5.15),arrowprops={'arrowstyle':'-|>','color':'#8FDCCB','lw':2,'mutation_scale':16})
    ax.add_patch(FancyBboxPatch((2.42,.35),.66,.95,boxstyle='round,pad=.02,rounding_size=.12',fc='#E7F5F6',ec='#AFCDD9',lw=1.2,zorder=8))
    ax.add_patch(FancyBboxPatch((2.49,.82),.52,.28,boxstyle='round,pad=.01,rounding_size=.05',fc='#6C9CAE',ec='none',zorder=9))
    ax.text(2.,5.95,'计划中的输出示意',ha='center',va='top',color='#FFD16F',fontsize=11,fontweight='bold')
    ax.text(2.,-.18,'路线 / 临时事件 / 地图写入条件',ha='center',color='#D9E8EC',fontsize=8.4)
    ax.set_xlim(0,4); ax.set_ylim(-.45,6.35); ax.set_aspect('equal'); ax.axis('off'); fig.subplots_adjust(0,0,1,1)
    path = OUT/'中文'/'决策示意.png'
    fig.savefig(path,facecolor=fig.get_facecolor(),dpi=220); plt.close(fig); paths.append(path)
    return paths


def replace_text(shape, value, lang):
    """Keep the reviewed paragraph styles while replacing text and font language."""
    tf = shape.text_frame
    prototype = tf.paragraphs[0]._p
    ppr = deepcopy(prototype.pPr) if prototype.pPr is not None else None
    tf.clear()
    for i, part in enumerate(value.split('\n')):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        if p._p.pPr is not None: p._p.remove(p._p.pPr)
        if ppr is not None: p._p.insert(0, deepcopy(ppr))
        p.text = part
        p.font.name = FONT_CN if lang == 'zh' else 'Arial'
        rpr = p._p.get_or_add_pPr().get_or_add_defRPr()
        rpr.set('lang', 'zh-CN' if lang == 'zh' else 'en-US')
        ea = rpr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}ea')
        if ea is None: ea = PptxElement('a:ea'); rpr.append(ea)
        ea.set('typeface', FONT_CN if lang == 'zh' else 'Arial')


def build_deck(lang, images):
    p = Presentation(TEMPLATE)
    folder = OUT / ('English' if lang == 'en' else '中文')
    folder.mkdir(parents=True, exist_ok=True)
    translations = CN if lang == 'zh' else EN
    for i, slide in enumerate(p.slides):
        for sh in slide.shapes:
            if sh.has_text_frame and sh.text:
                old = sh.text
                if lang == 'zh' and re.search('[A-Za-z]', old) and old not in CN:
                    raise ValueError(f'Missing Chinese translation: {old}')
                replace_text(sh, translations.get(old, old), lang)
                if old.startswith('Our final evidence will be'):
                    sh.top -= Pt(6)
                    sh.height += Pt(6)
        slide.notes_slide.notes_text_frame.text = '\n\n'.join(NOTES[lang][i])
        for para in slide.notes_slide.notes_text_frame.paragraphs:
            para.font.name = FONT_CN if lang == 'zh' else 'Arial'
        visible = '\n'.join(sh.text for sh in slide.shapes if sh.has_text_frame)
        combined = visible + slide.notes_slide.notes_text_frame.text
        assert not re.search('[A-Za-z]' if lang == 'zh' else '[\u4e00-\u9fff]', combined)
    if lang == 'zh':
        pics = [sh for sh in p.slides[0].shapes if sh.shape_type == MSO_SHAPE_TYPE.PICTURE]
        assert len(pics) == 3
        for old, path in zip(pics, images):
            new = p.slides[0].shapes.add_picture(str(path), old.left, old.top, old.width, old.height)
            el = old._element; parent = el.getparent(); index = parent.index(el)
            parent.remove(new._element); parent.insert(index, new._element); parent.remove(el)
    p.core_properties.title = 'Evidence and Evaluation' if lang == 'en' else '证据展示与评估'
    p.core_properties.subject = 'Research proposal presentation' if lang == 'en' else '项目计划书展示'
    p.core_properties.author = 'AIE1903 Project Team' if lang == 'en' else '课程项目小组'
    name = 'AIE1903_Evidence_Evaluation_EN.pptx' if lang == 'en' else '证据与评估_中文版.pptx'
    p.save(folder/name)
    return folder


def document_base(lang, title, subtitle):
    doc = Document(); sec = doc.sections[0]
    sec.page_width = Inches(8.27); sec.page_height = Inches(11.69)
    sec.top_margin = Inches(.65); sec.bottom_margin = Inches(.65)
    sec.left_margin = Inches(.72); sec.right_margin = Inches(.72)
    sec.header_distance = Inches(.28); sec.footer_distance = Inches(.28)
    font = FONT_CN if lang == 'zh' else 'Arial'
    for style_name in ['Normal','Title','Subtitle','Heading 1','Heading 2']:
        style = doc.styles[style_name]; style.font.name = font
        style.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),font)
        language = OxmlElement('w:lang'); language.set(qn('w:val'),'zh-CN' if lang == 'zh' else 'en-US')
        language.set(qn('w:eastAsia'),'zh-CN' if lang == 'zh' else 'en-US')
        style.element.get_or_add_rPr().append(language)
    normal = doc.styles['Normal']; normal.font.size = DocPt(10.5 if lang=='en' else 10.5)
    normal.font.color.rgb = RGBColor.from_string('22384A')
    normal.paragraph_format.line_spacing = 1.13
    normal.paragraph_format.space_after = DocPt(6)
    normal.paragraph_format.widow_control = True
    for key, size in [('Title',23),('Heading 1',13),('Heading 2',11)]:
        st = doc.styles[key]; st.font.size = DocPt(size); st.font.color.rgb = RGBColor.from_string('087F8C')
        st.paragraph_format.space_before = DocPt(9 if key!='Title' else 0)
        st.paragraph_format.space_after = DocPt(5)
    header = sec.header.paragraphs[0]
    header.text = 'AIE1903  |  SHARED ROAD MAP MAINTENANCE' if lang=='en' else '课程项目  |  共享道路地图维护'
    header.runs[0].font.size=DocPt(8); header.runs[0].font.color.rgb=RGBColor.from_string('617485')
    footer=sec.footer.paragraphs[0]; footer.alignment=2
    footer.add_run('Page ' if lang=='en' else '第 ')
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');footer._p.append(field)
    if lang=='zh':footer.add_run(' 页')
    doc.add_heading(title,0)
    p=doc.add_paragraph(subtitle);p.paragraph_format.space_after=DocPt(8)
    p.runs[0].font.size=DocPt(10);p.runs[0].font.color.rgb=RGBColor.from_string('617485')
    doc.core_properties.title=title
    doc.core_properties.author='AIE1903 Project Team' if lang=='en' else '课程项目小组'
    doc.core_properties.language='en-US' if lang=='en' else 'zh-CN'
    return doc


def build_documents(lang, folder):
    title = 'Evidence and Evaluation' if lang=='en' else '证据展示与评估'
    subtitle = 'Proposal section | Planned demonstration, evaluation and claim boundaries' if lang=='en' else '项目计划书正文｜最终展示、评估方法与结论范围'
    doc = document_base(lang,title,subtitle)
    for heading, paras in PROPOSAL[lang]:
        doc.add_heading(heading,1)
        for value in paras:doc.add_paragraph(value)
    stem='Proposal_Evidence_Evaluation_EN' if lang=='en' else '项目计划书_证据与评估_中文版'
    doc.save(folder/(stem+'.docx'))
    md='# '+title+'\n\n'+'\n\n'.join('## '+h+'\n\n'+'\n\n'.join(ps) for h,ps in PROPOSAL[lang])
    (folder/(stem+'.md')).write_text(md,encoding='utf-8')
    title='Presentation Script' if lang=='en' else '三页演示讲稿'
    subtitle='Three slides | Approximately 4–5 minutes in total' if lang=='en' else '对应三页演示｜总时长约4至5分钟'
    doc = document_base(lang,title,subtitle)
    for i, paras in enumerate(NOTES[lang]):
        if i:doc.add_page_break()
        prefix=f'Slide {i+1} — ' if lang=='en' else f'第{i+1}页｜'
        doc.add_heading(prefix+TITLES[lang][i],1)
        for value in paras:
            para=doc.add_paragraph(value);para.paragraph_format.space_after=DocPt(12)
            for run in para.runs:run.font.size=DocPt(12)
    stem='Speaker_Notes_EN' if lang=='en' else '逐页讲稿_中文版'
    doc.save(folder/(stem+'.docx'))
    plain='\n\n'.join((f'Slide {i+1} — ' if lang=='en' else f'第{i+1}页｜')+TITLES[lang][i]+'\n\n'+'\n\n'.join(ps) for i,ps in enumerate(NOTES[lang]))
    (folder/(stem+'.txt')).write_text(plain,encoding='utf-8')
    for values in [md,plain]:
        assert not re.search('[A-Za-z]' if lang=='zh' else '[\u4e00-\u9fff]',values)


if __name__=='__main__':
    images=chinese_figures()
    for lang in ['en','zh']:
        folder=build_deck(lang,images)
        build_documents(lang,folder)
        print(lang,folder)
    print('Created 2 three-slide decks, 2 proposal sections and 2 presentation scripts; language checks passed.')
