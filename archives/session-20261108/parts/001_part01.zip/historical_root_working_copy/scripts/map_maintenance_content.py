"""Five-section materials: map maintenance is core; vehicle reuse is an extension."""

HEADINGS = {
    'zh': ['目标', '输入', '流程', '输出', '条件与局限'],
    'en': ['Objective', 'Input', 'Pipeline', 'Output', 'Conditions and Limitations'],
}
TITLES = {
    'zh': ['目标与输入', '流程', '输出、条件与局限'],
    'en': ['Objective & Input', 'Pipeline', 'Output, Conditions and Limitations'],
}
ROLE = {
    'zh': ('黄子明：地图变化持续性判断与地图更新', '负责道路变化的长短期判断、结合可靠性结果更新基础地图、临时事件层管理、地图版本管理、可视化及地图更新评估。'),
    'en': ('黄子明：Map Change Persistence Assessment & Map Updating', 'Responsible for short-term and long-term change assessment, reliability-guided base-map updating, temporary event layer management, map version management, visualization, and map update evaluation.'),
}

PROPOSAL = {
    'zh': [
        ('目标', ['本模块的核心目标是判断道路变化属于长期变化、短期变化还是待确认状态，并完成地图更新与可视化。经核验的长期结构变化写入基础地图，短期障碍或占用记录在临时事件层。']),
        ('输入', ['输入包括原有地图、感知模块输出的变化候选及其位置与几何、多帧验证结果、观测时间与访问记录，以及可靠性模块提供的判断和观测质量证据。本模块利用这些上游结果进行持续性判断和地图维护；已采集序列可以按时间顺序作为测试输入。']),
        ('流程', [
            '首先关联地图对象与变化候选，检查几何、时间和观测质量，再结合多帧及跨访问证据判断持续性。长期结构变化在可靠性、对象匹配和几何检查通过后更新基础地图，并保留修改前后内容、版本、支持证据和回退记录。',
            '短期变化进入临时事件层，即叠加在基础地图上的事件标注，记录位置、影响范围、观测时间和有效状态，不直接改写道路结构。有新的核验结果时更新或解除事件；过期或缺测只表示需要核验，不能直接认定道路恢复。长期性未确认的已核验占用也可先保留事件标注，分类保持待确认；证据不足时不强行修改基础地图。',
        ]),
        ('输出', [
            '我们的最终证据将是地图变化长短期判断、分层更新与可视化的演示及配套评估：展示长期变化如何更新基础地图、短期变化如何进入临时事件层，以及每次判断与修改的证据、版本和回退记录。',
            '输出包括长短期及待确认分类结果、更新后的基础地图、临时事件层、地图前后对比和更新日志。评估将对照参考标注检查长短期误判、漏判和待确认比例，并统计错误更新比例、符合条件的更新覆盖率、几何误差、更新延迟及回退是否正确；同时报告应更新却未更新的变化。',
        ]),
        ('条件与局限', [
            '长期判断依赖足够时间跨度的有效证据；同次短视频中的连续多帧不能独立证明长期变化，持续占用也不自动等于道路结构变化。真实数据与受控仿真分别报告；没有参考标注时只展示流程，不宣称分类准确率。证据不保证变化永久存在，也不能证明真实驾驶安全。',
            '目前已有地图与观测接入、受控更新和回退原型；真实可靠性输出、真实复访证据与参考标注仍待补齐。向其他车辆共享更新，并由其用于规划，属于后续扩展，不作为本模块核心成果或当前评估的必要条件。',
        ]),
    ],
    'en': [
        ('Objective', ['The core objective is to classify observed road changes as long-term, short-term or unresolved, then update and visualise the map. Verified long-term structural changes modify the base map; short-term obstacles or occupancy are recorded in a temporary event layer.']),
        ('Input', ['Inputs include the original map, change candidates with locations and geometry from perception, multi-frame verification results, observation times and visit records, and reliability decisions with observation-quality evidence. This module uses those upstream results for persistence assessment and map maintenance. Recorded sequences can supply time-ordered test inputs.']),
        ('Pipeline', [
            'First, associate candidates with map objects and check geometry, time and observation quality. Assess persistence using multi-frame and independent-visit evidence. Long-term structural changes update the base map only after reliability, object-matching and geometry checks, retaining before/after states, versions, evidence and rollback records.',
            'Short-term changes enter a temporary event layer: annotations over the base map carrying location, affected area, observation time and validity, without rewriting road structure. New verification can update or clear an event; expiry or missing observations require review and do not establish clearance. Verified occupancy with unresolved persistence may also retain an event annotation while its classification remains unresolved. Insufficient evidence does not force a base-map update.',
        ]),
        ('Output', [
            'Our final evidence will be a demonstration and evaluation of map-change persistence assessment, layered updating and visualisation, showing how long-term changes update the base map, how short-term changes enter the temporary event layer, and how decisions and edits retain evidence, versions and rollback records.',
            'Outputs include long-term, short-term and unresolved classifications, the updated base map, the temporary event layer, before/after visualisations and update logs. Evaluation will compare classifications with reference labels, reporting misclassifications, missed changes and the unresolved proportion. It will also measure false-update rate, eligible-update coverage, geometry error, update delay and rollback correctness, including eligible changes left unapplied.',
        ]),
        ('Conditions and Limitations', [
            'Long-term decisions require valid evidence over a sufficient time span. Consecutive frames from one short recording do not independently prove long-term change; persistent occupancy does not automatically establish structural change. Real and simulated evidence will be reported separately. Without reference labels, demonstrations establish workflow rather than classification accuracy. Evidence does not guarantee permanence or real-world driving safety.',
            'Existing work includes map and observation intake, controlled updates and rollback. Actual reliability outputs, real revisit evidence and reference labels remain to be completed. Sharing updates with other vehicles for planning is a future extension, outside this module’s core deliverables and current evaluation requirements.',
        ]),
    ],
}

SCRIPT = {
    'zh': [
        [
            ('目标', [
                '我的任务是判断道路变化属于长期还是短期，再把判断结果落实到地图更新和可视化。这里主要维护两部分：基础地图和临时事件层。确认的长期道路结构变化更新基础地图，短期障碍或占用记录到临时事件层。证据不够时保留待确认状态。',
                '临时事件层可以理解成盖在原地图上面的一张可更新标注纸。例如道路上出现临时障碍，我们标出它的位置、影响范围和当前状态，原有道路结构仍然保留。这既记录了眼前的变化，也避免把临时障碍当成永久道路结构。',
            ]),
            ('输入', [
                '输入来自原有地图，以及其他成员提供的感知变化候选、多帧验证和可靠性结果。候选需要带有位置、几何和观测时间，跨次访问记录则帮助我们判断变化是否持续存在。我的部分承接这些结果，完成持续性判断、地图写入和可视化。',
                '已有采集数据可以按时间顺序驱动程序，这是测试输入的方式。最终要展示的是分类结果、地图实际发生的修改，以及支持修改的证据。',
            ]),
        ],
        [('流程', [
            '流程先从输入对齐开始：把变化候选关联到对应的地图对象，检查位置、几何、时间和观测质量，再结合可靠性结果、多帧和跨访问证据判断持续性。',
            '如果确认属于长期道路结构变化，例如标线位置发生持续改变，就在可靠性、对象匹配和几何检查通过后更新基础地图。每次更新都保存修改前后的内容、地图版本和支持证据，并能够回退。',
            '如果属于短期障碍或占用，就新增或更新临时事件标注，记录位置、影响范围、观测时间和有效状态。收到新的核验结果后可以更新或解除事件。信息过期或者一段时间没有观测到它，只能说明需要核验，不能直接说明道路已经恢复。',
            '如果长期性还不能确定，就保留待确认分类。已经核验的当前占用仍可以保留在事件层，但不会因为暂时缺少证据就强行改写基础地图。障碍物停留得久，也不自动说明车道结构发生变化。最后把分类、基础地图和事件层一起可视化。',
        ])],
        [
            ('输出', [
                '我们的最终证据将展示一条完整的地图维护流程：变化被判为长期、短期或待确认，随后更新到相应的图层，并能查看地图修改前后、判断依据、版本和回退记录。',
                '评估集中在分类和地图更新。我们将对照参考标注检查误判、漏判和待确认比例，再统计错误更新、更新覆盖、几何误差、更新延迟及回退是否正确。还要报告符合条件但没有完成更新的变化，不能因为什么都不改就认为系统准确。',
            ]),
            ('条件与局限', [
                '长期判断需要足够时间跨度的有效证据。单段短视频中的连续多帧，只能证明这段时间里持续出现，不能独立证明长期存在。没有参考标注时，可以展示流程，但不能宣称分类准确率。真实数据与受控仿真会分开报告，结论也不保证变化永久存在或真实驾驶安全。',
                '当前已有地图与观测接入、受控更新和回退原型，真实可靠性结果、真实复访和参考标注仍待补齐。向其他车辆共享更新，并让它们用于规划，是后续扩展。我的核心交付到地图更新、可视化和相应评估为止。',
            ]),
        ],
    ],
    'en': [
        [
            ('Objective', [
                'My task is to assess whether a road change is long-term or short-term, then turn that decision into a map update and visualisation. We maintain a base map and a temporary event layer. Confirmed long-term structural changes update the base map; short-term obstacles or occupancy enter the event layer. Insufficient evidence leaves the classification unresolved.',
                'The temporary event layer is like an editable sheet of annotations placed over the map. A temporary obstacle receives a location, affected area and current status, while the underlying road structure stays intact. This records the current change without treating a temporary obstacle as permanent road geometry.',
            ]),
            ('Input', [
                'Inputs come from the existing map and the other members’ perception, multi-frame verification and reliability results. Candidates need locations, geometry and observation times. Independent-visit records help determine persistence. My module uses these upstream results for persistence assessment, map updating and visualisation.',
                'Recorded data can drive the program in time order. That is a test-input method. The intended evidence is the classification, the actual map edit and its supporting observations.',
            ]),
        ],
        [('Pipeline', [
            'The pipeline starts by associating each change candidate with a map object and checking location, geometry, time and observation quality. It then assesses persistence using reliability results, multi-frame evidence and observations across independent visits.',
            'A confirmed long-term structural change, such as a persistent shift in a lane marking, updates the base map after reliability, object-matching and geometry checks. Each edit retains its before/after states, version and evidence, and supports rollback.',
            'A short-term obstacle or occupancy creates or updates an event annotation with location, affected area, observation time and validity. New verification may update or clear the event. Expired information or missing observations requires review; neither establishes that the road is clear.',
            'If persistence is uncertain, the classification remains unresolved. Verified current occupancy may retain an event annotation, while insufficient evidence does not force a base-map edit. An obstacle staying in place does not automatically establish a change in road structure. Finally, the classification, base map and event layer are visualised together.',
        ])],
        [
            ('Output', [
                'Our final evidence will show a complete map-maintenance workflow: classify a change as long-term, short-term or unresolved, update the appropriate layer, and inspect the map before and after, decision evidence, versions and rollback records.',
                'Evaluation focuses on classification and map updating. We will compare decisions against reference labels, report misclassifications, missed changes and unresolved cases, then measure false updates, update coverage, geometry error, delay and rollback correctness. Eligible changes left unapplied must also be reported; doing nothing does not establish accuracy.',
            ]),
            ('Conditions and Limitations', [
                'Long-term decisions need valid evidence over a sufficient time span. Consecutive frames in one short recording only establish persistence within that recording. Without reference labels, we can demonstrate the workflow but cannot claim classification accuracy. Real observations and controlled simulations will be reported separately. The evidence does not guarantee permanence or real-world driving safety.',
                'Existing work covers map and observation intake, controlled updates and rollback. Actual reliability outputs, real revisits and reference labels still need completion. Sharing updates with other vehicles for planning is a future extension. My core deliverables end at map updating, visualisation and the corresponding evaluation.',
            ]),
        ],
    ],
}
