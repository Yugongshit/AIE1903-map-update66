"""Exercise the self-contained demo in Chromium and optionally record a tour."""
import argparse
import json
import subprocess
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from functools import partial
from urllib.parse import quote
from playwright.sync_api import sync_playwright

parser=argparse.ArgumentParser();parser.add_argument('directory');parser.add_argument('--record',action='store_true')
args=parser.parse_args();root=Path(args.directory).resolve()
class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(root)))
thread=Thread(target=server.serve_forever,daemon=True);thread.start()
url=f'http://127.0.0.1:{server.server_port}/'+quote('演示.html')
checks=[]
def check(name,value):
    assert value,name
    checks.append(name)
try:
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1440,'height':1060},device_scale_factor=1)
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(url);page.wait_for_timeout(300)
        page.screenshot(path=str(root/'真实场景预览.png'),full_page=True)
        check('157 actual reference features',page.locator('#drawing [data-layer="reference"]').count()==157)
        check('29 actual candidates',page.locator('#stats strong').nth(1).inner_text()=='29')
        check('zero actual map writes',page.locator('#stats strong').nth(3).inner_text()=='0')
        page.locator('#frame').fill('11')
        ld_id=page.locator('#candidate option').evaluate_all("items => items.find(x => x.value.includes('LD-001')).value")
        page.locator('#candidate').select_option(ld_id)
        check('exact-frame candidate selection','LD-001' in page.locator('#detail').inner_text())
        page.locator('#base-layer').uncheck();check('map toggle',page.locator('#drawing [data-layer="reference"]').count()==0)
        page.locator('#base-layer').check();page.locator('#sim-tab').click()
        page.locator('[data-stage="2"]').click()
        check('two visits do not update',page.locator('#stats strong').nth(2).inner_text()=='0' and '证据不足' in page.locator('#detail').inner_text())
        page.locator('[data-stage="3"]').click()
        check('three consistent visits update one feature','已更新基础地图' in page.locator('#detail').inner_text() and page.locator('#stats strong').nth(2).inner_text()=='1')
        page.screenshot(path=str(root/'模拟更新预览.png'),full_page=True)
        page.locator('[data-case="1"]').click();check('occupancy remains an event','临时事件层' in page.locator('#detail').inner_text())
        page.locator('[data-case="2"]').click();check('untyped discrepancy blocked','写入受阻' in page.locator('#detail').inner_text())
        page.locator('[data-case="3"]').click();check('invalid alignment rejected','0 条接受 / 3 条拒绝' in page.locator('#detail').inner_text())
        page.locator('[data-stage="4"]').click();page.locator('[data-case="1"]').click();check('explicit recovery clears occupancy','已确认恢复' in page.locator('#detail').inner_text())
        page.locator('[data-stage="5"]').click();page.locator('[data-case="0"]').click()
        check('rollback restores geometry and requires review','需要重新核验' in page.locator('#detail').inner_text() and page.locator('#stats strong').nth(2).inner_text()=='0')
        page.screenshot(path=str(root/'回退预览.png'),full_page=True)
        with page.expect_download() as info:page.locator('#export').click()
        info.value.save_as(str(root/'导出验证.json'))
        exported=json.loads((root/'导出验证.json').read_text())
        check('export matches displayed rollback',exported['bundle']['versions'][-1]['patch']['operation']=='rollback')
        page.set_viewport_size({'width':390,'height':844})
        check('mobile has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
        check('no JavaScript errors',not errors)
        (root/'browser_checks.json').write_text(json.dumps({'status':'PASS','checks':checks,'javascript_errors':errors,'transport':'localhost HTTP; managed browser blocks file:// navigation'},ensure_ascii=False,indent=2)+'\n')
        print(f'Browser PASS: {len(checks)} interaction checks.',flush=True)
        page.close()
        if args.record:
            # Capture actual browser states and encode a paced tour with system ffmpeg.
            # This avoids a second Playwright-specific ffmpeg installation.
            context=browser.new_context(viewport={'width':1440,'height':1220})
            page=context.new_page();page.goto(url)
            frames=root/'video_frames';frames.mkdir(exist_ok=True);sequence=[]
            def capture(duration):
                name=f'{len(sequence):03d}.png'
                page.screenshot(path=str(frames/name))
                sequence.append((name,duration))
            capture(2)
            for i in range(1,41):page.locator('#frame').fill(str(i));capture(.25)
            page.locator('#frame').fill('11');page.locator('#candidate').select_option(ld_id);capture(2)
            page.locator('#sim-tab').click();capture(2)
            for i in [1,2,3]:page.locator(f'[data-stage="{i}"]').click();capture(2.5)
            for i in [1,2,3]:page.locator(f'[data-case="{i}"]').click();capture(2)
            page.locator('[data-stage="4"]').click();page.locator('[data-case="1"]').click();capture(3)
            page.locator('[data-stage="5"]').click();page.locator('[data-case="0"]').click();capture(4)
            manifest=frames/'frames.txt'
            manifest.write_text(''.join(f"file '{name}'\nduration {duration}\n" for name,duration in sequence)+f"file '{sequence[-1][0]}'\n")
            subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(manifest),'-vf','format=yuv420p','-r','24','-c:v','libx264','-preset','fast','-crf','23','-movflags','+faststart',str(root/'演示视频.mp4')],check=True)
            context.close()
            print('Saved paced browser demonstration video.',flush=True)
        browser.close()
finally:
    server.shutdown();server.server_close();thread.join()
