"""Build six bilingual materials with map maintenance as the core scope."""
from pathlib import Path
import json
import re

from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from docx.shared import Pt

from build_shared_map_revision import Deck, NAVY, TEAL, MINT, INK, MUTED, PAPER, WHITE, BORDER, CORAL, GOLD, BLUE
from build_separate_evidence_versions import document_base
from build_shared_map_structured import save_word
from map_maintenance_content import HEADINGS, TITLES, PROPOSAL, SCRIPT, ROLE

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs/map_maintenance_five_sections'


class MaintenanceDeck(Deck):
    def __init__(self, lang):
        super().__init__(lang)
        self.p.core_properties.title = self.pick('地图变化分类、更新与可视化', 'Map Change Classification, Updating and Visualisation')

    def heading(self, num, subtitle):
        s=self.p.slides.add_slide(self.p.slide_layouts[6])
        s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(PAPER)
        self.box(s,0,0,16,.09,TEAL,kind=MSO_SHAPE.RECTANGLE)
        self.text(s,.55,.28,6.4,.24,self.pick('地图变化分类、更新与可视化','MAP CHANGE CLASSIFICATION, UPDATING AND VISUALISATION'),10.0,TEAL,True)
        self.text(s,7.0,.28,8.45,.24,' / '.join(HEADINGS[self.lang]),9.1,MUTED,False,PP_ALIGN.RIGHT)
        self.text(s,.55,.76,14.9,.65,TITLES[self.lang][num-1],33.0,NAVY,True)
        self.text(s,.58,1.46,14.8,.31,subtitle,14.0,MUTED)
        self.line(s,.55,8.57,15.45,8.57,BORDER,.8)
        self.text(s,.55,8.68,13.8,.20,self.pick('项目计划书 · 核心范围：长短期判断、地图更新与可视化。','Research proposal · Core scope: persistence assessment, map updating and visualisation.'),9.7,MUTED)
        self.text(s,14.55,8.66,.9,.25,f'{num:02d} / 03',10.8,TEAL,True,PP_ALIGN.RIGHT)
        s.notes_slide.notes_text_frame.text='\n\n'.join(h+'\n\n'+'\n\n'.join(ps) for h,ps in SCRIPT[self.lang][num-1])
        return s

    def slide_one(self):
        s=self.heading(1,self.pick('承接上游感知、验证与可靠性结果，判断变化持续性，并维护相应地图图层。','Use upstream perception, verification and reliability evidence to assess persistence and maintain the appropriate map layer.'))
        self.box(s,.55,1.99,14.90,1.05,NAVY)
        self.text(s,.82,2.13,14.35,.28,self.pick('目标','Objective'),17.8,'80D8C4',True)
        self.text(s,.82,2.56,14.35,.32,self.pick('长期结构变化 → 核验后更新基础地图；短期变化 → 临时事件层；证据不足 → 待确认。','Long-term structural change → verified base-map update; short-term change → event layer; insufficient evidence → unresolved.'),16.7,WHITE,True)
        self.box(s,.55,3.30,7.13,3.83,WHITE,BORDER)
        self.text(s,.82,3.53,6.59,.36,self.pick('输入','Input'),22,TEAL,True)
        inputs=[
            (BLUE,self.pick('原有地图与变化候选','Original map and change candidates'),self.pick('地图对象、候选位置与几何，来自感知模块。','Map objects, candidate locations and geometry from perception.')),
            (TEAL,self.pick('多帧与跨访问记录','Multi-frame and independent-visit records'),self.pick('观测时间、持续性证据及多帧验证结果。','Observation times, persistence evidence and multi-frame verification.')),
            (GOLD,self.pick('可靠性与观测质量','Reliability and observation quality'),self.pick('上游可靠性判断与支持证据。','Upstream reliability decisions and supporting evidence.')),
        ]
        for i,(c,title,body) in enumerate(inputs):
            y=4.13+i*.86
            self.box(s,.83,y,.08,.48,c,kind=MSO_SHAPE.RECTANGLE)
            self.text(s,1.12,y-.02,6.22,.30,title,16.8,c,True)
            self.text(s,1.12,y+.39,6.22,.41,body,13.5,INK)
        self.box(s,7.94,3.30,7.51,3.83,WHITE,BORDER)
        self.text(s,8.21,3.53,6.97,.36,self.pick('两层地图，分别维护','Two map layers, maintained separately'),21.0,NAVY,True)
        self.box(s,8.35,4.16,6.68,.94,'FFF3DB')
        self.text(s,8.61,4.29,6.16,.29,self.pick('临时事件层：可更新的事件标注','Temporary event layer: editable annotations'),16.3,GOLD,True)
        self.text(s,8.61,4.73,6.16,.22,self.pick('位置 · 影响范围 · 观测时间 · 有效状态','Location · Affected area · Observation time · Validity'),12.0,INK)
        self.box(s,8.35,5.31,6.68,.94,MINT)
        self.text(s,8.61,5.44,6.16,.29,self.pick('基础地图：道路与标线等结构','Base map: road and lane-marking structure'),16.3,TEAL,True)
        self.text(s,8.61,5.88,6.16,.22,self.pick('确认长期结构变化后，再修改对应对象','Modify the relevant object after a structural change is confirmed.'),12.0,INK)
        self.text(s,8.35,6.53,6.68,.35,self.pick('可以理解成：原地图 + 一张临时标注纸。','Think of the original map plus a temporary annotation sheet.'),14.3,MUTED)
        self.box(s,.55,7.43,14.90,.84,MINT)
        self.text(s,.82,7.58,14.35,.27,self.pick('核心交付：长短期及待确认分类、地图更新、可视化与评估。','Core deliverables: long-term, short-term and unresolved classifications; map updates, visualisation and evaluation.'),15.5,TEAL,True)
        self.text(s,.82,7.98,14.35,.22,self.pick('已有采集序列可以按时间作为测试输入，最终检查地图实际发生的修改。','Recorded sequences can supply time-ordered test inputs; the demonstration inspects actual map edits.'),12.8,INK)

    def slide_two(self):
        s=self.heading(2,self.pick('输入对齐 → 综合证据 → 判断长短期 → 分层写入 → 可视化与记录。','Align inputs → assess evidence → classify persistence → update the appropriate layer → visualise and record.'))
        stages=[
            (self.pick('一  输入对齐','1  Align inputs'),self.pick('关联地图对象；检查位置、几何与时间。','Associate map objects; check location, geometry and time.')),
            (self.pick('二  综合证据','2  Assess evidence'),self.pick('结合可靠性、观测质量、多帧与跨访问结果。','Combine reliability, quality, multi-frame and independent-visit evidence.')),
            (self.pick('三  分类与写入决策','3  Classify and decide'),self.pick('判断长期、短期或待确认，并检查写入条件。','Classify long-term, short-term or unresolved; check update eligibility.')),
        ]
        for i,(title,body) in enumerate(stages):
            x=.55+i*5.07
            self.box(s,x,2.01,4.76,1.13,NAVY)
            self.text(s,x+.23,2.18,4.30,.31,title,17.7,WHITE,True)
            self.text(s,x+.23,2.62,4.30,.42,body,12.7,'DCEBF3')
            if i<2:self.text(s,x+4.80,2.39,.25,.36,'→',19.0,TEAL,True)
        self.text(s,.58,3.37,14.8,.25,self.pick('判断结果决定进入哪一层；待确认分类不强制写入基础地图。','The decision determines the target layer; unresolved evidence does not force a base-map edit.'),13.2,TEAL,True)
        branches=[
            (TEAL,self.pick('长期结构变化','Long-term structural change'),self.pick('更新基础地图','Update the base map'),self.pick('可靠性、对象匹配与几何检查通过后，修改对应地图对象。\n保留前后内容、版本、证据与回退记录。','After reliability, object-matching and geometry checks, modify the corresponding map object.\nRetain before/after states, versions, evidence and rollback.')),
            (GOLD,self.pick('短期障碍或占用','Short-term obstacle or occupancy'),self.pick('新增或更新临时事件','Create or update an event'),self.pick('记录位置、影响范围、时间与状态，保留基础道路结构。\n新的核验结果可更新或解除事件；过期不等于恢复。','Record location, affected area, time and status; preserve base-map road structure.\nNew verification may update or clear an event; expiry does not prove clearance.')),
            (MUTED,self.pick('证据不足或持续性未明','Insufficient or unresolved evidence'),self.pick('保留待确认状态','Retain an unresolved status'),self.pick('继续收集证据，不强行修改基础地图。\n已核验的当前占用可先保留事件标注，长期性仍待确认。','Collect further evidence without forcing a base-map edit.\nVerified current occupancy may retain an event annotation while persistence remains unresolved.')),
        ]
        for i,(c,title,action,body) in enumerate(branches):
            x=.55+i*5.07
            self.box(s,x,3.86,4.76,3.42,WHITE,BORDER)
            self.box(s,x+.23,4.09,.07,.35,c,kind=MSO_SHAPE.RECTANGLE)
            self.text(s,x+.46,4.07,4.05,.36,title,16.5,c,True)
            self.box(s,x+.24,4.71,4.28,.61,[MINT,'FFF3DB','EBEFF4'][i])
            self.text(s,x+.39,4.86,3.98,.28,action,16.2,c,True,PP_ALIGN.CENTER)
            self.text(s,x+.25,5.62,4.26,1.42,body,14.1,INK)
        self.box(s,.55,7.55,14.90,.71,MINT)
        self.text(s,.82,7.72,14.35,.35,self.pick('分类与分层结果 → 地图前后对比 + 判断原因 + 版本记录 + 回退验证','Classification and layer decisions → Before/after views + Decision evidence + Version records + Rollback checks'),15.3,TEAL,True)

    def slide_three(self):
        s=self.heading(3,self.pick('展示地图维护的结果与依据，并明确证据成立的条件和扩展范围。','Present map-maintenance outcomes and evidence, with the conditions, limitations and extension scope made explicit.'))
        self.box(s,.55,1.99,14.90,1.08,NAVY)
        self.text(s,.82,2.16,14.35,.79,self.pick('我们的最终证据将是长短期判断、分层地图更新与可视化的演示及配套评估，\n展示基础地图和临时事件层的变化，以及支持判断与修改的证据、版本和回退记录。','Our final evidence will be a demonstration and evaluation of persistence assessment, layered map updates and\nvisualisation, with changes to the base map and event layer supported by evidence, versions and rollback records.'),17.2,WHITE)
        self.box(s,.55,3.34,7.31,3.88,WHITE,BORDER)
        self.text(s,.82,3.54,6.77,.37,self.pick('输出','Output'),22.0,TEAL,True)
        self.text(s,.82,4.08,6.77,.70,self.pick('长短期及待确认分类 · 更新后的基础地图\n临时事件层 · 前后可视化 · 判断与更新日志','Persistence classifications · Updated base map\nTemporary event layer · Before/after views · Decision and update logs'),15.0,INK,True)
        self.line(s,.82,4.99,7.58,4.99,BORDER,.8)
        self.text(s,.82,5.17,6.77,.31,self.pick('对应评估','Evaluation'),16.5,TEAL,True)
        self.text(s,.82,5.66,6.77,1.22,self.pick('对照参考标注：误判、漏判与待确认比例。\n更新质量：错误更新、覆盖率、几何误差与延迟。\n检查回退正确性；同时统计应更新却未更新的变化。','Reference labels: misclassifications, missed changes and unresolved cases.\nUpdate quality: false updates, coverage, geometry error and delay.\nCheck rollback and report eligible changes left unapplied.'),14.2,INK)
        self.box(s,8.14,3.34,7.31,3.88,WHITE,BORDER)
        self.text(s,8.41,3.54,6.77,.37,self.pick('条件与局限','Conditions and Limitations'),22.0,NAVY,True)
        conditions=[
            self.pick('长期判断需要足够时间跨度；短视频多帧不能独立证明长期变化，持续占用不自动等于结构变化。','Long-term decisions need sufficient time coverage. A short recording cannot independently prove long-term change; occupancy is not automatically structural.'),
            self.pick('真实与仿真分别报告；没有参考标注时不宣称分类准确率。不保证永久性或真实驾驶安全。','Report real and simulated evidence separately. No reference labels means no accuracy claim; permanence and driving safety are not established.'),
            self.pick('已有接入、受控更新与回退原型；真实可靠性、复访证据及参考标注仍待补齐。','Intake, controlled updates and rollback exist as prototypes. Actual reliability outputs, real revisits and reference labels remain to be completed.'),
        ]
        for i,text in enumerate(conditions):
            y=4.12+i*.94
            self.box(s,8.42,y+.03,.06,.35,[TEAL,BLUE,GOLD][i],kind=MSO_SHAPE.RECTANGLE)
            self.text(s,8.65,y,6.48,.79,text,13.3,INK)
        self.box(s,.55,7.52,14.90,.75,'EBEFF4')
        self.text(s,.82,7.67,14.35,.44,self.pick('扩展：向其他车辆共享更新并用于规划。该部分不属于本模块当前核心交付与评估要求。','Extension: share updates with other vehicles for planning. This is outside the module’s current core deliverables and evaluation requirements.'),14.6,MUTED,True)

    def save(self,folder):
        self.slide_one();self.slide_two();self.slide_three()
        for slide in self.p.slides:
            text='\n'.join(x.text for x in slide.shapes if x.has_text_frame)+'\n'+slide.notes_slide.notes_text_frame.text
            assert not re.search('[A-Za-z]' if self.cn else '[\u4e00-\u9fff]',text)
        self.p.save(folder/('地图更新_五部分结构_中文版.pptx' if self.cn else 'Map_Maintenance_Five_Sections_EN.pptx'))


def base_document(lang,title,subtitle):
    doc=document_base(lang,title,subtitle)
    doc.sections[0].header.paragraphs[0].text='课程项目｜地图变化分类、更新与可视化' if lang=='zh' else 'AIE1903 | MAP CHANGE CLASSIFICATION, UPDATING AND VISUALISATION'
    for r in doc.sections[0].header.paragraphs[0].runs:r.font.size=Pt(8)
    return doc


def documents(lang,folder):
    cn=lang=='zh'
    title='地图变化分类、更新与可视化' if cn else 'Map Change Classification, Updating and Visualisation'
    subtitle='项目计划书｜目标、输入、流程、输出、条件与局限' if cn else 'Proposal | Objective, Input, Pipeline, Output, Conditions and Limitations'
    doc=base_document(lang,title,subtitle)
    doc.styles['Title'].font.size=Pt(21 if cn else 19)
    doc.styles['Normal'].font.size=Pt(10.2)
    doc.styles['Normal'].paragraph_format.line_spacing=1.02
    doc.styles['Normal'].paragraph_format.space_after=Pt(3.5)
    doc.styles['Heading 1'].font.size=Pt(12)
    doc.styles['Heading 1'].paragraph_format.space_before=Pt(6)
    doc.styles['Heading 1'].paragraph_format.space_after=Pt(4)
    for h,paras in PROPOSAL[lang]:
        doc.add_heading(h,1)
        for p in paras:doc.add_paragraph(p)
    name='地图更新_计划书_中文版' if cn else 'Map_Maintenance_Proposal_EN'
    save_word(doc,folder/(name+'.docx'),lang)
    markdown='# '+title+'\n\n'+'\n\n'.join('## '+h+'\n\n'+'\n\n'.join(ps) for h,ps in PROPOSAL[lang])
    (folder/(name+'.md')).write_text(markdown,encoding='utf-8')
    doc=base_document(lang,'地图变化分类、更新与可视化：讲稿' if cn else 'Map Maintenance: Presentation Script','对应三页演示｜约4至5分钟' if cn else 'Three corresponding slides | Approximately 4–5 minutes')
    doc.styles['Title'].font.size=Pt(21)
    doc.styles['Normal'].font.size=Pt(11.5)
    doc.styles['Normal'].paragraph_format.line_spacing=1.10
    doc.styles['Normal'].paragraph_format.space_after=Pt(7)
    parts=[]
    for i,sections in enumerate(SCRIPT[lang]):
        if i:doc.add_page_break()
        page=(f'第{i+1}页｜' if cn else f'Slide {i+1} — ')+TITLES[lang][i]
        doc.add_heading(page,1);lines=[page]
        for h,ps in sections:
            if len(sections)>1:doc.add_heading(h,2)
            lines.append(h)
            for p in ps:doc.add_paragraph(p);lines.append(p)
        parts.append('\n\n'.join(lines))
    name='地图更新_讲稿_中文版' if cn else 'Map_Maintenance_Script_EN'
    save_word(doc,folder/(name+'.docx'),lang)
    plain='\n\n'.join(parts)
    (folder/(name+'.txt')).write_text(plain,encoding='utf-8')
    for value in (markdown,plain):assert not re.search('[A-Za-z]' if cn else '[\u4e00-\u9fff]',value)


if __name__=='__main__':
    for lang,sub in [('zh','中文'),('en','English')]:
        folder=OUT/sub;folder.mkdir(parents=True,exist_ok=True)
        MaintenanceDeck(lang).save(folder);documents(lang,folder)
        print('Generated:',sub,'3 slides, five-section proposal and aligned script')
    (OUT/'任务描述与扩展范围.md').write_text('\n\n'.join([ROLE['zh'][0],ROLE['zh'][1],'扩展：向其他车辆共享更新，并由其用于规划。',ROLE['en'][0],ROLE['en'][1],'Extension: sharing map updates with other vehicles for planning.'])+'\n',encoding='utf-8')
    (OUT/'scope.json').write_text(json.dumps({'sections':HEADINGS['en'],'core':['persistence classification','base-map updating','temporary event layer management','visualisation','map maintenance evaluation'],'extension':['sharing updates with other vehicles','planning reuse'],'removed_from_core':['publishing and receiving client requirements','sharing latency evaluation','planning policy comparisons'],'current_limits':['actual reliability outputs','real revisit evidence','reference labels'],'deliverables':6},ensure_ascii=False,indent=2)+'\n')
