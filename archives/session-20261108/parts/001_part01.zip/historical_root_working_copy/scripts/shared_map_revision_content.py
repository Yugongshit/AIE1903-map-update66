"""Aligned Chinese and English content for the shared-map proposal revision."""

TITLES = {
    'zh': ['让一辆车的发现，服务其他车辆', '分层更新地图，让其他车辆正确使用', '证明地图改得对、传得到、用得上'],
    'en': ['One Vehicle Observes. Others Benefit.', 'Update the Right Layer. Share the Right State.', 'Correct Updates. Successful Sharing. Useful Planning.'],
}

PROPOSAL = {
    'zh': [
        ('最终证据', [
            '我们的最终证据将是一个共享地图更新与复用的端到端演示，以及配套的受控对照实验：展示一辆车发现的道路变化，如何经过可靠性与持续性判断，更新到合适的地图图层，再发布给另一辆车用于重新规划。',
        ]),
        ('更新、可视化与共享', [
            '系统将区分临时事件与持续性的地图结构变化。经核验的障碍物或临时占用可及时进入事件层并共享，不必等待长期性确认；记录将包含影响区域、观测时间、有效性状态与来源。过期或缺测不自动代表道路恢复。满足可靠性、跨访问持续性、对象匹配与几何检查的结构变化，才写入基础地图，并保留版本、修改前后内容及回退记录。',
            '发布端将提供带版本信息的地图更新与事件记录。另一接收端按统一接口获取并应用更新，检查地图对象、版本与时效。可视化将同时展示原始与更新后的地图、临时事件、支持证据、发布与接收状态，以及接收车辆的规划响应。对已确认不可通行的区域，规划器应避开受影响的通路，或报告无可行方案；部分占用或不确定候选则结合本车感知、覆盖条件和可行性检查处理。',
        ]),
        ('评估方法', [
            '评估包括三部分：地图维护质量，统计错误更新比例、符合条件的更新覆盖率、几何误差与更新延迟；共享链路，检查版本一致性、从发布到接收端应用的延迟、过期与重复更新处理，以及回退传播；规划效果，在相同本车感知、起终点和可行性检查下，比较不使用共享更新、对共享候选采用固定惩罚、使用可靠性与分层更新三种策略，报告可行路线比例、路线长度和失败原因。路线长度只在双方均可行的样本上比较。',
        ]),
        ('结论范围与实施状态', [
            '这些证据将检验地图变化能否被合理维护、可靠传递，并被另一车辆的规划模块使用。真实数据与受控仿真将分别报告；已有采集序列按时间输入程序，只是测试方法，最终成果是更新、共享和使用这条完整链路。证据不能保证变化永久存在、支持所有实车系统，或证明真实驾驶安全。',
            '目前已有真实地图与观测接入，以及受控更新和回退原型；成员三真实结果、发布与接收端、规划联调和真实复访仍待补齐。最终展示将明确区分已实现功能与计划验证内容，不提前宣称性能提升。',
        ]),
    ],
    'en': [
        ('Final evidence', [
            'Our final evidence will be an end-to-end demonstration and controlled comparisons showing how a road change observed by one vehicle is assessed for reliability and persistence, added to the appropriate shared-map layer, published, and used by another vehicle for replanning.',
        ]),
        ('Updating, visualising and sharing', [
            'The system will separate temporary events from persistent structural changes. Verified obstacles or temporary occupancy can be shared promptly in an event layer without waiting for long-term confirmation. Each event will carry its affected area, observation time, validity status and provenance. Expiry or missing observations will not establish clearance. Structural changes will enter the base map only after reliability, independent-visit persistence, object-matching and geometry checks, with versions, before/after records and rollback history.',
            'A publishing service will provide versioned map updates and events. A separate receiving client will retrieve and apply them through a common interface, checking object identity, version and freshness. The visualisation will show map differences, events, evidence, publication and receipt states, and the receiving planner’s response. Confirmed impassable areas should cause affected routes to be avoided or no feasible plan to be reported. Partial occupancy and uncertain candidates require local perception, coverage assessment and feasibility checks.',
        ]),
        ('Evaluation', [
            'We will evaluate map maintenance using false-update rate, eligible-update coverage, geometry error and update delay. Sharing tests will measure version consistency and publication-to-application latency, and check stale updates, duplicates and rollback propagation. Planning will compare no shared updates, fixed penalties for shared candidates, and reliability-aware layered updates under identical local observations, start/goal settings and feasibility checks. We will report feasible-route rate, route length and failure reasons; length comparisons will use cases feasible for both compared policies.',
        ]),
        ('Claim boundaries and implementation status', [
            'The evidence will test whether road changes are maintained appropriately, transferred consistently and used by another vehicle’s planner. Real observations and controlled simulations will be reported separately. Recorded sequences provide time-ordered test inputs; the final outcome is the update–share–use chain. Evidence will not guarantee permanence, interoperability with every production vehicle, or real-world driving safety.',
            'Current work includes real-map and observation intake, plus controlled update and rollback prototypes. Actual reliability outputs, publishing and receiving clients, planner integration and real revisits remain to be completed. The final demonstration will distinguish implemented capabilities from planned validation and will not assume a performance improvement.',
        ]),
    ],
}

NOTES = {
    'zh': [
        [
            '我们最终想展示的是：一辆车发现道路变化后，这条信息能够变成共享地图中的有效更新，并被另一辆车使用。成果包括地图维护、更新发布、接收，以及规划响应。',
            '第一辆车提供道路观测，系统判断证据是否可靠，并区分临时事件和持续性的结构变化。之后把相应更新发布到共享端，第二辆车获取地图版本和仍然有效的事件，再结合自己的感知重新规划。',
            '观众可以看到更新前后的地图、变化的原因、发布版本、接收状态和路线响应。例如，一处被核实不可通行的区域，应该在接收车辆的规划中得到体现；如果无法绕行，也应明确报告没有可行方案。',
            '这里的车辆可以先用两个独立客户端来代表，但必须真实执行发布、接收和应用，而不能只显示两个车辆图标。使用已经采集的数据按时间顺序驱动输入，是测试方法；我们要验证的目标仍然是地图更新能够被另一端使用。图中共享与规划路径是计划示意，尚不是已经测得的规划结果。',
        ],
        [
            '这一页回答两个问题：变化写到哪里，以及其他车辆怎样使用它。我们把共享地图分成基础地图和临时事件层。',
            '对于经核验的障碍物或临时占用，可以先把位置、影响区域、观测时间和状态写到事件层，及时共享给其他车辆，不必等到数天后才能告知它们。信息过期时需要标为过期或待核验；没有新观测，并不说明道路已经恢复。',
            '对于标线位置等结构变化，需要可靠性、跨访问持续性、目标对象和几何检查都通过，再修改基础地图。每次修改都保留版本、支持证据和回退能力。持续存在的占用也不自动等于道路结构已经改变。',
            '其他车辆接收更新后，需要检查版本和时效，再交给规划器。已经确认不可通行的区域，应避免进入受影响的通路；部分占用或尚未确认的候选，要结合本车感知和可行性检查，决定调整代价、进一步核验或评估停车。共享信息帮助规划作出决定，但不会把所有候选都直接变成整条道路封闭。',
        ],
        [
            '我们的评估围绕三个问题：地图是否改得正确，更新是否传到接收端，以及接收车辆是否用得上。',
            '第一，检查错误更新、更新覆盖、几何误差与延迟。还要报告符合条件的变化中有多少没有完成更新，避免通过什么都不改来获得看似很低的错误率。第二，记录发布、接收和应用时间，核对地图版本，并测试重复消息、过期信息和回退传播。',
            '第三，比较三种规划策略：不使用共享更新；对共享候选施加固定惩罚；使用可靠性和分层地图更新。三组保持本车感知、起终点和可行性检查一致，比较可行路线、长度和失败原因。是否改善规划，要由实验结果回答。',
            '当前已经有地图与观测接入、受控地图更新和回退原型；共享端、接收客户端、真实可靠性结果和规划器还需要联调。真实数据与仿真会分开报告。这些证据能支持测试条件下的地图维护与复用结论，不能保证变化永久存在，也不能证明所有真实车辆都能安全使用。',
        ],
    ],
    'en': [
        [
            'Our final demonstration will show how a road change observed by one vehicle becomes a usable shared-map update for another vehicle. The outcome includes map maintenance, publication, receipt and a planning response.',
            'The first vehicle supplies observations. The system assesses reliability and distinguishes temporary events from persistent structural changes. It then publishes the appropriate update. The second vehicle retrieves the map version and valid events, and replans using these alongside its own observations.',
            'The audience will inspect the map before and after the update, its supporting evidence, the published version, receipt status and route response. A confirmed impassable area should affect the receiving vehicle’s route; when no alternative is feasible, the system should report that explicitly.',
            'Two separate clients can initially represent the vehicles, but publication, receipt and application must actually occur. Recorded sensor sequences are simply a way to drive the test inputs. The target remains a map update used by another client. The sharing and route diagrams illustrate the planned demonstration, not measured planner outputs.',
        ],
        [
            'This slide explains where updates belong and how other vehicles should use them. We separate the base map from a temporary event layer.',
            'A verified obstacle or temporary occupancy can be shared promptly with its location, affected area, observation time and validity status. Other vehicles should not have to wait days for a persistence decision. When information expires, its status becomes stale or requires review; missing observations do not establish that the road is clear.',
            'Structural changes, such as a shifted lane marking, require reliability, independent-visit persistence, object-matching and geometry checks before changing the base map. Each update retains its version, evidence and rollback history. Even persistent occupancy does not automatically establish a structural road change.',
            'The receiving vehicle checks version and freshness before using the update. Confirmed impassability should exclude affected routes. Partial occupancy or uncertain candidates instead require local perception and feasibility checks to determine whether to adjust costs, seek verification or assess stopping. Shared evidence informs planning without automatically closing an entire road for every candidate.',
        ],
        [
            'Our evaluation asks three questions: was the map updated correctly, did the update reach the receiving client, and did that client use it effectively?',
            'First, we will measure incorrect updates, eligible-update coverage, geometry error and delay. We will include eligible changes that remain unapplied, so doing nothing cannot appear successful merely because it creates no incorrect writes. Second, we will record publication, receipt and application times, verify versions, and test duplicates, stale information and rollback propagation.',
            'Third, we will compare planning without shared updates, with fixed penalties for shared candidates, and with reliability-aware layered updates. Local observations, start/goal settings and feasibility checks will remain the same. We will compare feasible routes, lengths and failure reasons; any improvement is an empirical question.',
            'Existing work covers map and observation intake, controlled updates and rollback. Publishing and receiving clients, real reliability outputs and the planner still need integration. Real and simulated evidence will be reported separately. Conclusions will concern tested map maintenance and reuse, not guaranteed permanence or safety across all production vehicles.',
        ],
    ],
}
