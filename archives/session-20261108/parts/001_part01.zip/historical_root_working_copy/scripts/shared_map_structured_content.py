"""Reorder the approved content; preserve every proposal and script sentence."""
from collections import Counter
import re

from shared_map_revision_content import PROPOSAL as ORIGINAL_PROPOSAL
from shared_map_revision_content import NOTES as ORIGINAL_NOTES

HEADINGS = {
    'zh': ['输入', '方法', '输出', '假设与局限'],
    'en': ['Input', 'Method', 'Output', 'Assumption and Limitations'],
}
TITLES = {
    'zh': ['输入与方法', '输出', '假设与局限'],
    'en': ['Input & Method', 'Output', 'Assumption and Limitations'],
}


def sentences(paragraphs, lang):
    separator = r'(?<=。)' if lang == 'zh' else r'(?<=[.?])\s+'
    return [s for p in paragraphs for s in re.split(separator, p) if s]


# Input summaries only restate the map, observations and checks already described
# in the approved text. All original sentences below remain verbatim.
INPUT_SUMMARY = {
    'zh': '输入包括已有地图、车辆道路观测，以及用于更新判断的可靠性、持续性和几何证据。',
    'en': 'Inputs comprise the existing map, vehicle observations, and the reliability, persistence and geometry evidence used in update decisions.',
}
PROPOSAL_GROUPS = {
    'zh': [
        [[12]],
        [[1, 2, 4], [5, 6, 8], [9]],
        [[0], [7, 11]],
        [[3, 10], [13], [14, 15]],
    ],
    'en': [
        [[17]],
        [[1, 2, 3, 5], [6, 7, 9, 10], [11, 12, 13]],
        [[0], [8, 15], [14]],
        [[4, 16, 18], [19, 20, 21]],
    ],
}
SCRIPT_GROUPS = {
    'zh': [
        [[2, 7]],
        [[9, 10], [11], [13, 14], [3, 16, 17]],
        [[0, 1], [4, 5], [19], [20, 21], [22], [23, 24, 25]],
        [[6], [12, 15, 18], [26, 27, 28], [8]],
    ],
    'en': [
        [[2, 9, 10]],
        [[12, 3, 13], [14, 15], [17, 18], [4, 5, 20, 21, 22]],
        [[0, 1], [6, 7], [24], [25, 26], [27], [28, 29, 30]],
        [[8], [16, 19, 23], [31, 32, 33, 34], [11]],
    ],
}


def reorder(source, groups, lang):
    indices = [i for section in groups for paragraph in section for i in paragraph]
    assert Counter(indices) == Counter(range(len(source)))
    joiner = '' if lang == 'zh' else ' '
    return [[joiner.join(source[i] for i in paragraph) for paragraph in section]
            for section in groups]


PROPOSAL = {}
SCRIPT = {}
AUDIT = {}
for lang in HEADINGS:
    old_proposal = sentences([p for _, ps in ORIGINAL_PROPOSAL[lang] for p in ps], lang)
    old_notes = sentences([p for ps in ORIGINAL_NOTES[lang] for p in ps], lang)
    proposal = reorder(old_proposal, PROPOSAL_GROUPS[lang], lang)
    proposal[0].insert(0, INPUT_SUMMARY[lang])
    PROPOSAL[lang] = list(zip(HEADINGS[lang], proposal))
    note_sections = list(zip(HEADINGS[lang], reorder(old_notes, SCRIPT_GROUPS[lang], lang)))
    SCRIPT[lang] = [note_sections[:2], note_sections[2:3], note_sections[3:]]
    AUDIT[lang] = {
        'original_proposal_sentences_preserved_verbatim': len(old_proposal),
        'original_script_sentences_preserved_verbatim': len(old_notes),
        'original_sentences_removed_or_duplicated': 0,
        'input_summary': 'Restates existing input types; introduces no new capability or requirement.',
        'new_functional_claims': 0,
    }
