"""Polish the supplied core proposal and produce a second paper-format edition."""
from copy import deepcopy
from pathlib import Path
import json
import re

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.section import WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/team_proposal_revision'
SOURCE=Path('/workspace/attachments/06bb99a1-b27f-45be-964f-8535c87ad449/HD Map Change Detection - Team Proposal (revised).docx')
REFERENCE=Path('/workspace/attachments/af1e3f7d-5628-4e2d-9a30-90a19469eb21/AIE1903 proposal.docx')

# These edits retain the original sections, technical scope, ownership and plan.
EDITS={
3: 'Road layouts and markings change, creating discrepancies between a stored HD map and current observations. This proposal describes an offline workflow that distinguishes detected discrepancies, supported changes and persistent map updates. It connects these assessments to map maintenance and downstream route and behavior planning, with evidence retained for inspection.',
8: 'This proposal presents the problem and related work, the system architecture with its fallback and extension, the planned evidence and evaluation, and the team roles and implementation schedule.',
10: 'The distinction between map–observation disagreement and map change, and relevant work on detection, reliability and structured updates.',
12: 'The four-stage architecture, its five implementation modules, design highlights, optional extension and fallback plan.',
14: 'How change candidates receive long-term, short-term or unresolved classifications, together with the resulting outputs, evaluation metrics and limitations.',
16: 'Module ownership, handover interfaces, weekly tasks and acceptance milestones.',
19: 'High-definition (HD) maps provide lane geometry, road markings and lane connections as prior information for autonomous driving. Changes to road layouts and markings can create discrepancies between stored maps and current sensor observations. Detecting and interpreting these discrepancies is an important part of maintaining useful maps for autonomous vehicles (Lambert & Hays, 2021).',
20: 'An observed mismatch does not necessarily indicate a genuine map change. Occlusion, missed detections, and localization or calibration errors can also produce apparent differences (Zhang et al., 2025). For example, a lane marking hidden behind a vehicle should not immediately be classified as deleted. Reliability assessment must consider both the observed disagreement and the availability of supporting evidence.',
21: 'The project connects data annotation, local map reliability assessment, map updating and behavior planning. Cui Yingting and Wang Zimo will annotate road features and surrounding-vehicle trajectories from existing driving data. Mei Ziheng will compare these observations with the prior map and produce local reliability judgments with supporting evidence. Huang Ziming will use these assessments to update sufficiently supported map elements and visualize the original and updated maps side by side. Pan Mingyang will combine the updated map, current observations and a specified destination to select actions such as continuing, turning left or right, and stopping, then demonstrate the resulting action sequence.',
22: 'The central question is whether explicit map reliability assessment reduces unsupported updates and supports more feasible planning decisions than reliance on the prior map alone. The minimum viable version will focus on local lane-marking geometry and static planning scenarios. The intended output is a reproducible Python prototype that connects annotated observations to reliability judgments, visible map updates and subsequent driving decisions. Execution will be represented through simplified planning visualizations, with conclusions limited to the evaluated offline scenarios.',
25: 'Reliability under uncertain observations. Zhang et al. (2025) examined how incomplete and inaccurate perception affects map change detection. Their method combines geometric matching, probabilistic modeling and observations from multiple vehicles. We adopt the principle that map–observation disagreement must be interpreted alongside observation reliability. Our implementation will combine geometric residuals, observation-quality checks and repeated supporting evidence. Outputs will be reported as reliability judgments and evidence scores, rather than calibrated change probabilities.',
30: 'The goal is to detect and assess temporary road disruptions in nuScenes and long-term structural changes in Argoverse using sensor data and prior HD maps. Offline experiments will evaluate their implications for planning and map maintenance under verified data conditions.',
32: 'The system has four stages, with reliability assessment governing both downstream branches. Perception produces candidates from aligned observations and verifies them across frames. Reliability assessment determines whether a discrepancy is significant and sufficiently supported. Planning and map maintenance use these assessments in separate branches, while versioned map updates also feed planning.',
33: 'Perception. Detects road-change candidates from aligned sensor observations and prior HD maps, then supplies multi-frame verification evidence and vehicle-behavior associations.',
34: 'Reliability analysis. Assesses whether detected discrepancies are significant and sufficiently supported, accounting for observation uncertainty.',
35: 'Planning. Evaluates route planning for temporary disruptions and behavior planning for long-term changes, subject to feasibility constraints.',
36: 'Shared map maintenance. Assesses persistence across visits, separates temporary events from long-term map updates, and visualizes the results.',
38: 'Figure 1  Four-stage architecture implemented by five modules. Reliability assessment supplies evidence to planning and map maintenance; versioned map updates also feed planning. Decisions retain links to their supporting evidence.',
40: 'The five modules specify their inputs, processing steps and outputs so that downstream decisions can be traced to the evidence that supports them.',
41: 'Sensor perception and map change detection (Cui Yingting). Aligns the four input types, extracts road elements, detects single-frame changes and vehicles, produces shared vehicle tracks, and evaluates perception and change detection.',
42: 'Multi-frame verification and behavior analysis (Wang Zimo). Reuses the shared tracks to verify changes across frames, recognize vehicle behavior, and associate changes with that behavior.',
43: 'Local map reliability assessment (Mei Ziheng). Combines observations and verification evidence into reliability classes with explicit reasons, linked to a map version and an observation window.',
44: 'Shared map updating and visualization (Huang Ziming). Classifies changes as long-term, short-term or unresolved; updates the base map or temporary event layer; manages versions; and produces before-and-after views.',
45: 'Route and behavior planning (Pan Mingyang). Uses updated maps and reliability information to produce local route updates, behavior rules, feasibility checks and planning BEV logs.',
48: 'Different planning responses. Route planning for temporary disruptions and behavior planning for long-term structural changes.',
49: 'Evidence before action. The workflow distinguishes detected discrepancies, supported changes and persistent changes. Planning decisions and map updates require supporting evidence; a single observation does not establish a persistent change.',
51: 'If the core system meets its milestones and time permits, the optional extension will add dynamic, interactive driving to the offline workflow:',
56: 'If a method or data source proves difficult to implement, the following alternatives will preserve an operational core workflow:',
64: 'The core objective is to classify observed road changes as long-term, short-term or unresolved, then update and visualize the map. Verified long-term structural changes modify the base map; short-term obstacles or occupancy are recorded in a temporary event layer.',
66: 'Inputs include the original map, perception candidates with locations and geometry, multi-frame verification results, observation times and visit records, and reliability decisions with observation-quality evidence. These upstream results support persistence assessment and map maintenance. Recorded sequences can provide time-ordered test inputs.',
68: 'First, associate candidates with map objects and check geometry, time and observation quality. Assess persistence using multi-frame and independent-visit evidence. Long-term structural changes update the base map only after reliability, object-matching and geometry checks. Each edit retains its before-and-after states, version, supporting evidence and rollback record.',
69: 'Short-term changes enter a temporary event layer: annotations over the base map that record location, affected area, observation time and validity without rewriting road structure. New verification may update or clear an event. Expiry or missing observations require review and do not establish clearance. Verified occupancy may retain an event annotation while its persistence classification remains unresolved. Insufficient evidence does not force a base-map update.',
71: 'Figure 2  Maintenance decision flow. The three classification outcomes are mutually exclusive. Only supported long-term structural changes permit base-map edits.',
73: 'Our final evidence will be a demonstration and evaluation of map-change persistence assessment, layered updating and visualization. It will show how long-term changes update the base map, how short-term changes enter the temporary event layer, and how decisions and edits retain evidence, versions and rollback records.',
74: 'Outputs include long-term, short-term and unresolved classifications, the updated base map, temporary events, before-and-after visualizations and update logs. Evaluation against reference labels will report misclassifications, missed changes and the unresolved proportion. Map-maintenance metrics will include false-update rate, eligible-update coverage, geometry error, update delay and rollback correctness. Eligible changes left unapplied will also be reported.',
76: 'Long-term decisions require valid evidence over a sufficient time span. Consecutive frames from one short recording do not independently establish a long-term change; persistent occupancy does not automatically establish a structural change. Real and simulated evidence will be reported separately. Without reference labels, a demonstration establishes the workflow rather than classification accuracy. The evidence does not guarantee permanence or real-world driving safety.',
77: "Existing work includes map and observation intake, controlled updates and rollback. Actual reliability outputs, real revisit evidence and reference labels remain to be completed. Sharing updates with other vehicles for planning is a future extension, outside this module's core deliverables and current evaluation requirements.",
79: 'The team covers five modules: sensor perception, multi-frame verification, map reliability, route and behavior planning, and shared map updating. External inputs are photographs, radar, lidar and HD maps. Change records, vehicle trajectories and reliability information are produced within the system.',
80: 'The project runs for six weeks from kickoff. Weeks 1–2 cover design, interfaces and baselines; Weeks 3–4 cover implementation and integration; Week 5 covers evaluation; and Week 6 covers demonstration and reporting. The tasks below are planned activities.',
84: 'Cui Yingting supplies shared detection and tracking outputs. Wang Zimo reuses these trajectories for multi-frame verification and behavior analysis, avoiding duplicate tracking pipelines. Mei Ziheng combines observations and verification evidence to provide local reliability assessments to Huang Ziming and Pan Mingyang.',
85: 'Huang Ziming manages map updates, versions and shared map visualizations. Pan Mingyang uses the updated maps to visualize planned routes, behaviors and feasibility. Reliability results are linked to map versions and observation windows. All modules use agreed timestamps, coordinate systems, object or change IDs, and evidence references.',
86: 'Multi-frame verification supports a change within the observed period. Huang Ziming assesses update validity using observation duration and reliability. When evidence is insufficient, the status remains a “persistent change candidate” or “insufficient evidence”; a short sequence alone does not establish a permanent change.',
88: 'Members develop their modules in parallel. Early interface samples are used only for module testing. End-to-end integration and formal evaluation use actual module outputs generated from the four raw input types.',
90: 'Figure 3  Parallel module development and shared milestones: interface samples in Week 2, an end-to-end scene in Week 4, and the demonstration and report in Week 6.',
92: 'By Week 2, all five modules will produce agreed interface samples. By Week 4, one scene will run from raw inputs through map updating and planning outputs. Week 6 will deliver a reproducible demonstration, module evaluations, failure cases and the team report.',
93: 'Planning work focuses on design and interfaces in Weeks 1–2, Python prototyping from Week 3, and experiments in Week 5. For formal testing, data is split by original scene and thresholds are tuned only on the development set. Evaluation annotations are excluded from runtime inputs.',
94: 'Appendix A, Table 2, provides the corresponding weekly tasks for each member.',
}


def polish_paragraph(p, text):
    old_runs=list(p.runs)
    normal=next((r for r in reversed(old_runs) if r.text),None)
    rpr=deepcopy(normal._r.rPr) if normal is not None and normal._r.rPr is not None else None
    lead=old_runs[0].text if old_runs and old_runs[0].bold else None
    p.clear()
    if lead and '. ' in text:
        first,rest=text.split('. ',1)
        r=p.add_run(first+'. ')
        if rpr is not None:r._r.append(deepcopy(rpr))
        r.bold=True
        r=p.add_run(rest)
    else:r=p.add_run(text)
    if rpr is not None:r._r.append(deepcopy(rpr))


def make_polished():
    doc=Document(SOURCE)
    before={i:doc.paragraphs[i].text for i in EDITS}
    for i,value in EDITS.items():polish_paragraph(doc.paragraphs[i],value)
    # Keep the opening overview on its own page, as in the source report.
    doc.paragraphs[17].paragraph_format.page_break_before=True
    inline=doc.inline_shapes[0]
    rid=inline._inline.graphic.graphicData.pic.blipFill.blip.embed
    doc.part.related_parts[rid]._blob=(OUT/'architecture.png').read_bytes()
    with Image.open(OUT/'architecture.png') as im:ratio=im.width/im.height
    inline.height=int(inline.width/ratio)
    doc.core_properties.title='HD Map Change Detection, Maintenance and Planning under Uncertain Observations'
    doc.core_properties.subject='Core proposal: edited architecture figure and language; original section structure retained.'
    doc.save(OUT/'01_HD_Map_Proposal_Polished.docx')
    (OUT/'editorial_changes.json').write_text(json.dumps({'source':SOURCE.name,'reference_format':REFERENCE.name,'edits':[{'paragraph':i,'before':before[i],'after':EDITS[i]} for i in EDITS],'preserved':['four main sections and subsection order','five modules and member ownership','both original tables, all weekly tasks','six-week schedule and milestones','datasets, technical scope and references'],'figure_1':'Explicit multi-frame module within the existing perception stage; same four-stage dependency structure.','figures_2_and_3':'Original figures retained.'},ensure_ascii=False,indent=2)+'\n')
    return doc


def configure_font(style,name='Times New Roman',size=10):
    style.font.name=name;style.font.size=Pt(size)
    fonts=style.element.get_or_add_rPr().get_or_add_rFonts()
    for key in list(fonts.attrib):
        if 'theme' in key.lower():del fonts.attrib[key]
    for slot in ('ascii','hAnsi','cs'):fonts.set(qn('w:'+slot),name)
    fonts.set(qn('w:eastAsia'),'Noto Serif CJK SC')
    style.font.color.rgb=RGBColor(0,0,0)


def columns(section,n):
    section.page_width=Inches(8.268);section.page_height=Inches(11.693)
    section.left_margin=section.right_margin=Inches(.63)
    section.top_margin=Inches(.63);section.bottom_margin=Inches(.67)
    section.header_distance=Inches(.23);section.footer_distance=Inches(.28)
    c=section._sectPr.find(qn('w:cols'))
    if c is None:c=OxmlElement('w:cols');section._sectPr.append(c)
    for child in list(c):c.remove(child)
    c.set(qn('w:num'),str(n));c.set(qn('w:space'),'360')
    section.different_first_page_header_footer=False


def section_break(doc,n,new_page=False):
    section=doc.add_section(WD_SECTION_START.NEW_PAGE if new_page else WD_SECTION_START.CONTINUOUS)
    columns(section,n)
    p=doc.paragraphs[-1]
    p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(0)
    p.paragraph_format.line_spacing=Pt(1)
    p.add_run().font.size=Pt(1)
    return section


def ieee_citations(text):
    for old,new in [('(Lambert & Hays, 2021)','[1]'),('(Zhang et al., 2025)','[4]'),('Lambert and Hays (2021)','Lambert and Hays [1]'),('Zhang et al. (2025)','Zhang et al. [4]'),('Wild et al. (2025)','Wild et al. [3]'),('Paden et al. (2016)','Paden et al. [2]')]:text=text.replace(old,new)
    return text


def add_text(doc,text,style='Normal',bold_prefix=False):
    p=doc.add_paragraph(style=style)
    if bold_prefix and '. ' in text:
        a,b=text.split('. ',1);p.add_run(a+'. ').bold=True;p.add_run(b)
    else:p.add_run(text)
    return p


def paper_table(doc,source,widths,fontsize):
    table=doc.add_table(rows=0,cols=len(widths));table.autofit=False
    for c,w in zip(table.columns,widths):c.width=Inches(w)
    for ri,row in enumerate(source.rows):
        cells=table.add_row().cells
        trpr=table.rows[-1]._tr.get_or_add_trPr()
        if ri==0:
            e=OxmlElement('w:tblHeader');trpr.append(e)
        nosplit=OxmlElement('w:cantSplit');trpr.append(nosplit)
        for ci,(src,c,w) in enumerate(zip(row.cells,cells,widths)):
            c.width=Inches(w)
            p=c.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.first_line_indent=Pt(0)
            p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(2)
            p.paragraph_format.line_spacing=1.04
            r=p.add_run(src.text);r.font.name='Times New Roman';r.font.size=Pt(fontsize);r.bold=ri==0 or ci==0
            tcpr=c._tc.get_or_add_tcPr()
            borders=OxmlElement('w:tcBorders')
            for edge in ('top','left','bottom','right'):
                e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'AAAAAA');borders.append(e)
            tcpr.append(borders)
            if ri==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'EEEEEE');tcpr.append(shade)
    return table


def make_paper(core):
    doc=Document()
    for name,size in [('Normal',10),('Title',23),('Heading 1',10.5),('Heading 2',10),('Caption',8.5),('List Bullet',10)]:configure_font(doc.styles[name],size=size)
    for border in doc.styles['Title'].element.xpath('.//w:pBdr'):
        border.getparent().remove(border)
    normal=doc.styles['Normal'].paragraph_format
    normal.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY;normal.first_line_indent=Inches(.12)
    normal.line_spacing=1.0;normal.space_after=Pt(3)
    normal.widow_control=True
    h1=doc.styles['Heading 1'];h1.font.bold=True;h1.font.small_caps=True
    h1.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER;h1.paragraph_format.first_line_indent=Pt(0)
    h1.paragraph_format.space_before=Pt(9);h1.paragraph_format.space_after=Pt(5);h1.paragraph_format.keep_with_next=True
    h2=doc.styles['Heading 2'];h2.font.bold=False;h2.font.italic=True
    h2.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT;h2.paragraph_format.first_line_indent=Pt(0)
    h2.paragraph_format.space_before=Pt(7);h2.paragraph_format.space_after=Pt(4);h2.paragraph_format.keep_with_next=True
    cap=doc.styles['Caption'];cap.font.bold=False;cap.paragraph_format.first_line_indent=Pt(0);cap.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
    cap.paragraph_format.space_after=Pt(6)
    columns(doc.sections[0],1)
    footer=doc.sections[0].footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)
    title=' '.join(core.paragraphs[1].text.split())
    p=doc.add_paragraph(title,'Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_after=Pt(14)
    for r in p.runs:r.italic=True
    author=doc.add_table(rows=2,cols=3);author.autofit=False
    names=['Cui Yingting','Wang Zimo','Mei Ziheng','Pan Mingyang','Huang Ziming']
    for c,name in zip([c for row in author.rows for c in row.cells],names):
        p=c.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_after=Pt(8)
        r=p.add_run(name+'\n');r.font.size=Pt(10)
        r=p.add_run('School of Artificial Intelligence\nThe Chinese University of Hong Kong, Shenzhen\nShenzhen, China');r.font.size=Pt(8.5)
    p=doc.add_paragraph('AIE1903_AD · Team project proposal · Six-week plan · November 2026')
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0)
    for r in p.runs:r.font.size=Pt(8.5)
    section_break(doc,2)
    p=doc.add_paragraph();p.paragraph_format.first_line_indent=Pt(0)
    p.add_run('Abstract—'+core.paragraphs[3].text).bold=True
    p=doc.add_paragraph();p.paragraph_format.first_line_indent=Pt(0)
    p.add_run('Keywords—HD map change detection; observation uncertainty; map reliability; map maintenance; route and behavior planning').bold=True

    paras=core.paragraphs
    ps={p._p:i for i,p in enumerate(paras)}
    table_index=0
    for el in core.element.body:
        if el.tag==qn('w:tbl'):
            if table_index==0:
                p=add_text(doc,'TABLE I. MEMBER RESPONSIBILITIES AND KEY DELIVERABLES','Caption');p.paragraph_format.keep_with_next=True
                paper_table(doc,core.tables[0],[.82,3.48,2.708],9.0)
                section_break(doc,2)
            else:
                p=add_text(doc,'TABLE II. WEEK-BY-WEEK TASKS FOR THE FIVE MODULES','Caption');p.paragraph_format.keep_with_next=True
                paper_table(doc,core.tables[1],[.58,1.071,1.071,1.071,1.071,1.071,1.073],8.0)
            table_index+=1
            continue
        if el not in ps:continue
        i=ps[el];p=paras[i];text=p.text.strip()
        if i<7 or i in (82,101) or not text and not p._p.xpath('.//w:drawing'):continue
        if i in (37,70,89):
            section_break(doc,1)
            imagepath=OUT/'architecture.png' if i==37 else OUT/'source_1'/('image2.png' if i==70 else 'image3.png')
            q=doc.add_paragraph();q.alignment=WD_ALIGN_PARAGRAPH.CENTER;q.paragraph_format.first_line_indent=Pt(0);q.paragraph_format.keep_with_next=True
            q.add_run().add_picture(str(imagepath),width=Inches(7.0))
            continue
        if i in (38,71,90):
            text=re.sub(r'^Figure (\d+)\s+',r'Fig. \1. ',text)
            add_text(doc,text,'Caption')
            section_break(doc,2)
            continue
        if i==81:section_break(doc,1)
        if i==100:
            section_break(doc,1,new_page=True)
            add_text(doc,'APPENDIX A. WEEK-BY-WEEK TASK PLAN','Heading 1')
            continue
        if i==7:
            add_text(doc,'Overview','Heading 2');continue
        if 9<=i<=16:
            q=add_text(doc,text,bold_prefix=False)
            q.paragraph_format.first_line_indent=Pt(0);q.paragraph_format.space_after=Pt(2)
            if i in (9,11,13,15):
                q.paragraph_format.keep_with_next=True
                for r in q.runs:r.bold=True
            for r in q.runs:r.font.size=Pt(9)
            continue
        if i in (17,28,62,78):
            roman={17:'I',28:'II',62:'III',78:'IV'}[i]
            add_text(doc,roman+'. '+re.sub(r'^\d+\s+','',text).upper(),'Heading 1');continue
        match=re.match(r'^([1-4])\.(\d+)\s+(.+)',text)
        if match:
            add_text(doc,chr(64+int(match.group(2)))+'. '+match.group(3),'Heading 2');continue
        if i==95:
            add_text(doc,'REFERENCES','Heading 1');continue
        if 96<=i<=99:
            q=add_text(doc,f'[{i-95}] '+text)
            q.paragraph_format.first_line_indent=Inches(-.18);q.paragraph_format.left_indent=Inches(.18)
            for r in q.runs:r.font.size=Pt(8.8)
            continue
        text=ieee_citations(text)
        has_label=bool(p.runs and p.runs[0].bold and p.runs[0].text.endswith('. '))
        q=add_text(doc,text,'List Bullet' if p.style.name=='List Bullet' else 'Normal',has_label)
        if p.style.name=='List Bullet':
            q.paragraph_format.left_indent=Inches(.12);q.paragraph_format.first_line_indent=Inches(-.12)
            q.paragraph_format.space_after=Pt(3)
    doc.core_properties.title=title
    doc.core_properties.author='Cui Yingting; Wang Zimo; Mei Ziheng; Pan Mingyang; Huang Ziming'
    doc.core_properties.subject='Core proposal content in the supplied AIE1903 paper-style format.'
    doc.save(OUT/'02_HD_Map_Proposal_AIE1903_Format.docx')
    return doc


if __name__=='__main__':
    OUT.mkdir(parents=True,exist_ok=True)
    core=make_polished();paper=make_paper(core)
    original=Document(SOURCE)
    assert len(original.paragraphs)==len(core.paragraphs)
    for a,b in zip(original.tables,core.tables):assert [[c.text for c in r.cells] for r in a.rows]==[[c.text for c in r.cells] for r in b.rows]
    assert len(core.tables)==2 and len(paper.tables)==3
    for a,b in zip(core.tables,paper.tables[1:]):assert [[c.text for c in r.cells] for r in a.rows]==[[c.text for c in r.cells] for r in b.rows]
    print('Created two Word documents; all source table cells and the original report section order are retained.')
