"""Export function-focused proposals, with assignments only in the team section."""
import json
from copy import deepcopy
from docx import Document
from docx.oxml.ns import qn
import build_dataset_model_proposal_versions as editions


def main():
    editions.OUT=editions.ROOT/'outputs/team_proposal_clean_architecture'
    editions.focused.ARCHITECTURE=editions.OUT/'architecture.png'
    editions.main()
    path=editions.OUT/'update_notes.json'
    audit=json.loads(path.read_text())
    names=[]
    for name in audit['outputs']:
        original=editions.OUT/name
        renamed=original.with_name(original.name.replace('_Updated',''))
        if name.startswith('02_'):
            # End in the existing two-column section; an empty closing section
            # can otherwise produce a blank trailing page in Word/PDF export.
            doc=Document(original)
            last=doc.paragraphs[-1]
            section=last._p.find('./'+qn('w:pPr')+'/'+qn('w:sectPr'))
            if not last.text and section is not None:
                body=doc._element.body
                body.remove(body.sectPr)
                body.append(deepcopy(section))
                body.remove(last._p)
            doc.save(original)
        original.rename(renamed)
        names.append(renamed.name)
    audit['outputs']=names
    audit['updates'] += [
        'Architecture figure shows functions and data flow without personal names',
        'Module headings and technical narrative omit personal assignments',
        'Member responsibilities are consolidated in the team-roles section',
        'Planning remains before the final Evaluation and Evidence stage',
    ]
    audit['unchanged'].remove('improved architecture image')
    path.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':
    main()
