"""Build a self-contained Chinese demo from actual data and real engine snapshots."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from map_update.demo import base_map, demo_records, T0
from map_update.engine import Maintainer, rollback
from map_update.scene import inspect_scene


def build(output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    actual = inspect_scene(ROOT/'AIE1903 原始资料', ROOT/'external/perception_delivery')
    records = demo_records()
    stages = []
    descriptions = [
        ('初始地图', 0, '尚无观测。先保留四条原始标线，等待支持证据。'),
        ('首次经过', .04, '一次有效访问只支持候选；占用进入事件层，对齐异常记录被拒绝。'),
        ('12小时后', 12.04, '已累计两次模拟访问，仍未达到三次访问和24小时跨度的演示门槛。'),
        ('26小时后', 26.04, '第三次一致观测通过门槛：一条标线被更新。占用和未明确类型的标线差异不写入基础地图。'),
        ('27小时后', 27.04, '充分观测确认占用位置恢复，临时事件解除；不是因为记录消失就自动清除。'),
    ]
    for i, (label, hour, description) in enumerate(descriptions):
        cutoff = str(T0+int(hour*3600*1e9))
        bundle = Maintainer(base_map()).run([] if i == 0 else records, cutoff)
        stages.append({'label': label, 'description': description, 'hour': hour, 'bundle': bundle})
    restored = rollback(stages[-1]['bundle'], 'v0')
    stages.append({'label':'回退原图','hour':27.04,'description':'恢复初始标线位置，同时生成新的回退版本；保留历史更新记录，原变化重新进入待复核状态。','bundle':restored})
    # Expected outcomes come from the engine; the page never substitutes a result.
    assert len(stages[2]['bundle']['versions']) == 1
    assert len(stages[3]['bundle']['versions']) == 2
    assert stages[3]['bundle']['events'][0]['status'] == 'applied'
    assert stages[3]['bundle']['events'][1]['status'] == 'temporary'
    assert stages[3]['bundle']['events'][2]['status'] == 'long_term_candidate'
    assert stages[3]['bundle']['events'][3]['independent_visits'] == 0
    assert stages[4]['bundle']['events'][1]['status'] == 'resolved'
    assert restored['current_map']['elements'] == restored['baseline']['elements']
    actual.pop('frame_evidence', None)
    data = {'actual':actual,'stages':stages,'scope':'actual single-pass replay + explicitly controlled synthetic engine demonstration; no planner results'}
    payload = json.dumps(data,ensure_ascii=False,allow_nan=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    template = (ROOT/'map_update/project_demo.html').read_text(encoding='utf-8')
    (output/'演示.html').write_text(template.replace('__DEMO_JSON__',payload),encoding='utf-8')
    (output/'demo_data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    summary={'actual_frames':len(actual['replay']),'actual_map_features':len(actual['reference_map']['elements']),'actual_candidates':len(actual['candidates']),'actual_map_updates':0,'actual_validation_checks':len(actual['raw_validation']['checks']),'synthetic_stages':len(stages),'synthetic_applied_updates':len(stages[3]['bundle']['versions'])-1,'rollback_restores_elements':True,'planner_output_present':False}
    (output/'demo_checks.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(summary,ensure_ascii=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True)
    build(parser.parse_args().out)
