"""Update data/model provenance in the focused proposal and export both styles."""
from pathlib import Path
from copy import deepcopy
import json
import re
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import build_focused_team_proposal as focused
from revise_team_proposal import columns, configure_font

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/team_proposal_datasets_models'

RELATED=[
    'Dataset sources. We use driving scenes from the official nuScenes dataset and devkit [6], including camera, LiDAR and radar observations together with poses, calibration and map information. These recordings support our temporary road-occupancy and map–observation consistency experiments. For structural map-change evaluation, Trust, but Verify (TbV) [1] provides the sensor/map benchmark, while ArgoTweak [3] adds structured priors and element-level change annotations. Prior/current map roles and edit-label semantics are verified before use; controlled perturbations are reported separately when reliable real-change labels are unavailable.',
    'Perception model. Our road-perception component uses YOLOP (You Only Look Once for Panoptic Driving Perception) [7]. The model jointly supports traffic-object detection, drivable-area segmentation and lane-line detection. Its lane predictions provide image-space road evidence for polyline extraction, projection and geometric map matching in this project. The official release is trained and evaluated on BDD100K; performance on our nuScenes scenes is assessed rather than assumed. YOLOP predictions are observations, while multi-frame verification, reliability assessment and map updating remain separate downstream steps.',
    'Reliability and planning. Work on uncertain perception motivates interpreting geometric disagreement together with observation quality and repeated evidence [4]. We use interpretable reliability judgments rather than assume calibrated probabilities. The distinction between route, behavior, motion planning and control [2] defines the static planning MVP and its optional dynamic extension.',
]
REFERENCES=[
    'Caesar, H., Bankiti, V., Lang, A. H., Vora, S., Liong, V. E., Xu, Q., Krishnan, A., Pan, Y., Baldan, G., & Beijbom, O. (2020). nuScenes: A multimodal dataset for autonomous driving. Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR). Dataset and devkit: https://github.com/nutonomy/nuscenes-devkit',
    'Wu, D., Liao, M.-W., Zhang, W.-T., Wang, X.-G., Bai, X., Cheng, W.-Q., & Liu, W.-Y. (2022). YOLOP: You only look once for panoptic driving perception. Machine Intelligence Research. https://doi.org/10.1007/s11633-022-1339-y. Official implementation: https://github.com/hustvl/YOLOP',
]


def report_version(source,target):
    doc=Document(source)
    for sec in doc.sections:columns(sec,1)
    for name,size in [('Normal',11),('Title',25),('Heading 1',15),('Heading 2',12),('Heading 3',11),('Caption',9)]:
        configure_font(doc.styles[name],name='Calibri',size=size)
    normal=doc.styles['Normal'].paragraph_format
    normal.line_spacing=1.07;normal.space_after=Pt(5);normal.first_line_indent=Pt(0)
    normal.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    for name in ['Heading 1','Heading 2','Heading 3']:
        s=doc.styles[name];s.font.italic=False;s.font.bold=True;s.font.small_caps=False
        s.font.color.rgb=RGBColor.from_string('193B5A' if name!='Heading 2' else '276E7A')
        s.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
        s.paragraph_format.space_before=Pt(10 if name=='Heading 1' else 7)
        s.paragraph_format.space_after=Pt(5)
    title=doc.styles['Title'];title.font.color.rgb=RGBColor.from_string('193B5A');title.font.bold=True
    header=doc.sections[0].header.paragraphs[0]
    header.text='AIE1903 | HD Map Change Detection, Maintenance and Planning'
    for r in header.runs:r.font.name='Calibri';r.font.size=Pt(8);r.font.color.rgb=RGBColor.from_string('617485')
    current=0
    for p in doc.paragraphs:
        if p.style.name=='Title':
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT
            for r in p.runs:r.italic=False;r.bold=True
            borders=OxmlElement('w:pBdr');line=OxmlElement('w:bottom')
            for k,v in {'val':'single','sz':'12','space':'8','color':'276E7A'}.items():line.set(qn('w:'+k),v)
            borders.append(line);p._p.get_or_add_pPr().append(borders)
        elif p.style.name=='Heading 1':
            for roman,num in [('IV.',4),('III.',3),('II.',2),('I.',1)]:
                if p.text.startswith(roman):
                    current=num;p.text=str(num)+'  '+p.text[len(roman):].strip().title();break
        elif p.style.name=='Heading 2':
            m=re.match(r'^([A-F])\.\s+(.+)',p.text)
            if m:p.text=f'{current}.{ord(m.group(1))-64}  '+m.group(2)
        elif p.style.name=='Heading 3':
            p.text=re.sub(r'^(\d+)\)\s+',r'2.3.\1  ',p.text)
        elif p.style.name=='Caption':
            p.text=p.text.replace('Fig. 1.','Figure 1.').replace('TABLE I.','Table 1.')
        for r in p.runs:
            if 'Section II.C' in r.text:r.text=r.text.replace('Section II.C','Section 2.3')
            if re.match(r'^\[\d+\]',p.text):r.font.size=Pt(9)
            if p.text.startswith('Pipeline. Estimate normal residual'):
                r.font.name='Times New Roman'
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for r in p.runs:r.font.name='Calibri';r.font.size=Pt(9)
    doc.core_properties.subject='Report edition: focused module details, nuScenes data provenance and YOLOP model description.'
    doc.save(target)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    focused.OUT=OUT/'build'
    focused.RELATED=RELATED
    focused.ADDITIONAL_REFERENCES=REFERENCES
    focused.EXPLICIT_RELATED_HEADINGS=True
    focused.MODULES=deepcopy(focused.MODULES)
    for i,(label,text) in enumerate(focused.MODULES[0]['parts']):
        if label=='Pipeline':
            text=text.replace('Extract lane-marking polylines with a pretrained detector or geometric image rules, project ground-level features, and match them using distance, direction and overlap.', 'Use pretrained YOLOP [7] lane predictions to extract lane-marking polylines, project ground-level features, and match them using distance, direction and overlap; geometric image rules remain a fallback.')
            focused.MODULES[0]['parts'][i]=(label,text)
    focused.build()
    source=focused.OUT/'HD_Map_Proposal_Focused_Revision.docx'
    paper=OUT/'02_HD_Map_Proposal_AIE1903_Format_Updated.docx'
    d=Document(source)
    d.core_properties.subject='AIE1903 paper edition: focused module details, nuScenes data provenance and YOLOP model description.'
    d.save(paper)
    report=OUT/'01_HD_Map_Proposal_Polished_Updated.docx'
    report_version(paper,report)
    for p in [paper,report]:
        d=Document(p);body='\n'.join(x.text for x in d.paragraphs)
        assert 'YOLOP' in body and 'nuScenes' in body and 'BDD100K' in body
        assert '[6]' in body and '[7]' in body
        assert not any(x in body for x in ['Overview','Appendix A','Module interfaces and responsibility boundaries'])
    audit={'base':'Latest focused team proposal; reviewer-requested removals retained.',
        'updates':['Explicit Related Work subsection','nuScenes dataset/devkit provenance','TbV and ArgoTweak roles','YOLOP model tasks and lane-prediction usage','Perception pipeline aligned with YOLOP','References 6 and 7 added'],
        'local_evidence':'AIE1903 原始资料/processed/road_perception/frame026_lane_fit_report.json: source = YOLOP lane prediction',
        'official_sources':['https://github.com/nutonomy/nuscenes-devkit','https://github.com/hustvl/YOLOP'],
        'unchanged':['five module owners','core map updating versus fleet-sharing extension','six-week milestones','improved architecture image'],
        'outputs':[report.name,paper.name]}
    (OUT/'update_notes.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
    print('Created both updated Word editions.')


if __name__=='__main__':main()
