"""Rebuild six aligned deliverables around update, publication and vehicle reuse."""
from pathlib import Path
import json
import re

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from docx.shared import Pt as DocPt
from docx.oxml.ns import qn
from build_separate_evidence_versions import document_base
from shared_map_revision_content import TITLES, PROPOSAL, NOTES

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/shared_map_revision'
OUT.mkdir(parents=True,exist_ok=True)
NAVY='142D43';TEAL='087F8C';MINT='E7F4F0';INK='22384A';MUTED='617485';PAPER='F6F8FA';WHITE='FFFFFF';BORDER='DBE4EA';CORAL='DA725D';GOLD='C39425';BLUE='477FB5'


class Deck:
    def __init__(self,lang):
        self.lang=lang;self.cn=lang=='zh';self.font='Noto Sans CJK SC' if self.cn else 'Arial'
        self.p=Presentation();self.p.slide_width=Inches(16);self.p.slide_height=Inches(9)
        self.p.core_properties.title=self.pick('共享地图更新与复用：证据与评估','Shared-Map Updates and Reuse: Evidence and Evaluation')
        self.p.core_properties.author=self.pick('课程项目小组','AIE1903 Project Team')

    def pick(self,cn,en):return cn if self.cn else en

    def box(self,s,x,y,w,h,fill=WHITE,border=None,kind=MSO_SHAPE.ROUNDED_RECTANGLE):
        q=s.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h));q.fill.solid();q.fill.fore_color.rgb=RGBColor.from_string(fill)
        if border:q.line.color.rgb=RGBColor.from_string(border);q.line.width=Pt(.8)
        else:q.line.fill.background()
        if kind==MSO_SHAPE.ROUNDED_RECTANGLE:q.adjustments[0]=.12
        return q

    def text(self,s,x,y,w,h,value,size=17,color=INK,bold=False,align=PP_ALIGN.LEFT):
        q=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=q.text_frame
        tf.clear();tf.word_wrap=True;tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0
        for i,part in enumerate(value.split('\n')):
            p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=part;p.alignment=align
            p.font.name=self.font;p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=RGBColor.from_string(color)
            p.line_spacing=1.10;p.space_after=Pt(2);p.space_before=Pt(0)
            rpr=p._p.get_or_add_pPr().get_or_add_defRPr();rpr.set('lang','zh-CN' if self.cn else 'en-US')
            ea=OxmlElement('a:ea');ea.set('typeface',self.font);rpr.append(ea)
        return q

    def line(self,s,x1,y1,x2,y2,color=TEAL,width=2):
        q=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2));q.line.color.rgb=RGBColor.from_string(color);q.line.width=Pt(width)
        return q

    def heading(self,num,subtitle):
        s=self.p.slides.add_slide(self.p.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(PAPER)
        self.box(s,0,0,16,.09,TEAL,kind=MSO_SHAPE.RECTANGLE)
        self.text(s,.55,.28,10,.23,self.pick('课程项目  /  共享地图更新与多车复用','AIE1903  /  SHARED-MAP UPDATES AND VEHICLE REUSE'),10.8,TEAL,True)
        self.box(s,11.7,.22,3.75,.31,MINT)
        self.text(s,11.8,.255,3.55,.23,self.pick('计划中的证据与评估','PLANNED EVIDENCE & EVALUATION'),10.2,TEAL,True,PP_ALIGN.CENTER)
        self.text(s,.55,.72,14.9,.67,TITLES[self.lang][num-1],31 if not self.cn else 33,NAVY,True)
        self.text(s,.57,1.42,14.8,.31,subtitle,14.2,MUTED)
        self.line(s,.55,8.57,15.45,8.57,BORDER,.8)
        self.text(s,.55,8.68,13.8,.20,self.pick('项目计划书 · 真实数据与受控仿真分别报告；共享与规划效果仍待验证。','Research proposal · Real and simulated evidence reported separately; sharing and planning remain to be validated.'),9.6,MUTED)
        self.text(s,14.55,8.66,.9,.25,f'{num:02d} / 03',10.8,TEAL,True,PP_ALIGN.RIGHT)
        s.notes_slide.notes_text_frame.text='\n\n'.join(NOTES[self.lang][num-1])
        for p in s.notes_slide.notes_text_frame.paragraphs:p.font.name=self.font
        return s

    def car(self,s,x,y,color=BLUE,scale=1):
        self.box(s,x,y,1.06*scale,.53*scale,color)
        self.box(s,x+.24*scale,y+.08*scale,.50*scale,.19*scale,'C8E5EB')
        for dx in [.14,.77]:
            self.box(s,x+dx*scale,y-.04*scale,.15*scale,.09*scale,INK,kind=MSO_SHAPE.RECTANGLE)
            self.box(s,x+dx*scale,y+.48*scale,.15*scale,.09*scale,INK,kind=MSO_SHAPE.RECTANGLE)

    def road(self,s,x,y,w=3.7,h=1.42):
        self.box(s,x,y,w,h,NAVY)
        self.line(s,x+.12,y+.23,x+w-.12,y+.23,'A8C1CD',1)
        self.line(s,x+.12,y+h-.23,x+w-.12,y+h-.23,'A8C1CD',1)
        for j in range(7):self.line(s,x+.15+j*(w-.3)/7,y+h/2,x+.35+j*(w-.3)/7,y+h/2,'92B0BE',1)

    def slide_one(self):
        s=self.heading(1,self.pick('最终展示：发现变化、更新地图、发布共享，再由另一辆车获取并重新规划。','The final demo: observe a change, update and publish it, then let another vehicle retrieve it and replan.'))
        self.box(s,.55,1.94,14.9,1.03,NAVY)
        quote=self.pick('我们的最终证据将是共享地图更新与复用的端到端演示及受控对照实验：\n一辆车发现的变化，经判断、分层更新与发布后，被另一辆车获取并用于重新规划。','Our final evidence will be an end-to-end demonstration and controlled comparisons showing how a change\nobserved by one vehicle is assessed, added to a shared map, published, and used by another vehicle for replanning.')
        self.text(s,.80,2.10,14.37,.77,quote,17.8 if self.cn else 17.3,WHITE)
        starts=[.55,5.64,10.73]
        for x in starts:self.box(s,x,3.25,4.72,3.84,WHITE,BORDER)
        self.text(s,.78,3.43,4.24,.32,self.pick('01  车辆甲：发现并核验','01  Vehicle A: observe and assess'),18,NAVY,True)
        self.road(s,1.06,4.02)
        self.car(s,1.37,4.54,BLUE,.9)
        self.box(s,3.85,4.35,.20,.55,CORAL,kind=MSO_SHAPE.RECTANGLE)
        self.line(s,2.48,4.68,3.64,4.60,GOLD,2.5)
        self.text(s,.81,5.67,4.18,.36,self.pick('观测 + 可靠性 + 持续性','Observation + reliability + persistence'),14.1,TEAL,True)
        self.text(s,.81,6.17,4.18,.70,self.pick('判断变化是否可信、影响哪里，\n并区分临时事件与结构变化。','Assess the evidence and affected area;\ndistinguish events from structural changes.'),14.2,MUTED)
        self.text(s,5.88,3.43,4.23,.32,self.pick('02  共享端：更新并发布','02  Shared map: update and publish'),17.4,NAVY,True)
        for j,(label,c) in enumerate([(self.pick('临时事件层','Temporary events'),GOLD),(self.pick('版本化基础地图','Versioned base map'),TEAL),(self.pick('发布记录与回退历史','Publication and rollback history'),BLUE)]):
            self.box(s,6.16,4.04+j*.45,3.67,.35,[ 'FFF3DB',MINT,'E9F0F8'][j])
            self.text(s,6.31,4.075+j*.45,3.37,.24,label,12.4,c,True,PP_ALIGN.CENTER)
        self.text(s,5.91,5.67,4.18,.36,self.pick('地图变化可见，更新来源可查','Visible map changes, traceable updates'),14.1,TEAL,True)
        self.text(s,5.91,6.17,4.18,.70,self.pick('发布地图版本、事件状态与时效，\n供其他车辆按统一接口获取。','Publish map versions, event states and\nfreshness through a common interface.'),14.2,MUTED)
        self.text(s,10.98,3.43,4.22,.32,self.pick('03  车辆乙：接收并使用','03  Vehicle B: receive and use'),18,NAVY,True)
        self.road(s,11.23,4.02)
        self.car(s,11.43,4.57,TEAL,.72)
        self.box(s,13.39,4.62,.27,.32,CORAL,kind=MSO_SHAPE.RECTANGLE)
        pts=[(12.30,4.83),(12.70,4.83),(13.03,4.35),(13.94,4.35),(14.42,4.83)]
        for a,b in zip(pts,pts[1:]):self.line(s,*a,*b,'76DFC3',2.7)
        self.text(s,11.0,5.67,4.18,.36,self.pick('获取更新，结合本车感知重新规划','Retrieve updates and replan locally'),14.1,TEAL,True)
        self.text(s,11.0,6.17,4.18,.70,self.pick('核实不可通行时避开受影响通路；\n无替代方案时明确报告失败。','Avoid confirmed impassable routes;\nreport failure if no feasible option exists.'),14.2,MUTED)
        for x in [5.31,10.40]:self.text(s,x,4.62,.32,.46,'→',25,TEAL,True)
        self.text(s,.59,7.29,14.80,.27,self.pick('图示为计划中的共享与规划流程，尚不是实测路线；演示将检查发布、接收、应用是否真正发生。','Illustrative sharing and route concept, not a measured planner result. The demo will verify actual publication, receipt and application.'),10.7,MUTED)
        self.box(s,.55,7.76,14.9,.54,MINT)
        self.text(s,.79,7.89,14.40,.28,self.pick('可检查的最终证据：地图前后差异  ·  更新原因  ·  发布与接收版本  ·  另一车辆的规划响应','Inspectable evidence: map differences  ·  reasons for updates  ·  published and received versions  ·  another vehicle’s planning response'),13.7,TEAL,True)

    def slide_two(self):
        s=self.heading(2,self.pick('临时障碍及时共享；持续性结构变化通过检查后，再写入基础地图。','Share verified temporary obstacles promptly; write persistent structural changes only after the required checks.'))
        rows=[
            (1.97,'FFF3DB',GOLD,self.pick('临时障碍 / 道路占用','Temporary obstacle / occupancy'),self.pick('经核验后进入事件层，及时共享。','Verify, then share promptly in the event layer.'),self.pick('保留影响区域、观测时间与有效状态。\n过期或缺测不自动代表道路已恢复。','Keep the affected area, observation time and validity.\nExpiry or missing observations do not prove clearance.')),
            (3.80,MINT,TEAL,self.pick('持续性的地图结构变化','Persistent structural change'),self.pick('通过可靠性、持续性与几何检查后更新。','Update after reliability, persistence and geometry checks.'),self.pick('核实地图对象与完整观测几何。\n基础地图保留版本、证据和回退记录。','Verify the target object and observed geometry.\nKeep base-map versions, evidence and rollback records.')),
            (5.63,'EBEFF4',MUTED,self.pick('证据不足 / 类型未明确','Insufficient or unresolved evidence'),self.pick('保留待核实状态，继续收集证据。','Retain an unresolved status and collect more evidence.'),self.pick('不据此改写基础地图的几何。','Do not rewrite base-map geometry on this evidence.')),
        ]
        for i,(y,bg,c,title,action,body) in enumerate(rows):
            h=1.64 if i<2 else 1.25
            self.box(s,.55,y,9.31,h,WHITE,BORDER)
            self.box(s,.78,y+.22,.51,.51,c,kind=MSO_SHAPE.OVAL)
            self.text(s,.78,y+.305,.51,.26,str(i+1),17,WHITE,True,PP_ALIGN.CENTER)
            self.text(s,1.52,y+.17,8.02,.32,title,18.2,c,True)
            self.text(s,1.52,y+.62,8.01,.28,action,14.9,INK,True)
            self.text(s,1.52,y+1.03 if i<2 else y+.91,8.01,.52 if i<2 else .23,body,13.6,MUTED)
        self.box(s,10.13,1.97,5.32,4.91,NAVY)
        self.text(s,10.40,2.19,4.78,.35,self.pick('每次发布都要说清楚','Every publication needs context'),19.0,WHITE,True)
        fields=[self.pick('对象与位置：改的是哪里','Object and location: what is affected'),self.pick('图层与版本：用的是哪一版','Layer and version: what should be applied'),self.pick('时间与状态：信息是否仍有效','Time and status: whether it is still valid'),self.pick('来源与原因：为什么做出修改','Source and reason: why it was changed')]
        for i,value in enumerate(fields):
            self.box(s,10.41,2.88+i*.59,.07,.29,['65D5BB','8EB9E7','E0B85F','E8A18B'][i],kind=MSO_SHAPE.RECTANGLE)
            self.text(s,10.66,2.84+i*.59,4.48,.40,value,13.7,'E5EFF7')
        self.box(s,10.41,5.51,4.76,.95,'244D51')
        self.text(s,10.63,5.67,4.31,.60,self.pick('接收端核对版本与时效，\n再把有效更新交给规划器。','The receiver checks version and freshness,\nthen passes valid updates to its planner.'),14.4,'BDEDDD',True)
        self.box(s,.55,7.10,14.9,1.18,MINT)
        self.text(s,.81,7.27,14.35,.31,self.pick('规划如何响应？先判断实际影响，再决定路线。','How should planning respond? Assess the actual impact before choosing a route.'),17.4,TEAL,True)
        self.text(s,.81,7.76,14.30,.41,self.pick('已确认不可通行：避开受影响通路或报告无解。部分占用 / 不确定：结合本车感知、覆盖与可行性检查处理。','Confirmed impassability: avoid affected routes or report no feasible plan. Partial / uncertain occupancy: use local perception and feasibility checks.'),13.1,INK)

    def slide_three(self):
        s=self.heading(3,self.pick('评估完整链路：地图更新是否正确、接收端是否一致，以及规划是否得到帮助。','Evaluate the full chain: update correctness, consistency at the receiver, and usefulness for planning.'))
        cols=[
            (TEAL,self.pick('01  地图改得对','01  Correct map maintenance'),self.pick('分层与写入决策是否合理？','Are layer and write decisions appropriate?'),self.pick('错误更新比例 · 更新覆盖率\n几何误差 · 更新延迟','False-update rate · Update coverage\nGeometry error · Update delay'),self.pick('同时统计该更新却未更新的变化。\n零写入不等于已经证明准确。','Count eligible changes still not updated.\nZero writes do not establish accuracy.')),
            (BLUE,self.pick('02  更新传得到','02  Consistent sharing'),self.pick('另一接收端是否获得正确状态？','Does the receiver apply the correct state?'),self.pick('发布→应用延迟 · 版本一致性\n重复 / 过期处理 · 回退传播','Publication-to-application latency\nVersions · Duplicates · Expiry · Rollback'),self.pick('检查发布、接收、应用记录，\n而不只展示上传成功的图标。','Inspect publication, receipt and application\nrecords, beyond an upload indicator.')),
            (CORAL,self.pick('03  其他车辆用得上','03  Useful planning response'),self.pick('共享信息如何影响路线选择？','How does shared information affect routes?'),self.pick('可行路线比例 · 路线长度\n无可行方案与失败原因','Feasible-route rate · Route length\nNo-feasible-plan outcomes and reasons'),self.pick('路线长度只在双方都可行时比较。\n是否改善，由实验结果回答。','Compare lengths where both are feasible.\nAny improvement must be measured.')),
        ]
        for i,(c,title,q,metrics,body) in enumerate(cols):
            x=.55+i*5.07;self.box(s,x,1.97,4.76,3.01,WHITE,BORDER)
            self.box(s,x+.23,2.20,.07,.42,c,kind=MSO_SHAPE.RECTANGLE)
            self.text(s,x+.46,2.17,4.04,.34,title,17.6,c,True)
            self.text(s,x+.25,2.76,4.24,.44,q,13.6,INK)
            self.text(s,x+.25,3.36,4.24,.65,metrics,15.1,c,True)
            self.text(s,x+.25,4.22,4.24,.55,body,12.9,MUTED)
        self.text(s,.59,5.18,14.8,.29,self.pick('三组规划对照：相同本车感知、起终点与可行性检查，仅改变共享信息的使用策略。','Three planning comparisons: identical local observations, start/goal and feasibility checks; different use of shared information.'),12.1,TEAL,True)
        strategies=[self.pick('一  不使用共享更新','A  No shared updates'),self.pick('二  共享候选采用固定惩罚','B  Fixed penalties for shared candidates'),self.pick('三  可靠性与分层更新','C  Reliability-aware layered updates')]
        for i,value in enumerate(strategies):
            x=.55+i*5.07;self.box(s,x,5.68,4.76,.66,MINT)
            self.text(s,x+.20,5.87,4.36,.32,value,13.9,TEAL,True,PP_ALIGN.CENTER)
        self.box(s,.55,6.67,7.31,1.19,WHITE,BORDER);self.box(s,8.14,6.67,7.31,1.19,WHITE,BORDER)
        self.text(s,.80,6.83,6.81,.27,self.pick('已有原型','CURRENT PROTOTYPE'),12.1,TEAL,True)
        self.text(s,.80,7.20,6.81,.48,self.pick('真实地图与观测接入；受控更新、版本和回退。','Real-map and observation intake; controlled updates,\nversion records and rollback.'),13.5,INK)
        self.text(s,8.39,6.83,6.81,.27,self.pick('仍待完成与联调','STILL TO BUILD AND INTEGRATE'),12.1,GOLD,True)
        self.text(s,8.39,7.20,6.81,.48,self.pick('真实可靠性、发布与接收端、规划对照和真实复访。','Real reliability outputs, publisher/receiver, planning\ncomparisons and real revisits.'),13.5,INK)
        self.text(s,.59,8.10,14.8,.30,self.pick('结论限定于测试条件：不保证变化永久存在、适配所有实车系统，或证明真实驾驶安全。','Claims stay within test conditions: no guarantee of permanence, universal vehicle compatibility, or real-world driving safety.'),11.4,MUTED)

    def save(self,folder):
        self.slide_one();self.slide_two();self.slide_three()
        for s in self.p.slides:
            body='\n'.join(x.text for x in s.shapes if x.has_text_frame)+'\n'+s.notes_slide.notes_text_frame.text
            assert not re.search('[A-Za-z]' if self.cn else '[\u4e00-\u9fff]',body)
        self.p.save(folder/('共享地图_证据与评估_中文版.pptx' if self.cn else 'Shared_Map_Evidence_Evaluation_EN.pptx'))


def save_document(doc, path, lang):
    # Theme fonts can override explicit CJK fonts during Word/PDF rendering.
    font = 'Noto Sans CJK SC' if lang == 'zh' else 'Arial'
    for style in doc.styles:
        if not hasattr(style, 'font'):
            continue
        rpr = style.element.get_or_add_rPr()
        fonts = rpr.get_or_add_rFonts()
        for key in list(fonts.attrib):
            if 'theme' in key.lower():
                del fonts.attrib[key]
        for slot in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
            fonts.set(qn('w:' + slot), font)
    doc.save(path)


def documents(lang,folder):
    cn=lang=='zh';title='共享地图更新与复用：证据与评估' if cn else 'Shared-Map Updates and Reuse'
    subtitle='项目计划书正文｜更新、共享与其他车辆使用' if cn else 'Proposal section | Evidence and evaluation of update, sharing and vehicle reuse'
    doc=document_base(lang,title,subtitle)
    for heading,paras in PROPOSAL[lang]:
        doc.add_heading(heading,1)
        for text in paras:doc.add_paragraph(text)
    name='共享地图_Proposal_中文版' if cn else 'Shared_Map_Proposal_EN'
    save_document(doc, folder/(name+'.docx'), lang)
    md='# '+title+'\n\n'+'\n\n'.join('## '+h+'\n\n'+'\n\n'.join(ps) for h,ps in PROPOSAL[lang])
    (folder/(name+'.md')).write_text(md,encoding='utf-8')
    title='共享地图更新与复用：逐页讲稿' if cn else 'Shared-Map Updates and Reuse: Script'
    subtitle='对应三页演示｜约4至5分钟' if cn else 'Three corresponding slides | Approximately 4–5 minutes'
    doc=document_base(lang,title,subtitle)
    for i,paras in enumerate(NOTES[lang]):
        if i:doc.add_page_break()
        prefix=f'第{i+1}页｜' if cn else f'Slide {i+1} — '
        doc.add_heading(prefix+TITLES[lang][i],1)
        for text in paras:
            p=doc.add_paragraph(text);p.paragraph_format.space_after=DocPt(11)
            for r in p.runs:r.font.size=DocPt(12)
    name='共享地图_讲稿_中文版' if cn else 'Shared_Map_Script_EN'
    save_document(doc, folder/(name+'.docx'), lang)
    plain='\n\n'.join((f'第{i+1}页｜' if cn else f'Slide {i+1} — ')+TITLES[lang][i]+'\n\n'+'\n\n'.join(ps) for i,ps in enumerate(NOTES[lang]))
    (folder/(name+'.txt')).write_text(plain,encoding='utf-8')
    for value in [md,plain]:assert not re.search('[A-Za-z]' if cn else '[\u4e00-\u9fff]',value)


if __name__=='__main__':
    for lang,sub in [('zh','中文'),('en','English')]:
        folder=OUT/sub;folder.mkdir(parents=True,exist_ok=True)
        Deck(lang).save(folder);documents(lang,folder)
        print('Generated:',sub,'3 slides, proposal, matching script')
    (OUT/'revision_scope.json').write_text(json.dumps({'objective':'versioned shared-map maintenance and use by another vehicle','temporary_events':'share promptly after verification; do not wait for structural persistence','structural_changes':'require reliability, persistence, object and geometry checks','publishing_receiving_planning':'planned, not currently demonstrated as implemented','recorded_sequence_replay':'test-input method, not final outcome','languages':'separate zh/en; aligned content','deliverables':6},ensure_ascii=False,indent=2)+'\n')
