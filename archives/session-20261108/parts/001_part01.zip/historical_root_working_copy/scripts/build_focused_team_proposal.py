"""Apply the team feedback: concise front matter, detailed modules, short team plan."""
from pathlib import Path
import json
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from revise_team_proposal import configure_font, columns, section_break, paper_table

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/team_proposal_focused'
ARCHITECTURE=ROOT/'outputs/team_proposal_revision/architecture.png'
BASE=ROOT/'outputs/team_proposal_revision/01_HD_Map_Proposal_Polished.docx'
ADDITIONAL_REFERENCES=[]
EXPLICIT_RELATED_HEADINGS=False

MODULES=[
    {
        'title':'Sensor perception and map change detection', 'owner':'Cui Yingting',
        'source':'Perception_Proposal_Draft.docx: synchronization, road observations, single-frame detection and vehicle tracking',
        'parts':[
            ('Input', 'Camera and LiDAR observations, available radar data, ego poses, calibration, and local map geometry. The prior/current role of each map and the meaning of ArgoTweak old/new annotations must be checked before constructing change labels.'),
            ('Pipeline', 'Select representative scenes, then use LiDAR timestamps to select nearby camera frames and match or interpolate poses, recording time offsets. Transform observations into City coordinates and crop the local map. Extract lane-marking polylines with a pretrained detector or geometric image rules, project ground-level features, and match them using distance, direction and overlap. Measure geometric disagreement with mean nearest-point distances in both directions. Compare known marking attributes; unmatched observations become insertion candidates, while missing map features become deletion candidates only with sufficient visibility. Lane-use and topology changes require separate semantic or connectivity evidence.'),
            ('Tracking', 'Use pretrained vehicle detections and associated LiDAR clusters for 3D positions, followed by constant-velocity Kalman prediction and distance-gated Hungarian matching. Retain 2D-only tracks when depth is insufficient. Predicted positions are flagged separately from measurements, and track IDs are not continued across unrelated clips.'),
            ('Output and conditions', 'Provide synchronized frame records, map elements, candidate IDs/types/geometries/timestamps and shared vehicle tracks with velocity, heading and measurement flags. Reject invalid alignment or synchronization; occlusion or a missed marking alone does not establish deletion.'),
        ],
    },
    {
        'title':'Multi-frame verification and behavior analysis', 'owner':'Wang Zimo',
        'source':'Perception_Proposal_Draft.docx: multi-frame fusion, trajectory features, behavior recognition and spatiotemporal association',
        'parts':[
            ('Input', 'Single-frame candidates, visibility information and the shared vehicle tracks supplied by perception. This module reuses those tracks rather than running a second tracker.'),
            ('Pipeline', 'Group existing features by map-element ID and new features by spatial proximity. Count valid observable frames N_valid and frames supporting the same change N_support. For N_valid > 0, use S = N_support / N_valid with minimum-count and support-ratio thresholds; otherwise retain insufficient evidence. Consolidate supported geometry in City coordinates. S describes repeated observation support, not a calibrated change probability.'),
            ('Behavior and association', 'Derive speed, unwrapped heading change, lane-normal displacement and trajectory completeness. Apply rules for straight motion, stopping and turning; retain U-turn and detour candidates only when the trajectory supports the complete maneuver. Associate behavior events with change regions using minimum spatial distance, temporal proximity and track completeness. Output associated, not_associated or uncertain; no trackable vehicle is a separate unavailable-evaluation case.'),
            ('Output and conditions', 'Produce verification records, behavior events and change–vehicle association records with IDs, time windows, geometry and evidence counts. Low-speed heading, short tracks and occlusion may leave behavior unresolved. Association establishes spatiotemporal proximity, not causation; multi-frame agreement alone does not prove long-term persistence.'),
        ],
    },
    {
        'title':'Local HD map reliability assessment', 'owner':'Mei Ziheng',
        'source':'proposal_member3.docx, supported by M3 draft.docx',
        'parts':[
            ('Input', 'Matched map/observation geometry or signed lane-normal residuals, map version and time window, field-of-view and occlusion information, quality/alignment flags, and upstream evidence counts. Retain verified unchanged and sufficiently observed elements to estimate normal error.'),
            ('Pipeline', 'Estimate normal residual location and dispersion from unchanged scenes. A robust one-dimensional scale is σ̂ = 1.4826 × median|eᵢ − median(e)|; reliable two-dimensional correspondences can support covariance estimation [5]. Test new residuals with the normalized statistic T = (e − μ)² / σ² or the Mahalanobis statistic T = (r − μ)ᵀΣ⁻¹(r − μ). Set thresholds from held-out unchanged scenes; use theoretical chi-square references only when their assumptions are supported.'),
            ('Quality gate and decision', 'Project map elements into camera views and measure effective coverage C_eff = L_valid / L_target, using area weighting for crosswalks. Valid evidence must be in view, unoccluded, adequately resolved and geometrically aligned. Apply this quality gate before the anomaly test and use repeated upstream support as an additional check. Return No Significant Mismatch, Suspected Map Change, Needs Further Verification or Insufficient Evidence.'),
            ('Output and conditions', 'Export element-level CSV/JSON records containing residuals, anomaly statistics, coverage, support counts, decision and reason, linked to the map version/window. Missing detections do not themselves establish poor visibility. Anomaly scores and p-values are not change probabilities; Bayesian updating is optional and requires defensible priors and labeled detection errors.'),
        ],
    },
    {
        'title':'Map updating, evaluation and evidence', 'owner':'Huang Ziming',
        'source':'Shared_Map_Proposal_One_Page_CN-2(1).docx, with the agreed core/extension scope and final evidence-aggregation responsibility',
        'parts':[
            ('Input', 'Map elements, observed geometry and change records from perception/verification, coverage and reliability decisions, plus routes, behavior decisions and feasibility logs from planning. Collect evaluation records from all upstream modules. Match inputs by scene, element ID, map version and observation window; retain evidence provenance.'),
            ('Pipeline', 'Initialize a versioned JSON map with base-map, temporary-event and evidence records. Associate existing elements by ID and new candidates by distance, direction and overlap. Maintain first/last observation times, valid observation batches, cross-visit support and geometric consistency. Use a rule-based state machine to classify short-term, supported long-term or unresolved changes; thresholds are selected on development data. Adjacent frames from one pass do not count as independent visits.'),
            ('Updating', 'Record short-term obstacles or occupancy in the temporary event layer with location, affected area, observation time and validity. Supported long-term structural changes may insert, modify or deactivate base-map elements after reliability and geometry checks. A discrepancy score without the required geometry cannot trigger a geometry edit. Verified current occupancy may retain an event annotation while persistence remains unresolved; expiry or missing observations does not prove clearance.'),
            ('Evaluation and evidence', 'As the final aggregation module, assemble the team’s scene-linked evidence: upstream module metrics, planning comparisons, map-update correctness, before-and-after views, decision histories and failure cases. Keep real and controlled results separate, report unresolved cases, and state which claims each result supports. Module owners supply their evaluation records; this stage consolidates them.'),
            ('Output and conditions', 'Deliver the final evidence package, evaluation summary, versioned maps, update histories, before-and-after BEV views and rollback records. Fleet sharing remains an extension. Long-term eligibility does not guarantee permanence. Real revisit evidence is needed to validate persistence; controlled simulations are reported separately when only short recordings are available.'),
        ],
    },
    {
        'title':'Local route and behavior planning', 'owner':'Pan Mingyang',
        'source':'122 (1).docx',
        'parts':[
            ('Input', 'The current prior map with verified lane connectivity and drivable-area geometry, ego pose/speed/time, a destination, change records and reliability evidence. Obstacle footprints come from independent annotation or an agreed upstream interface with documented conservative dimensions. Use only information available at decision time; aligned vehicle tracks are required for the dynamic extension.'),
            ('Pipeline', 'Build a directed lane graph and run A* with nonnegative distance costs and an admissible heuristic. Associate changes with affected lanes by ID and spatial overlap while respecting encoded direction and turn restrictions. No Significant Mismatch retains the original cost; Suspected Map Change adds a nonnegative uncertainty penalty. Needs Further Verification or Insufficient Evidence limits local operation to adequately observed space and triggers verification or stopping-feasibility assessment. Remove edges only when independent evidence confirms impassability; a missing marking is not a lane closure.'),
            ('Feasibility and extension', 'The MVP uses geometric routes and static lane-keeping/stopping decisions. Reject candidates outside verified drivable space, violating encoded rules or intersecting buffered obstacle footprints. Rank remaining candidates and report no feasible plan with reasons if all fail; braking is also checked. A later dynamic extension uses constant-velocity prediction and sampled speed profiles, checking speed, acceleration, curvature, stopping distance and time-aligned/swept occupancy. Scripted futures are sensitivity cases, not calibrated probabilities.'),
            ('Output and conditions', 'Deliver a Python planner, route/behavior BEV views and JSON/CSV logs of feasibility, rejection reasons, runtime and timed trajectories when available. Pass planning outputs and evaluation records to the final evidence-aggregation stage. Static planning is the minimum viable scope; vehicle control and closed-loop safety claims are outside it.'),
        ],
    },
]

# Implementation and presentation order: planning precedes final aggregation.
MODULES.sort(key=lambda m: ['Cui Yingting','Wang Zimo','Mei Ziheng','Pan Mingyang','Huang Ziming'].index(m['owner']))

INTRO=[
    'HD maps provide lane geometry, markings and connectivity as priors for autonomous driving. Road changes can invalidate those priors, but an observed mismatch may also arise from occlusion, missed detections or alignment error. A hidden lane marking therefore cannot be treated as deleted without sufficient evidence. The project asks whether explicit reliability assessment reduces unsupported map updates and supports more feasible planning decisions than reliance on the prior map alone.',
    'Our contribution is an inspectable Python workflow connecting perception, multi-frame verification, reliability assessment and local planning to a final map-update and evidence-aggregation stage. The minimum viable version focuses on local lane-marking geometry and static planning scenarios. Recorded observations drive offline experiments; outputs include evidence-linked decisions, visible map edits and simplified planning views.',
]
RELATED=[
    'Trust, but Verify provides a sensor/map change-detection benchmark [1]; ArgoTweak adds structured priors and element-level edit annotations [3]. Their map roles and annotation semantics must be verified before use. Work on uncertain perception motivates interpreting geometric disagreement together with observation quality and repeated evidence [4]. We use interpretable judgments rather than assume calibrated probabilities. The distinction between route, behavior, motion planning and control [2] defines the scope of the planning MVP and its optional dynamic extension.',
]


def paragraph(doc,text,lead=None,style='Normal'):
    p=doc.add_paragraph(style=style)
    if lead:p.add_run(lead+'. ').bold=True
    # Use native superscript formatting for the inverse; this avoids a fallback
    # font placing the Unicode superscript-minus out of reading order in PDF.
    chunks=text.split('Σ⁻¹')
    for i,chunk in enumerate(chunks):
        if i:
            p.add_run('Σ')
            r=p.add_run('−1');r.font.superscript=True
        p.add_run(chunk)
    return p


def make_table(doc,headers,rows,widths,fontsize=8.8):
    donor=Document();t=donor.add_table(rows=0,cols=len(headers))
    for values in [headers]+rows:
        for cell,value in zip(t.add_row().cells,values):cell.text=value
    return paper_table(doc,t,widths,fontsize)


def setup():
    doc=Document()
    for name,size in [('Normal',10),('Title',22),('Heading 1',10.5),('Heading 2',10),('Heading 3',10),('Caption',8.5)]:configure_font(doc.styles[name],size=size)
    for border in doc.styles['Title'].element.xpath('.//w:pBdr'):border.getparent().remove(border)
    n=doc.styles['Normal'].paragraph_format
    n.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY;n.first_line_indent=Inches(.12)
    n.line_spacing=1.0;n.space_after=Pt(3);n.widow_control=True
    for name in ['Heading 1','Heading 2','Heading 3']:
        s=doc.styles[name];s.paragraph_format.first_line_indent=Pt(0);s.paragraph_format.keep_with_next=True
        s.paragraph_format.space_before=Pt(8 if name=='Heading 1' else 6);s.paragraph_format.space_after=Pt(4)
        s.font.bold=name!='Heading 2';s.font.italic=name=='Heading 2'
        s.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER if name=='Heading 1' else WD_ALIGN_PARAGRAPH.LEFT
    doc.styles['Heading 1'].font.small_caps=True
    cap=doc.styles['Caption'];cap.font.bold=False;cap.paragraph_format.first_line_indent=Pt(0)
    cap.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT;cap.paragraph_format.space_after=Pt(6)
    columns(doc.sections[0],1)
    footer=doc.sections[0].footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)
    return doc


def build():
    OUT.mkdir(parents=True,exist_ok=True)
    doc=setup()
    title='HD Map Change Detection, Maintenance and Planning under Uncertain Observations'
    p=paragraph(doc,title,style='Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0)
    p.paragraph_format.space_after=Pt(10)
    for r in p.runs:r.italic=True
    for text,size in [
        ('Cui Yingting · Wang Zimo · Mei Ziheng · Pan Mingyang · Huang Ziming',10),
        ('School of Artificial Intelligence, The Chinese University of Hong Kong, Shenzhen',9),
        ('AIE1903_AD · Team project proposal · Six-week plan · November 2026',8.5),
    ]:
        p=paragraph(doc,text);p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0)
        for r in p.runs:r.font.size=Pt(size)
    section_break(doc,2)
    abstract='We propose an evidence-based workflow for HD map change detection, reliability assessment, map maintenance and local planning. The system combines aligned sensor observations, multi-frame verification and uncertainty-aware checks to distinguish supported changes from insufficient evidence. It records short-term events separately from long-term structural edits and links decisions to map versions and observation windows. A reproducible Python prototype will evaluate module accuracy, update correctness and planning feasibility under verified real-data and controlled synthetic conditions.'
    p=paragraph(doc,'Abstract—'+abstract);p.paragraph_format.first_line_indent=Pt(0)
    for r in p.runs:r.bold=True
    p=paragraph(doc,'Keywords—HD map change detection; multi-frame verification; reliability; map updating; local planning')
    p.paragraph_format.first_line_indent=Pt(0)
    for r in p.runs:r.bold=True

    paragraph(doc,'I. INTRODUCTION AND RELATED WORK',style='Heading 1')
    if EXPLICIT_RELATED_HEADINGS:paragraph(doc,'A. Introduction',style='Heading 2')
    for text in INTRO:paragraph(doc,text)
    if EXPLICIT_RELATED_HEADINGS:paragraph(doc,'B. Related work: data sources and model',style='Heading 2')
    for text in RELATED:paragraph(doc,text)

    paragraph(doc,'II. OVERALL ARCHITECTURE, FALLBACK AND EXTENSION',style='Heading 1')
    paragraph(doc,'A. Overall goal',style='Heading 2')
    paragraph(doc,'Detect and assess temporary disruptions in nuScenes and long-term structural changes in Argoverse, then evaluate their implications for map maintenance and planning under verified data conditions. Real-change analysis is used only where map versions and labels can be established; otherwise controlled prior-map perturbations provide a separately reported test setting.')
    paragraph(doc,'B. Architecture',style='Heading 2')
    paragraph(doc,'The four stages are perception, reliability analysis, planning, and Evaluation and Evidence. Perception contains sensor processing and multi-frame verification. Planning precedes the final stage, which updates and visualizes the map and consolidates outputs, metrics and failure cases from all upstream modules. Figure 1 shows this order and the evidence-aggregation paths.')
    section_break(doc,1)
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.keep_with_next=True
    p.add_run().add_picture(str(ARCHITECTURE),width=Inches(7.0))
    paragraph(doc,'Fig. 1. Planning precedes the final Evaluation and Evidence stage, which combines planning results and upstream records with map updates, visualizations and the team evaluation summary.',style='Caption')
    section_break(doc,2)
    paragraph(doc,'C. Module specifications',style='Heading 2')
    paragraph(doc,'All modules use agreed timestamps, City coordinates, object/change IDs, map versions, observation windows and evidence references. The specifications below define the processing steps, outputs and conditions of the five modules.')
    for i,m in enumerate(MODULES,1):
        paragraph(doc,f'{i}) {m["title"]}',style='Heading 3')
        for lead,text in m['parts']:paragraph(doc,text,lead)
    paragraph(doc,'D. Design highlights',style='Heading 2')
    paragraph(doc,'Shared tracks avoid duplicate tracking pipelines. Observation quality, mismatch significance and persistence remain separate decisions. Map edits and planning outputs retain their supporting evidence and map-version references, so failures can be traced across modules.')
    paragraph(doc,'E. Optional extension',style='Heading 2')
    paragraph(doc,'After the core milestones, MetaDrive with ScenarioNet (or CARLA) may support closed-loop simulation and dynamic replanning. Further extensions include vehicle-motion prediction, continuous multi-vehicle evidence fusion and sharing map updates with other vehicles. These are not prerequisites for the core map-maintenance demonstration.')
    paragraph(doc,'F. Fallback plan',style='Heading 2')
    paragraph(doc,'Use nuScenes annotations as a separately identified perception fallback if detection or tracking blocks integration. Use controlled map perturbations when real-change labels are unavailable, and geometric/coverage/support rules if reliability models are unstable. Retain basic route search and checked stopping or waiting decisions if planning extensions fail. A separate event layer and recorded-data replay can replace complex map write-back or closed-loop execution, with the reduced capability stated explicitly.')

    paragraph(doc,'III. EVIDENCE AND EVALUATION',style='Heading 1')
    paragraph(doc,'Our final evidence will be a reproducible scene-level demonstration and quantitative module evaluations linking observations to verification, reliability decisions, planning outputs and visible map updates. The final stage consolidates these results after planning, including before-and-after views, decision and rollback logs, and representative failure cases. Long-term, short-term and unresolved map decisions remain distinguishable.')
    paragraph(doc,'Split data by original scene, keeping all derived perturbations in the same split. Tune thresholds only on development scenes; reference labels and future observations are evaluation-only inputs. Report real-change and synthetic results separately, with unresolved or unevaluable cases and coverage alongside accepted-case scores. A short recording cannot establish long-term persistence, and unavailable ground truth does not support an accuracy claim.')
    section_break(doc,1)
    p=paragraph(doc,'TABLE I. COMPACT MODULE EVALUATION PLAN',style='Caption');p.paragraph_format.keep_with_next=True
    make_table(doc,['Module','Reference / comparison','Main measures'],[
        ['Perception','Verified change labels; independent vehicle boxes and track IDs','Change precision/recall/F1 and geometry error; vehicle AP, IDF1 and ID switches.'],
        ['Verification and behavior','Annotated behavior intervals and change–vehicle associations','Verification performance, behavior macro-F1 and association precision/recall/F1; unresolved proportion.'],
        ['Reliability','Geometric threshold vs. normalized test vs. quality-gated repeated evidence','Precision/recall/F1, false-positive rate and evaluable coverage; failures by occlusion/alignment quality.'],
        ['Planning','Map-only vs. fixed candidate penalty vs. reliability-aware planning','Feasible-route rate, independently checked boundary/obstacle intrusion, clearance, length/detour, runtime and stop/failure frequency.'],
        ['Map updating and final evidence','Reference persistence/update labels; independent sequences, controlled cases and upstream evaluation records','Misclassification/missed changes, eligible-update coverage, false updates, geometry error, delay and rollback correctness; consolidated team metrics and failure cases.'],
    ],[1.05,2.45,3.508],8.6)
    section_break(doc,2)
    paragraph(doc,'Planning comparisons use the same start/goal and obstacle/feasibility checks; compare lengths only when both policies yield feasible routes. Three-dimensional localization error requires independent 3D references, not only 2D boxes. No performance gain is assumed in advance. Conclusions concern the tested offline conditions and do not establish permanence, real-road generalization or closed-loop driving safety.')

    paragraph(doc,'IV. TEAM ROLES AND SIX-WEEK SCHEDULE',style='Heading 1')
    paragraph(doc,'Cui Yingting is responsible for sensor perception and map change detection; Wang Zimo for multi-frame verification and behavior analysis; Mei Ziheng for local HD map reliability assessment; Pan Mingyang for local route and behavior planning; and Huang Ziming for map updating, visualization and final Evaluation and Evidence aggregation.')
    paragraph(doc,'Members develop in parallel and provide module outputs and evaluation records. Planning results feed the final evidence package. Early interface samples support module tests; formal evaluation uses actual outputs. Planning prototypes begin in Week 3 and controlled experiments in Week 5. The shared milestones are:')
    milestones=[
        ('Weeks 1–2', 'Verify data, map roles and interfaces; establish baselines. Week 2: all five modules provide agreed interface samples.'),
        ('Weeks 3–4', 'Implement and integrate the modules. Week 4: one scene runs from raw observations through planning to final map updates and evidence aggregation.'),
        ('Weeks 5–6', 'Evaluate comparisons and failure cases, then refine. Week 6: deliver reproducible code, the demonstration, module evaluations and the team report.'),
    ]
    for lead,text in milestones:paragraph(doc,text,lead)
    paragraph(doc,'REFERENCES',style='Heading 1')
    base=Document(BASE)
    refs=[base.paragraphs[i].text for i in range(96,100)]
    refs.append('Alharbi, M., & Karimi, H. A. (2021). Context-aware sensor uncertainty estimation for autonomous vehicles. Vehicles, 3(4), 721–735.')
    refs.extend(ADDITIONAL_REFERENCES)
    for i,text in enumerate(refs,1):
        p=paragraph(doc,f'[{i}] '+text)
        p.paragraph_format.first_line_indent=Inches(-.16);p.paragraph_format.left_indent=Inches(.16)
        for r in p.runs:r.font.size=Pt(8.7)
    # Close the final two-column section so Word and PDF balance its columns.
    section_break(doc,1)
    doc.core_properties.title=title
    doc.core_properties.author='Cui Yingting; Wang Zimo; Mei Ziheng; Pan Mingyang; Huang Ziming'
    doc.core_properties.subject='Team-feedback revision: detailed module specifications, concise evaluation and schedule.'
    path=OUT/'HD_Map_Proposal_Focused_Revision.docx';doc.save(path)

    paras=[p.text for p in doc.paragraphs]
    body='\n'.join(paras)
    assert 'Overview' not in body and 'Appendix' not in body and 'Module interfaces and responsibility boundaries' not in body
    assert len(MODULES)==5
    words=lambda t:len(re.findall(r"[\w’'-]+",t))
    start=next(i for i,s in enumerate(paras) if s.startswith('II. OVERALL'))
    end=next(i for i,s in enumerate(paras) if s.startswith('III. EVIDENCE'))
    total=words(body)+sum(words(c.text) for t in doc.tables for row in t.rows for c in row.cells)
    section_words=words('\n'.join(paras[start:end]))
    audit={'removed':['Overview','former Section 4.2 on module interfaces as a separate section','Appendix A and detailed weekly task table','duplicated member/deliverable table','repeated decision-flow and schedule graphics'],
        'retained':['four main sections','four-stage/five-module architecture','improved architecture figure','six-week milestones','original four references'],
        'expanded':'Section 2.3 / II.C using the available member drafts',
        'module_sources':[{k:m[k] for k in ('owner','title','source')} for m in MODULES],
        'additional_reference':'Alharbi and Karimi (2021), already cited in the reliability member draft',
        'core_scope':'Pan Mingyang precedes Huang Ziming; Huang Ziming performs map updating/visualization and final Evaluation and Evidence aggregation. Fleet sharing remains an extension.',
        'word_count_including_tables_and_references':total,'section_II_word_count':section_words,'section_II_share':round(section_words/total,3)}
    (OUT/'revision_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
    (OUT/'proposal_text.txt').write_text(body+'\n')
    print(json.dumps({k:v for k,v in audit.items() if 'word' in k or 'share' in k}))
    print(path)


if __name__=='__main__':build()
