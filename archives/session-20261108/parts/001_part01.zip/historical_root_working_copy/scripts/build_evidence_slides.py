"""Build three editable proposal slides with actual map figures and bilingual notes.

Optional presentation dependencies: python-pptx, matplotlib, numpy.
Run from the repository root after generating outputs/scene0980-map-replay.
"""
from pathlib import Path
import json
import math

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, FancyArrowPatch, FancyBboxPatch, Circle
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'outputs/evidence_presentation'
OUT.mkdir(parents=True, exist_ok=True)
SCENE = json.loads((ROOT/'outputs/scene0980-map-replay/scene.json').read_text())

NAVY='142D43'; TEAL='087F8C'; MINT='E7F4F0'; INK='22384A'; MUTED='617485'
PAPER='F6F8FA'; WHITE='FFFFFF'; BORDER='DBE4EA'; CORAL='DA725D'; GOLD='C39425'; BLUE='477FB5'
FONT='Arial'; CJK='Noto Sans CJK SC'


def map_figure(name, observed=False):
    fig, ax = plt.subplots(figsize=(4.2,4.4),dpi=220)
    fig.patch.set_facecolor('#112C40'); ax.set_facecolor('#112C40')
    for e in SCENE['reference_map']['elements']:
        g=e['geometry_city']; layer=e['layer']
        if g['type']=='Polygon':
            fill={'road_segment':'#193E50','lane':'#214E5B','lane_connector':'#1A4557','ped_crossing':'#58707A'}.get(layer,'#193E50')
            ax.add_patch(Polygon(g['coordinates'][0],facecolor=fill,edgecolor='#6392A0',linewidth=.65,alpha=.8,zorder=1))
        else:
            p=g['coordinates']; ax.plot([x[0] for x in p],[x[1] for x in p],color='#8ADACB' if layer=='lane_divider' else '#A8BBC2',lw=1.8,zorder=3)
    frame=SCENE['replay'][0]
    if observed:
        for l in frame['observed_lines']:
            p=l['geometry_city']['coordinates'];ax.plot([x[0] for x in p],[x[1] for x in p],color='#FFD16F',lw=3.3,zorder=7)
        for o in frame['occupancy']:
            for p in o['objects']:
                ax.add_patch(Polygon(p['geometry_city']['coordinates'][0],facecolor='#ED8D77',edgecolor='#FFCEBE',lw=.8,zorder=6))
        for v in frame['vehicles']:
            ax.scatter(*v['xy'],s=28,c='#A5C8FF',edgecolors='white',linewidth=.6,zorder=8)
        x,y=frame['ego']['xy']; a=math.radians(frame['ego']['yaw_deg'])
        ax.scatter(x,y,s=65,c='#70E8C7',edgecolors='white',zorder=10)
        ax.add_patch(FancyArrowPatch((x,y),(x+4*math.cos(a),y+4*math.sin(a)),arrowstyle='-|>',color='#70E8C7',mutation_scale=15,lw=2,zorder=10))
    ax.set_xlim(420,457);ax.set_ylim(1228,1280);ax.set_aspect('equal')
    ax.plot([423,433],[1231,1231],color='white',lw=1.5)
    ax.text(428,1232,'10 m',color='white',fontsize=8,ha='center')
    ax.annotate('N',xy=(453,1274),xytext=(453,1268),color='white',ha='center',fontsize=10,arrowprops={'arrowstyle':'->','color':'white'})
    ax.axis('off');fig.subplots_adjust(0,0,1,1)
    path=OUT/name;fig.savefig(path,facecolor=fig.get_facecolor(),dpi=220);plt.close(fig);return path


def concept_figure():
    fig,ax=plt.subplots(figsize=(4.2,4.4),dpi=220)
    fig.patch.set_facecolor('#112C40');ax.set_facecolor('#112C40')
    ax.add_patch(Polygon([[.5,0],[3.5,0],[3.5,6],[.5,6]],color='#27495A'))
    for x in [.5,3.5]: ax.plot([x,x],[0,6],color='#9CD3D1',lw=2)
    ax.plot([2,2],[0,6],color='#8AABB7',lw=1.3,ls=(0,(5,5)))
    for y in [2.65,3.05,3.45]:
        ax.add_patch(Polygon([[2.15,y],[3.05,y],[3.05,y+.16],[2.15,y+.16]],facecolor='#EB8B75',edgecolor='#FFD0C4',lw=.9))
    ax.plot([2.75,2.75,1.25,1.25,2.75,2.75],[.6,1.5,2.1,4.05,4.8,5.3],ls='--',lw=2.6,color='#8FDCCB')
    ax.annotate('',xy=(2.75,5.65),xytext=(2.75,5.15),arrowprops={'arrowstyle':'-|>','color':'#8FDCCB','lw':2,'mutation_scale':16})
    ax.add_patch(FancyBboxPatch((2.42,.35),.66,.95,boxstyle='round,pad=.02,rounding_size=.12',fc='#E7F5F6',ec='#AFCDD9',lw=1.2,zorder=8))
    ax.add_patch(FancyBboxPatch((2.49,.82),.52,.28,boxstyle='round,pad=.01,rounding_size=.05',fc='#6C9CAE',ec='none',zorder=9))
    ax.text(2.0,5.95,'PLANNED CONCEPT',ha='center',va='top',color='#FFD16F',fontsize=11,fontweight='bold')
    ax.text(2.,-.18,'Route / temporary layer / update gate',ha='center',color='#D9E8EC',fontsize=8.4)
    ax.set_xlim(0,4);ax.set_ylim(-.45,6.35);ax.set_aspect('equal');ax.axis('off');fig.subplots_adjust(0,0,1,1)
    path=OUT/'decision_concept.png';fig.savefig(path,facecolor=fig.get_facecolor(),dpi=220);plt.close(fig);return path


def rgb(hex): return RGBColor.from_string(hex)
prs=Presentation();prs.slide_width=Inches(16);prs.slide_height=Inches(9)
prs.core_properties.title='Planned Evidence and Evaluation | Shared Road Map Maintenance'
prs.core_properties.subject='Three proposal slides: demonstration, evaluation, and claim boundaries'
prs.core_properties.author='AIE1903 Project Team'


def shape(s,x,y,w,h,fill=WHITE,line=None,kind=MSO_SHAPE.ROUNDED_RECTANGLE,radius=.12):
    sh=s.shapes.add_shape(kind,Inches(x),Inches(y),Inches(w),Inches(h))
    sh.fill.solid();sh.fill.fore_color.rgb=rgb(fill)
    if line:sh.line.color.rgb=rgb(line);sh.line.width=Pt(.8)
    else:sh.line.fill.background()
    if kind==MSO_SHAPE.ROUNDED_RECTANGLE:
        sh.adjustments[0]=radius
    return sh


def text(s,x,y,w,h,value,size=18,color=INK,bold=False,font=FONT,align=PP_ALIGN.LEFT):
    box=s.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=box.text_frame
    tf.clear();tf.word_wrap=True;tf.margin_left=0;tf.margin_right=0;tf.margin_top=0;tf.margin_bottom=0
    for i,line in enumerate(value.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.alignment=align
        p.font.name=font;p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=rgb(color)
        p.space_before=Pt(0);p.space_after=Pt(2);p.line_spacing=1.13
    return box


def line(s,x1,y1,x2,y2,color=BORDER,width=1.0):
    c=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2));c.line.color.rgb=rgb(color);c.line.width=Pt(width);return c


def pill(s,x,y,w,label,color=TEAL,bg=MINT):
    shape(s,x,y,w,.30,bg,radius=.4);text(s,x+.1,y+.045,w-.2,.23,label,10.2,color,True,align=PP_ALIGN.CENTER)


def header(title,zh,num):
    s=prs.slides.add_slide(prs.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=rgb(PAPER)
    shape(s,0,0,16,.09,TEAL,kind=MSO_SHAPE.RECTANGLE)
    text(s,.55,.28,8,.23,'AIE1903  /  SHARED ROAD MAP MAINTENANCE',10.7,TEAL,True)
    pill(s,11.56,.22,3.89,'PLANNED EVIDENCE & EVALUATION')
    text(s,.55,.72,14.9,.65,title,34,NAVY,True)
    text(s,.57,1.40,14.8,.35,zh,15,MUTED,font=CJK)
    line(s,.55,8.57,15.45,8.57)
    text(s,.55,8.68,13.8,.20,'Research proposal  •  Real-data and simulation evidence will be reported separately.',10.1,MUTED)
    text(s,14.55,8.65,.9,.25,f'{num:02d} / 03',11,TEAL,True,align=PP_ALIGN.RIGHT)
    return s


def icon(s,x,y,kind,color=TEAL,scale=1):
    if kind=='target':
        for size in [.56,.35,.12]:
            sh=shape(s,x+(.56-size)/2*scale,y+(.56-size)/2*scale,size*scale,size*scale,WHITE,color,MSO_SHAPE.OVAL)
        line(s,x+.32*scale,y+.22*scale,x+.63*scale,y-.02*scale,color,2)
    elif kind=='route':
        pts=[(x+.03*scale,y+.5*scale),(x+.19*scale,y+.5*scale),(x+.19*scale,y+.10*scale),(x+.48*scale,y+.10*scale),(x+.48*scale,y+.37*scale)]
        for a,b in zip(pts,pts[1:]):line(s,*a,*b,color,2.6)
        for px,py in [pts[0],pts[-1]]:shape(s,px-.055*scale,py-.055*scale,.11*scale,.11*scale,color,kind=MSO_SHAPE.OVAL)
    elif kind=='map':
        for i in range(3):
            shape(s,x+i*.18*scale,y+(.05 if i%2 else .0)*scale,.18*scale,.49*scale,MINT,color,MSO_SHAPE.PARALLELOGRAM)
        line(s,x+.13*scale,y+.34*scale,x+.43*scale,y+.14*scale,color,2)
    elif kind=='check':
        line(s,x,y+.22*scale,x+.15*scale,y+.38*scale,color,2.6);line(s,x+.15*scale,y+.38*scale,x+.48*scale,y+.01*scale,color,2.6)
    elif kind=='limit':
        shape(s,x,y,.48*scale,.48*scale,'FFF4DE',color,MSO_SHAPE.OVAL)
        line(s,x+.12*scale,y+.24*scale,x+.36*scale,y+.24*scale,color,2.3)


# Slide 1: two actual data panels plus an explicitly planned concept.
ref=map_figure('reference_map.png');obs=map_figure('observations.png',True);concept=concept_figure()
s=header('What Will We Show?','我们会展示什么？从道路观测，到可解释的规划与地图维护。',1)
shape(s,.55,1.95,14.9,.83,NAVY)
text(s,.79,2.10,14.40,.53,'Our final evidence will be an offline replay and controlled comparisons showing how perception,\nreliability assessment, planning, and map maintenance work together.',17.8,WHITE)
panels=[('01  Reference map',ref,'Actual scene geometry','Keep source features and map IDs.'),
        ('02  Road observations',obs,'Actual frame 0 evidence','Inspect lane curves and occupancy.'),
        ('03  Decision layers',concept,'Planned output concept','Show routes, temporary events and\nevidence-gated map updates.')]
for i,(title,path,label,caption) in enumerate(panels):
    x=.55+i*3.17;shape(s,x,3.02,3.02,3.94,WHITE,BORDER)
    text(s,x+.15,3.17,2.75,.28,title,16.4,NAVY,True)
    shape(s,x+.14,3.61,2.74,2.43,'112C40',kind=MSO_SHAPE.RECTANGLE)
    pic=s.shapes.add_picture(str(path),Inches(x+.14),Inches(3.61),height=Inches(2.43))
    pic.left=Inches(x+.14)+(Inches(2.74)-pic.width)//2
    text(s,x+.14,6.15,2.74,.23,label,11,TEAL if i<2 else GOLD,True)
    text(s,x+.14,6.46,2.74,.43,caption,12.2,MUTED)
shape(s,10.24,3.02,5.21,3.94,WHITE,BORDER)
text(s,10.48,3.20,4.72,.35,'Evidence the audience can inspect',19.2,NAVY,True)
items=[('SYNCHRONIZED REPLAY','Compare the map, observations and decisions\nat the same scene time.'),
       ('TRACEABLE DECISIONS','Show supporting evidence, uncertainty,\nand the reason for each action.'),
       ('VERSIONED MAP HISTORY','Separate temporary events from base-map\nchanges; record updates and rollback.')]
for i,(t,b) in enumerate(items):
    yy=3.85+i*.91
    shape(s,10.49,yy+.03,.08,.57,[TEAL,BLUE,CORAL][i],kind=MSO_SHAPE.RECTANGLE)
    text(s,10.71,yy,4.4,.25,t,11.5,[TEAL,BLUE,CORAL][i],True)
    text(s,10.71,yy+.31,4.42,.50,b,14.1,INK)
text(s,.58,7.17,14.8,.24,'ACTUAL FIGURES: nuScenes scene-0980. Dashed route in panel 03 is illustrative, not a tested planner output.',10.7,MUTED)
shape(s,.55,7.62,14.9,.69,MINT)
text(s,.78,7.83,2.7,.28,'Perception candidates',15.3,NAVY,True)
text(s,3.6,7.81,.35,.3,'→',20,TEAL,True)
text(s,4.12,7.83,3.25,.28,'Reliability assessment',15.3,NAVY,True)
text(s,7.35,7.81,.35,.3,'→',20,TEAL,True)
text(s,7.9,7.81,7.15,.32,'Planning  +  Shared-map maintenance',17,TEAL,True)
s.notes_slide.notes_text_frame.text='''中文讲稿：
我们的最终证据不是一张“检测到了变化”的截图，而是一段能够解释决策过程的离线回放。大家可以同时看到原始道路地图、当前观测、可靠性判定，以及它们如何影响规划和地图维护。
左边两幅图使用我们现有的 nuScenes scene-0980 数据：第一幅是参考地图，第二幅叠加了观测标线、占用轮廓和车辆。第三幅是未来展示形式的概念图，虚线路径不是已经验证的规划结果。
我们希望每项决策都能够追溯：为什么先放在临时事件层，为什么需要继续核验，以及满足哪些条件后才允许更新基础地图。地图更新还会保留版本与回退记录。
目前已有地图和逐帧证据回放；M3、规划对比及真实长期性评估仍属于计划中的集成工作。

English speaking notes:
We will show more than a detection screenshot. The offline replay will connect observations to reliability decisions, planning and map maintenance. The first two panels use our actual scene data. The third panel is a planned visualization concept, not a validated route. Evidence histories and version logs will make the decisions inspectable.

Source: repository outputs/scene0980-map-replay/scene.json; team proposals. No performance measurements are fabricated.'''


# Slide 2: measurable questions, a test protocol and planning baselines.
s=header('How Will We Evaluate It?','我们怎么评估？判断是否准确，规划是否有帮助，地图是否被正确更新。',2)
shape(s,.55,1.95,9.28,4.58,WHITE,BORDER)
text(s,.80,2.16,8.78,.28,'THREE QUESTIONS, WITH MEASURABLE EVIDENCE',12.1,TEAL,True)
rows=[('target','Change assessment','Are the candidates assessed correctly?','Precision / Recall / F1','Use independent labels where available.',TEAL),
      ('route','Planning','Are routes feasible without needless detours?','Feasible route rate / Route length','Compare the same scenarios and obstacle checks.',BLUE),
      ('map','Map maintenance','Do we avoid wrong updates and respond in time?','False-update rate / Geometry error / Update delay','Count incorrect writes, not only successful updates.',CORAL)]
for i,(kind,title,question,metrics,extra,c) in enumerate(rows):
    yy=2.83+i*1.16
    icon(s,.86,yy+.12,kind,c)
    text(s,1.65,yy,7.9,.30,title,19,NAVY,True)
    text(s,1.65,yy+.37,7.9,.26,question,14.6,MUTED)
    text(s,1.65,yy+.74,7.9,.28,metrics,16,c,True)
    if i<2:line(s,.83,yy+1.08,9.53,yy+1.08)
shape(s,10.09,1.95,5.36,4.58,NAVY)
text(s,10.37,2.16,4.8,.35,'Build a fair comparison',20,WHITE,True)
text(s,10.37,2.65,4.78,.50,'Use real observations and controlled\nchanges with known outcomes.',15.1,'D9E8ED')
shape(s,10.37,3.38,4.78,.80,'244556')
text(s,10.58,3.51,4.36,.24,'REAL SCENES',11.4,'8FE0C9',True)
text(s,10.58,3.82,4.35,.26,'Independent review where labels exist.',13.7,WHITE)
shape(s,10.37,4.35,4.78,.80,'244556')
text(s,10.58,4.48,4.36,.24,'CONTROLLED SIMULATION',11.4,'FFD784',True)
text(s,10.58,4.79,4.35,.26,'Known map changes and temporal patterns.',13.7,WHITE)
text(s,10.38,5.42,4.75,.83,'Report these results separately.\nFix thresholds before testing; keep variants\nof the same scene in the same split.',14.0,'D9E8ED')
text(s,.58,6.80,14.7,.27,'PLANNING BASELINES  /  Same scenarios, same feasibility checks, different map-information policies',12,TEAL,True)
cards=[('A','MAP ONLY','Use the reference map\nwithout candidate penalties.',MUTED),
       ('B','FIXED PENALTY','Apply the same added cost\nto every change candidate.',GOLD),
       ('C','RELIABILITY-AWARE','Adapt planning decisions\nto the assessed evidence.',TEAL)]
for i,(letter,title,body,c) in enumerate(cards):
    x=.55+i*5.07;shape(s,x,7.22,4.76,1.08,WHITE,BORDER)
    shape(s,x+.18,7.43,.54,.54,c,kind=MSO_SHAPE.OVAL)
    text(s,x+.18,7.52,.54,.29,letter,18,WHITE,True,align=PP_ALIGN.CENTER)
    text(s,x+.93,7.35,3.62,.25,title,12.7,c,True)
    text(s,x+.93,7.68,3.62,.47,body,13.4,INK)
s.notes_slide.notes_text_frame.text='''中文讲稿：
评估可以概括为三个问题。第一，变化候选判断得对不对：在有独立标注的样本上，计算精确率、召回率和 F1。第二，可靠性信息对规划有没有帮助：比较可行路线比例与路线长度。第三，地图有没有被错误修改：统计错误更新比例、几何误差以及从获得证据到更新的延迟。
规划部分设置三个对照。A 只使用参考地图；B 对所有候选施加相同惩罚；C 根据可靠性结果调整规划。三组必须使用相同场景和障碍物可行性检查。
真实数据与受控仿真分开报告。有独立真值才报告精度指标，不能把未标注样本自动当作负例。阈值只在开发集选择，同一场景的所有扰动版本都留在同一数据划分，避免把相似数据当作独立测试。
这一页是评估设计，还不是实验结果；没有填入任何尚未获得的数值。

English speaking notes:
We will evaluate assessment correctness, planning usefulness and map-update quality. The three planning baselines differ only in their use of map-change information. Real scenes and controlled simulations will be reported separately. Independent labels are required for precision and recall; scene variants must stay in the same data split.
No numeric accuracy or improvement claims are made in this proposal.'''


# Slide 3: positive claims and boundaries; temporal illustrations remain conceptual.
s=header('What Can This Evidence Demonstrate?','这些证据能说明什么？验证测试场景中的表现，并清楚界定结论范围。',3)
shape(s,.55,1.96,7.31,3.60,WHITE,BORDER)
shape(s,8.14,1.96,7.31,3.60,WHITE,BORDER)
pill(s,.83,2.19,3.31,'WHAT IT CAN SUPPORT',TEAL,MINT)
pill(s,8.43,2.19,3.68,'WHAT REMAINS UNPROVEN',GOLD,'FFF3DB')
yes=[('Integration','Modules exchange consistent geometry,\ntimestamps and decisions.'),
     ('Decision quality','Compare feasible routes and incorrect\nmap updates within tested scenarios.'),
     ('Traceability','Explain why evidence led to a temporary\nevent, further review or a map update.')]
no=[('Permanence','Repeated observations do not guarantee\nthat a change will last forever.'),
    ('Probability or causation','A high score is not a calibrated probability;\nnearby behaviour is not a causal explanation.'),
    ('Real-world driving safety','Offline tests do not establish safety\nin closed-loop autonomous driving.')]
for x,items,c,k in [(.86,yes,TEAL,'check'),(8.46,no,GOLD,'limit')]:
    for i,(a,b) in enumerate(items):
        yy=2.85+i*.83;icon(s,x,yy+.08,k,c,.7)
        text(s,x+.54,yy,6.02,.28,a,17.4,NAVY,True)
        text(s,x+.54,yy+.32,6.02,.46,b,14.2,MUTED)
shape(s,.55,5.84,14.9,2.14,NAVY)
text(s,.83,6.02,14.2,.30,'PERSISTENCE NEEDS EVIDENCE ACROSS TIME',12.4,'8FE0C9',True)
text(s,.83,6.44,3.30,.34,'One observed pass',20,WHITE,True)
text(s,.83,6.89,3.25,.64,'Current scene: 41 frames, about 20 s.\nSupports candidates, not permanence.',13.7,'DCE8ED')
line(s,4.43,6.42,4.43,7.57,'476271',1.3)
text(s,4.76,6.43,6.0,.27,'Independent revisits OR labelled temporal simulation',15.2,WHITE,True)
for i,label in enumerate(['Visit 1','Later visit','Later visit']):
    x=4.8+i*1.82
    shape(s,x,6.98,1.50,.55,'2A4B5B')
    line(s,x+.18,7.13,x+.62,7.13,'93D9D1',2)
    line(s,x+.18,7.32,x+.62,7.32,'93D9D1',2)
    shape(s,x+.33,7.16,.16,.12,CORAL,kind=MSO_SHAPE.RECTANGLE)
    text(s,x+.74,7.12,.7,.22,label,10.5,WHITE)
    if i<2:text(s,x+1.55,7.10,.25,.25,'→',16,'A7C9D0',True)
text(s,4.82,7.66,6.1,.19,'Illustrative timeline — not collected revisit results.',10.3,'B4C9D3')
shape(s,11.31,6.39,3.86,1.23,'214B50')
text(s,11.51,6.54,3.45,.27,'MAP-UPDATE GATE',12.1,'8FE0C9',True)
text(s,11.51,6.91,3.45,.51,'Reliability + persistence + geometry\nchecks must pass before writing.',13.4,WHITE)
text(s,.58,8.18,14.8,.24,'我们的目标：证明方法在已测试场景中是否有效，而不是证明变化永久存在或真实驾驶安全。',13.1,MUTED,font=CJK)
s.notes_slide.notes_text_frame.text='''中文讲稿：
我们最后能够支持的是有限而具体的结论：各模块能否协同运行；可靠性和持续性检查是否影响路线与地图更新的质量；每个决策能否追溯到证据。
不能据此得出三个更强的结论。第一，变化永久存在：即使多次观察到，也可能是持续施工。第二，分数是准确概率，或者附近车辆行为由地图差异导致。第三，系统在真实自动驾驶中安全：离线回放没有验证闭环控制。
底部时间线解释我们的长期性验证方法。现有资料只有一次经过，41 帧约 20 秒，不能因为候选持续几秒就判为长期。后续必须使用真正独立的重复访问，或明确标注的时序仿真。图中的后续访问只是方法示意，不代表我们已经采集到了这些数据。
基础地图写回还需同时通过可靠性、持续性与几何检查。当前缺少 M3 与独立复访，真实数据的基础地图更新仍然为零；这体现证据门控，而不是遗漏了更新步骤。

English speaking notes:
Our evidence can support integration, decision-quality comparisons and traceability in the tested scenarios. It cannot guarantee permanence, calibrated probabilities, causal explanations or real-world driving safety. A single pass is insufficient for persistence. Independent revisits or explicitly labelled temporal simulation are needed, followed by reliability and geometry checks before map writing.'''

target=OUT/'AIE1903_Evidence_and_Evaluation.pptx';prs.save(target)
notes=[]
for i,s in enumerate(prs.slides,1):
    notes.append(f'PAGE {i}\n'+s.notes_slide.notes_text_frame.text)
(OUT/'Speaker_Notes_CN_EN.txt').write_text('\n\n'.join(notes),encoding='utf-8')
print(target)
print('Slides:',len(prs.slides),'| editable text/shapes, source-map figures, Chinese + English speaker notes')
