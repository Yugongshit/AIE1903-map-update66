"""Export both proposal editions with planning before final evidence aggregation."""
import json
import build_dataset_model_proposal_versions as editions


def main():
    editions.OUT=editions.ROOT/'outputs/team_proposal_final_evidence'
    editions.focused.ARCHITECTURE=editions.OUT/'architecture.png'
    editions.main()
    path=editions.OUT/'update_notes.json'
    audit=json.loads(path.read_text())
    audit['updates'] += [
        'Module 4: Pan Mingyang — local route and behavior planning',
        'Module 5, final stage: Huang Ziming — map updating, evaluation and evidence',
        'Planning outputs and upstream evaluation records flow into final aggregation',
        'Module order, architecture, evaluation table and team schedule aligned',
    ]
    audit['unchanged'].remove('improved architecture image')
    path.write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':
    main()
