#!/bin/bash
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required for local viewing. Open START_HERE.html for the online links."
  read -r -p "Press Enter to close. "
  exit 1
fi
python3 run_demo.py
