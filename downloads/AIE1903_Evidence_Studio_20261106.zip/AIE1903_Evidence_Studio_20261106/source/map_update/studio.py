"""Data-backed driving-view review and controlled map-write demonstrations."""
from copy import deepcopy
from hashlib import sha256
from math import hypot
from pathlib import Path

from .camera import build_camera_views
from .demo import record
from .engine import Maintainer, rollback
from .geometry import line_distance


def build_write_experiment(scene):
    """Run the existing engine on explicitly invented visits, in an isolated copy.

The line geometry comes from the real reference map. Its changed position,
coverage, matching and revisit evidence are test inputs, not real findings.
"""
    position = scene['replay'][30]['ego']['xy']
    candidates = []
    for element in scene['reference_map']['elements']:
        if element['layer'] != 'lane_divider':
            continue
        points = element['geometry_city']['coordinates']
        length = sum(hypot(b[0]-a[0], b[1]-a[1]) for a, b in zip(points, points[1:]))
        if 8 < length < 35:
            candidates.append((min(hypot(p[0]-position[0], p[1]-position[1]) for p in points), element))
    if not candidates:
        raise ValueError('No appropriate source line for controlled write experiment')
    original = min(candidates, key=lambda pair: pair[0])[1]
    line = original['geometry_city']['coordinates']
    dx, dy = line[-1][0]-line[0][0], line[-1][1]-line[0][1]
    norm = hypot(dx, dy)
    normal = [-dy/norm, dx/norm]
    baseline = {'schema_version': '1.0', 'map_id': 'controlled-copy-of-nuscenes-scene0980',
                'version': 'experiment-v0', 'dataset_id': 'controlled_test',
                'source_dataset_id': 'nuscenes', 'map_role': 'controlled_synthetic_prior',
                'coordinate_reference': {'frame': 'City', 'city_id': scene['reference_map']['map_id'], 'units': 'm'},
                'provenance': 'Real reference geometry copied into an isolated test. Observations and time spans are invented.',
                'elements': [{'element_id': original['element_id'], 'element_type': 'lane_marking',
                              'geometry_city': deepcopy(original['geometry_city']), 'active': True,
                              'properties': {'source_layer': original['layer']}}]}
    variants = []
    for offset in (.6, .8, 1.2):
        changed = {'type': 'LineString', 'coordinates': [[p[0]+normal[0]*offset, p[1]+normal[1]*offset] for p in line]}
        records = []
        for i, hour in enumerate((0, 12, 26)):
            r = record(f'controlled-shift-{i}', f'invented-visit-{i}', hour, target=original['element_id'], geometry=changed)
            r.update(map_id=baseline['map_id'], map_version=baseline['version'],
                     coordinate_reference=deepcopy(baseline['coordinate_reference']),
                     source='explicitly_invented_observation_for_write_engine_test')
            records.append(r)
        bundles = [Maintainer(baseline).run(records[:n]) for n in range(4)]
        if len(bundles[3]['versions']) != 2:
            raise ValueError('Controlled experiment did not pass the existing engine write gate')
        bundles.append(rollback(bundles[3], baseline['version']))
        if bundles[-1]['current_map']['elements'] != baseline['elements']:
            raise ValueError('Rollback did not restore original geometry')
        variants.append({'offset_m': offset, 'measured_geometry_delta_m': line_distance(line, changed['coordinates']),
                         'records': records, 'stages': [
                             {'stage': i, 'version': b['current_map']['version'], 'map': b['current_map'],
                              'versions': b['versions'], 'events': b['events'], 'policy': b['policy']}
                             for i, b in enumerate(bundles)]})
    return {'dataset_type': 'controlled_map_write_test', 'source_dataset_id': 'nuscenes',
            'source_scene_id': scene['scene_id'], 'source_map_sha256': scene['reference_map']['source_sha256'],
            'target_id': original['element_id'], 'baseline': baseline, 'variants': variants,
            'real_candidate_id': None, 'real_map_modified': False, 'independent_real_visits_added': 0,
            'scope': 'Only engine mechanics: invented offsets, complete coverage, valid alignment and three independent visits over 26 hours. Not a real change detection result.',
            'assumptions': ['目标身份与整段观测在试验中指定，并非自动核实的真实 LD 匹配。',
                            '0 / 12 / 26 小时的三次访问及 95% 有效覆盖率是人为设置。',
                            '只修改试验副本的一条标线，不修改道路拓扑，也不证明规划可行性。']}


def issue_register(scene, cameras):
    """Concrete outstanding problems, with owners and acceptance conditions."""
    base = 'AIE1903 原始资料/'
    return [
        {'id': 'P01', 'priority': 'P0', 'status': '待补数据', 'title': '车前照片尚不可读取',
         'finding': f"CAM_FRONT 的 {len(cameras['views'])} 帧元数据、标定和位姿已接入；当前目录找到 {cameras['available_images']} 张对应照片。旧上传的完整 enhanced.rrd 超过文件服务 32 MiB 传输上限，读取被拒绝；可读 overlay.rrd 只有增量图层。",
         'impact': '目前只能显示几何重建与感知录屏，不能证明照片中的叠加正确。',
         'owner': '感知 / 数据交付 + 可视化接入',
         'next': '从现有完整 RRD 或原数据导出该场景 CAM_FRONT 的 41 张 JPG，保留 sample_data 中的原文件名；或交付可读取的小体积相机素材。',
         'acceptance': '41 张图片与 sample_token、相机时间戳、分辨率、标定一一匹配；人工检查至少正常、遮挡、差异三类帧。',
         'source': base+'v1.0-trainval/sample_data.json；perception/outputs/visualization/README.md'},
        {'id': 'P02', 'priority': 'P0', 'status': '证据不足', 'title': '可靠性已接入，但 7 个对象仍不可写图',
         'finding': 'M3 已成功复现并接入；七个复核单元均为 Insufficient Evidence，有效覆盖率和物理对齐状态未知。',
         'impact': '不能用候选高分、已检出点比例或代数往返误差代替可靠性证据。',
         'owner': '梅子衡 + 感知负责人',
         'next': '按同一对象和帧窗口补可见长度、遮挡长度、有效长度及对齐核验，再重算可靠性。',
         'acceptance': '能从非空有效覆盖率追溯到分母与原图；错误对齐 / 低覆盖样例会被拒绝。',
         'source': base+'M3_scene0980_proposal_supplement 2/results/real_scene_handoff.json'},
        {'id': 'P03', 'priority': 'P0', 'status': '待核验', 'title': '6 个标线候选缺少明确的修改对象',
         'finding': '六个 LD 均未获得已验证的地图修改目标；最近地图线不能自动视为同一个物理对象。',
         'impact': '无法决定应替换哪段线，可能把投影偏差或短局部段写入整条地图线。',
         'owner': '崔映庭 + 地图维护',
         'next': '优先核查 LD003 / LD004：交目标 element_id、变化类型、覆盖区段及有序几何；误检也需保留结论。',
         'acceptance': '至少一个对象可从图像、感知曲线追溯到唯一地图目标，或明确判为不应修改。',
         'source': base+'M3_scene0980_proposal_supplement 2/results/real_scene_decisions.csv'},
        {'id': 'P04', 'priority': 'P0', 'status': '真实验证缺口', 'title': '一次短场景不能验证长期变化',
         'finding': 'scene-0980 只有一次约 19.85 秒、41 帧的访问；参考地图的历史 / 当前时间关系也未核验。重复目录不构成复访。',
         'impact': '真实基础地图更新仍为 0，不能报告长期改图成功率；受控写入只是机制测试。',
         'owner': '多帧验证 + 感知 + 地图维护',
         'next': '获取同一路段独立时段观测及基线时间说明；拿不到时，将真实结论限定为差异候选，单列受控试验。',
         'acceptance': '独立 visit_id、真实时间、同一对象匹配与观察周期可核查，不能复制本片段填满门槛。',
         'source': base+'scene_info.json；v1.0-trainval/scene.json；processed/frames.csv'},
        {'id': 'P05', 'priority': 'P0', 'status': '未接入', 'title': '没有可称为“应该这样行驶”的路线输出',
         'finding': '当前集成没有规划模块的可执行入口、起终点、规划路线及可行性检查；现有 ego 轨迹是实际行驶记录。',
         'impact': '轨迹可投影查看，但不能冒充推荐路线，也不能宣称避障或规划改善。',
         'owner': '潘明阳 + 可视化 / 评估',
         'next': '交带地图版本、决策时间、起终点、route_xy、策略、feasible、拒绝原因与碰撞 / 道路约束检查的结构化结果。',
         'acceptance': '同一输入可比较基线与候选策略；无路时明确失败；前视图与鸟瞰使用同一条有来源的路线。',
         'source': '当前集成接口；docs/m3_integration_and_architecture.md'},
        {'id': 'P06', 'priority': 'P0', 'status': '待标注', 'title': '217 行真实评估标签为空',
         'finding': '候选 29、行为 13、关联 175，共 217 行模板无独立真值。',
         'impact': '无法诚实计算真实 Precision / Recall / F1、误更新率或规划收益。',
         'owner': '全组协作标注，黄子明汇总',
         'next': '先选一个最小评估子集：正常、疑似变化、遮挡和错误匹配，记录标注者、依据及争议；标注与预测分开。',
         'acceptance': '标签有证据引用，不照抄预测；场景级划分，扰动版本不跨训练 / 测试划分。',
         'source': base+'perception/evaluation_labels/'},
        {'id': 'P07', 'priority': 'P1', 'status': '需限制表述', 'title': '受控实验的高 F1 掩盖了大量拒判',
         'finding': '质量门控方法 126 个变体只明确判定 36 个：覆盖率 28.6%，条件 F1 94.1%，全正例召回 22.2%。这些变体来自同场景三个窗口。',
         'impact': '不能把条件 F1 当整体准确率，也不能把 126 个扰动当 126 个独立真实场景。',
         'owner': '梅子衡 + Evaluation and Evidence',
         'next': '同时报告覆盖率、拒判数、条件指标和全正例召回；补独立校准 / 测试场景。',
         'acceptance': 'proposal、图表和讲稿口径一致；真实数据与受控扰动分开。',
         'source': base+'M3_scene0980_proposal_supplement 2/results/controlled_comparison.csv'},
        {'id': 'P08', 'priority': 'P1', 'status': '在线能力缺口', 'title': '当前汇总分数会使用之后的帧',
         'finding': '多帧分数、行为关联按整个时间窗口汇总；本轮重建还可查看后来真实经过的轨迹。',
         'impact': '可以复核历史证据，不能直接用作早于窗口结束时的在线规划输入。',
         'owner': '王子墨 + 规划',
         'next': '按决策时间截断观测并重算上游分数；为在线和事后分析分别输出接口。',
         'acceptance': '任何时刻的决策都不读取未来帧；若仍为事后复核，界面和报告明确说明。',
         'source': base+'perception/pipeline/stage3.py；stage5.py；stage6.py'},
        {'id': 'P09', 'priority': 'P1', 'status': '待实图检验', 'title': '前视投影有时间差与地平面假设',
         'finding': 'CAM_FRONT 与参考帧时间最大差 37.609 ms，对应 ego 位移最高约 0.228 m。新版使用相机曝光时的 ego pose；2D 地图仍按 z=0 投影，目标框保留标注帧时间。',
         'impact': '地面坡度、遮挡或动态目标运动会造成照片叠加偏差；重建画面本身不能验证物理对齐。',
         'owner': '感知 / 标定 + 可视化',
         'next': '用原图核对静态地标重投影，报告像素 / 米级误差；需要时接入地面高度与时序插值。',
         'acceptance': '给出定量误差与失败帧，保留不可判断区域；不把重建图称为原始照片。',
         'source': base+'processed/alignment_check.json；v1.0-trainval/ego_pose.json'},
        {'id': 'R01', 'priority': 'P1', 'status': '已绕开，需规范交付', 'title': '原运行脚本和媒体交付不便复现',
         'finding': '原入口含旧本机路径；Windows .cmd 不能直接供 Mac 使用；仓库 .gitignore 排除了 JPG、MP4、RRD。当前用隔离运行器显式指定路径。',
         'impact': '“GitHub Desktop 已同步”不等于媒体文件也上传了；换电脑后原入口可能找不到输入。',
         'owner': '各模块负责人 + 集成',
         'next': '统一相对路径和参数入口，附版本依赖、小场景输入输出、媒体清单与哈希；大媒体独立交付。',
         'acceptance': '新目录可复跑同一结果，媒体清单中的文件实际可读；无需修改成员源码中的路径。',
         'source': '.gitignore；scripts/verify_upstream.py；scripts/verify_m3.py'},
        {'id': 'R02', 'priority': 'P1', 'status': '本轮补齐展示', 'title': 'PPT 承诺与已上线展示曾不一致',
         'finding': 'PPT 第 2–3 页承诺前后地图、判断原因、版本记录、回退验证；旧网页主要呈现候选与评估。',
         'impact': '观看者看不到改图动作，容易把图层叠加误认为地图更新。',
         'owner': '黄子明 / Evaluation and Evidence',
         'next': '本轮新增实际事件层对照、真实底图副本上的引擎写入试验、几何差异、版本与回退，并保留真实写入 0 的说明。',
         'acceptance': '可操作查看改前 / 改后，导出实际引擎 patch，回退恢复原几何；真实与受控统计不混用。',
         'source': 'outputs/map_maintenance_five_sections/中文/地图更新_五部分结构_中文版.pptx；map_update/engine.py'},
    ]


def build_studio_data(raw_root, scene, dashboard):
    camera = build_camera_views(raw_root, scene)
    return {'schema': 'aie1903-visual-studio-1.0', 'dataset_id': 'nuscenes',
            'real': dashboard['real'], 'controlled_evaluation': dashboard['controlled'],
            'provenance': dashboard.get('provenance', []), 'camera': camera,
            'write_experiment': build_write_experiment(scene), 'issues': issue_register(scene, camera),
            'real_events': scene['event_layer'], 'planning': {'status': 'not_integrated', 'route': None},
            'perception_video': None}
