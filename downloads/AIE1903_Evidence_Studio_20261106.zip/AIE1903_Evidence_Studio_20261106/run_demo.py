#!/usr/bin/env python3
"""Serve this packaged static demo on localhost using Python's standard library."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
import webbrowser

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--no-browser', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent / 'website'
if not (root / 'en/index.html').is_file():
    raise SystemExit('Please extract the entire ZIP before starting the demo.')
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
with ThreadingHTTPServer(('127.0.0.1', 0), handler) as server:
    url = 'http://127.0.0.1:%d/en/index.html#decisions' % server.server_port
    print('Demo: ' + url, flush=True)
    print('Keep this window open. Press Ctrl+C to stop. / 保持窗口打开，按 Ctrl+C 结束。', flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
