AIE1903 Evaluation & Evidence — 下载包使用说明
版本：2026-11-06

1. 最快查看：打开 START_HERE.html，点击英文版或中文版在线入口。
英文版：https://yugongshit.github.io/AIE1903-map-update66/en/index.html?v=35aa3d4#decisions
中文版：https://yugongshit.github.io/AIE1903-map-update66/zh/index.html?v=35aa3d4#decisions

2. 本地运行：先完整解压 ZIP，不要只打开里面的单个文件。
本地运行需要已经安装 Python 3，不需要 pip 安装依赖。
Mac：双击 Start_Mac.command。若无法直接启动，在终端进入解压目录后运行 python3 run_demo.py。
Windows：双击 Start_Windows.cmd，或在解压目录执行 py -3 run_demo.py。
浏览器会打开本地网站；终端窗口保持打开。按 Ctrl+C 结束。
如果电脑没有 Python 3，直接使用在线链接即可。
Rerun 需要支持 WebGL 的浏览器；建议使用桌面版 Chrome 或 Edge。
不要只双击 website/en/index.html 来验证全部功能，Rerun 的模块与 WASM 需要 HTTP 服务。

3. 演示顺序：LD003 → 拖动地图分界线 → 展开可靠性和决策依据 → 受控写入实验 → 26 小时 → 回退 → 评估检查。

4. 内容：
website/：已经构建的英文和中文网站、原视频、RRD、官方 Rerun 查看器、案例 CSV、来源说明和报告。
source/：维护引擎、网站构建与检查代码、测试和文档；它不包含全部原始资料或模型权重。
validation/：这一版本的检查结果与 GitHub Pages 部署记录。
Quick_Start_CN.docx：可用 Word 打开的使用说明。
PACKAGE_MANIFEST.json：来源提交和各文件 SHA256。

5. 数据边界：真实场景仅 nuScenes scene-0980。真实基础地图写入为 0，真实准确率尚未知。
受控写图使用隔离副本及人为设定的偏移、复访和质量输入；不代表真实复访。
英文使用原类别标注，中文翻译显示名称。Argoverse、规划和跨车共享未接入。
已有原始演示视频；没有在下载包中补造 CAM_FRONT 实景照片。

6. source/ 用于查阅和继续开发。要从头重新运行完整数据处理/构建流程，仍需原仓库中对应成员的原始资料及依赖。
本地直接演示 website/ 不需要重新处理数据。

网站提交：35aa3d4f93377d8fca40ea48bfc672c9e719a7fc
源码提交：0d90d1fe429b2e36ec4ef2b901aba45a1fc1b626
检查范围：99 项核心测试；56 项新工作台、40 项双语回归和35 项 Rerun 浏览器检查通过。
浏览器验证环境为云端 Chromium / SwiftShader，不代表已经在你的 Mac 或 Safari 上验证。
