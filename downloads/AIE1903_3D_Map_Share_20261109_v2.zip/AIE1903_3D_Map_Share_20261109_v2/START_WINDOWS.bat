@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 launch.py
    pause
    exit /b
)
where python >nul 2>nul
if not errorlevel 1 (
    python launch.py
    pause
    exit /b
)
echo Python 3 was not found. Open index.html for the online link and instructions.
pause
